# clean_duplicates.py
from database_mongo import users_collection

print("🔍 Buscando usuarios duplicados...")

# Encontrar duplicados por correo
pipeline = [
    {
        "$group": {
            "_id": "$correo",
            "dups": {"$push": "$_id"},
            "count": {"$sum": 1}
        }
    },
    {
        "$match": {
            "count": {"$gt": 1}
        }
    }
]

duplicates = list(users_collection.aggregate(pipeline))

print(f"📊 Encontrados {len(duplicates)} usuarios duplicados")

if duplicates:
    for doc in duplicates:
        # Mantener el primer documento, eliminar los demás
        keep_id = doc["dups"][0]
        delete_ids = doc["dups"][1:]
        
        print(f"🔄 Procesando {doc['_id']}:")
        print(f"   - Mantener: {keep_id}")
        print(f"   - Eliminar: {len(delete_ids)} duplicados")
        
        # Eliminar duplicados
        result = users_collection.delete_many({"_id": {"$in": delete_ids}})
        print(f"   ✅ Eliminados {result.deleted_count} duplicados")
    
    print("🎉 Limpieza de duplicados completada")
else:
    print("✅ No se encontraron usuarios duplicados")

# Verificar resultado final
total_usuarios = users_collection.count_documents({})
print(f"📈 Total de usuarios después de limpieza: {total_usuarios}")

# Mostrar usuarios únicos
usuarios_unicos = list(users_collection.find({}, {"correo": 1, "nombre": 1, "rol": 1}))
print("\n👥 Usuarios únicos:")
for usuario in usuarios_unicos:
    print(f"   - {usuario['nombre']} ({usuario['correo']}) - {usuario['rol']}")