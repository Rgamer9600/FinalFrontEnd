# asignaciones.py - Sistema de asignación de pedidos a repartidores
from fastapi import APIRouter, HTTPException
from database_mongo import db  # ✅ Importar db
from bson import ObjectId
from datetime import datetime
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter(prefix="/asignaciones", tags=["Asignaciones"])

# Definir colecciones usando db
orders_collection = db.orders
repartidores_collection = db.repartidores
payments_collection = db.payments
users_collection = db.users

class AsignacionData(BaseModel):
    pedido_id: str
    repartidor_id: str

@router.get("/repartidores/")
def listar_repartidores(estado: Optional[str] = None):
    """Listar repartidores disponibles"""
    query = {}
    if estado:
        query["estado"] = estado
    
    repartidores = list(repartidores_collection.find(query))
    
    # Convertir ObjectId a string
    for rep in repartidores:
        rep["id"] = str(rep["_id"])
        del rep["_id"]
    
    return repartidores

@router.get("/pedidos_pendientes/")
def listar_pedidos_pendientes_asignacion():
    """Listar pedidos pagados con tarjeta que están listos para asignar"""
    
    # Buscar pedidos pagados con tarjeta y estado 'pagado'
    pedidos_pendientes = []
    all_orders = list(orders_collection.find({"estado": "pagado"}))
    
    for pedido in all_orders:
        # Verificar si el pago fue con tarjeta
        pago = payments_collection.find_one({"pedido_id": str(pedido["_id"])})
        
        if pago and pago.get("metodo") == "tarjeta":
            # Verificar que no esté ya asignado
            repartidor_asignado = repartidores_collection.find_one({
                "pedidos_asignados": str(pedido["_id"])
            })
            
            if not repartidor_asignado:
                pedidos_pendientes.append({
                    "id": str(pedido["_id"]),
                    "cliente_correo": pedido.get("cliente_correo", ""),
                    "total": pedido.get("total", 0),
                    "created_at": pedido.get("created_at"),
                    "items": pedido.get("items", []),
                    "direccion_entrega": pedido.get("direccion_entrega", "Por definir")
                })
    
    return pedidos_pendientes

@router.post("/asignar/")
def asignar_pedido_repartidor(asignacion: AsignacionData):
    """Asignar un pedido a un repartidor"""
    
    # Validar IDs
    if not ObjectId.is_valid(asignacion.pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    if not ObjectId.is_valid(asignacion.repartidor_id):
        raise HTTPException(status_code=400, detail="ID de repartidor inválido")
    
    # Verificar que el pedido existe y está pagado con tarjeta
    pedido = orders_collection.find_one({"_id": ObjectId(asignacion.pedido_id)})
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")
    
    if pedido.get("estado") != "pagado":
        raise HTTPException(status_code=400, detail="Pedido no está pagado")
    
    # Verificar método de pago
    pago = payments_collection.find_one({"pedido_id": asignacion.pedido_id})
    if not pago or pago.get("metodo") != "tarjeta":
        raise HTTPException(status_code=400, detail="Solo se pueden asignar pedidos pagados con tarjeta")
    
    # Verificar que el repartidor existe y está disponible
    repartidor = repartidores_collection.find_one({"_id": ObjectId(asignacion.repartidor_id)})
    if not repartidor:
        raise HTTPException(status_code=404, detail="Repartidor no encontrado")
    
    if repartidor.get("estado") != "disponible":
        raise HTTPException(status_code=400, detail="Repartidor no disponible")
    
    # Verificar capacidad del repartidor
    if len(repartidor.get("pedidos_asignados", [])) >= repartidor.get("capacidad_maxima", 3):
        raise HTTPException(status_code=400, detail="Repartidor ha alcanzado su capacidad máxima")
    
    try:
        # Asignar pedido al repartidor
        repartidores_collection.update_one(
            {"_id": ObjectId(asignacion.repartidor_id)},
            {
                "$push": {"pedidos_asignados": asignacion.pedido_id},
                "$set": {"ultima_asignacion": datetime.utcnow()}
            }
        )
        
        # Actualizar estado del pedido
        orders_collection.update_one(
            {"_id": ObjectId(asignacion.pedido_id)},
            {"$set": {
                "estado": "asignado", 
                "repartidor_id": asignacion.repartidor_id,
                "fecha_asignacion": datetime.utcnow()
            }}
        )
        
        # Si el repartidor alcanza su capacidad, marcarlo como ocupado
        nuevos_pedidos = repartidor.get("pedidos_asignados", []) + [asignacion.pedido_id]
        if len(nuevos_pedidos) >= repartidor.get("capacidad_maxima", 3):
            repartidores_collection.update_one(
                {"_id": ObjectId(asignacion.repartidor_id)},
                {"$set": {"estado": "ocupado"}}
            )
        
        return {
            "mensaje": "Pedido asignado exitosamente",
            "pedido_id": asignacion.pedido_id,
            "repartidor": repartidor.get("nombre"),
            "codigo_repartidor": repartidor.get("codigo")
        }
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error al asignar: {str(e)}")

@router.get("/mis_asignaciones/{repartidor_id}")
def obtener_asignaciones_repartidor(repartidor_id: str):
    """Obtener pedidos asignados a un repartidor"""
    
    if not ObjectId.is_valid(repartidor_id):
        raise HTTPException(status_code=400, detail="ID de repartidor inválido")
    
    repartidor = repartidores_collection.find_one({"_id": ObjectId(repartidor_id)})
    if not repartidor:
        raise HTTPException(status_code=404, detail="Repartidor no encontrado")
    
    # Obtener detalles de los pedidos asignados
    pedidos_asignados = []
    for pedido_id in repartidor.get("pedidos_asignados", []):
        if ObjectId.is_valid(pedido_id):
            pedido = orders_collection.find_one({"_id": ObjectId(pedido_id)})
            if pedido:
                pedidos_asignados.append({
                    "id": str(pedido["_id"]),
                    "cliente_correo": pedido.get("cliente_correo", ""),
                    "total": pedido.get("total", 0),
                    "estado": pedido.get("estado", ""),
                    "created_at": pedido.get("created_at"),
                    "direccion_entrega": pedido.get("direccion_entrega", "Por definir")
                })
    
    return {
        "repartidor": {
            "nombre": repartidor.get("nombre"),
            "codigo": repartidor.get("codigo"),
            "estado": repartidor.get("estado"),
            "zona": repartidor.get("zona")
        },
        "pedidos_asignados": pedidos_asignados,
        "total_pedidos": len(pedidos_asignados),
        "capacidad_restante": repartidor.get("capacidad_maxima", 3) - len(pedidos_asignados)
    }

@router.put("/entregar/{pedido_id}")
def marcar_pedido_entregado(pedido_id: str):
    """Marcar un pedido como entregado"""
    
    if not ObjectId.is_valid(pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    # Actualizar estado del pedido
    result = orders_collection.update_one(
        {"_id": ObjectId(pedido_id)},
        {"$set": {"estado": "entregado", "fecha_entrega": datetime.utcnow()}}
    )
    
    if result.modified_count == 0:
        raise HTTPException(status_code=404, detail="Pedido no encontrado o ya entregado")
    
    # Quitar pedido de la lista del repartidor
    repartidores_collection.update_one(
        {"pedidos_asignados": pedido_id},
        {"$pull": {"pedidos_asignados": pedido_id}}
    )
    
    # Verificar si el repartidor ahora está disponible
    repartidor = repartidores_collection.find_one({"pedidos_asignados": pedido_id})
    if repartidor and len(repartidor.get("pedidos_asignados", [])) < repartidor.get("capacidad_maxima", 3):
        repartidores_collection.update_one(
            {"_id": repartidor["_id"]},
            {"$set": {"estado": "disponible"}}
        )
    
    return {"mensaje": "Pedido marcado como entregado"}

@router.get("/reporte_asignaciones/")
def generar_reporte_asignaciones():
    """Generar reporte de asignaciones"""
    
    repartidores = list(repartidores_collection.find({}))
    reporte = []
    
    for rep in repartidores:
        pedidos_info = []
        for pedido_id in rep.get("pedidos_asignados", []):
            if ObjectId.is_valid(pedido_id):
                pedido = orders_collection.find_one({"_id": ObjectId(pedido_id)})
                if pedido:
                    pedidos_info.append({
                        "id": str(pedido["_id"]),
                        "cliente": pedido.get("cliente_correo", ""),
                        "total": pedido.get("total", 0),
                        "estado": pedido.get("estado", "")
                    })
        
        reporte.append({
            "repartidor": rep.get("nombre"),
            "codigo": rep.get("codigo"),
            "estado": rep.get("estado"),
            "zona": rep.get("zona"),
            "pedidos_asignados": len(rep.get("pedidos_asignados", [])),
            "capacidad_maxima": rep.get("capacidad_maxima", 3),
            "pedidos_detalle": pedidos_info
        })
    
    return reporte

@router.get("/ordenes-despacho/")
async def obtener_ordenes_despacho(repartidor_id: Optional[str] = None, estado: Optional[str] = None):
    """Obtener órdenes de despacho"""
    try:
        print(f"🔍 [ordenes-despacho] Buscando órdenes...")
        
        # Construir query básica - MODIFICADO: incluir más estados relevantes
        query = {"estado": {"$in": ["pagado", "asignado", "en_camino"]}}
        
        # Filtrar por repartidor
        if repartidor_id and repartidor_id != "todos":
            # Buscar repartidor por nombre o ID
            repartidor = None
            if ObjectId.is_valid(repartidor_id):
                repartidor = repartidores_collection.find_one({"_id": ObjectId(repartidor_id)})
            
            if repartidor:
                # Buscar pedidos con este repartidor_id O en su lista de pedidos_asignados
                pedidos_ids = repartidor.get("pedidos_asignados", [])
                query["$or"] = [
                    {"repartidor_id": repartidor_id},
                    {"_id": {"$in": [ObjectId(pid) for pid in pedidos_ids if ObjectId.is_valid(pid)]}}
                ]
        
        # Filtrar por estado si se especifica
        if estado and estado != "todos":
            query["estado"] = estado
        else:
            # MODIFICADO: Incluir "entregado" en los estados por defecto
            query["estado"] = {"$in": ["asignado", "en_camino", "entregado"]}
        
        print(f"🔍 Query: {query}")
        
        # Buscar pedidos
        pedidos = list(orders_collection.find(query).sort("created_at", 1))
        print(f"✅ [ordenes-despacho] Encontrados {len(pedidos)} pedidos")
        
        # Formatear respuesta
        ordenes_formateadas = []
        
        for pedido in pedidos:
            try:
                orden = {
                    "_id": str(pedido["_id"]),
                    "pedido_id": str(pedido["_id"]),  # Agregar este campo para compatibilidad
                    "numero_pedido": f"PED-{str(pedido['_id'])[-6:].upper()}",
                    "estado": pedido.get("estado", "pendiente"),
                    "total": pedido.get("total", 0),
                    "direccion_entrega": pedido.get("direccion_entrega", "Dirección no especificada"),
                    "created_at": pedido.get("created_at", datetime.now()),
                    "fecha_salida": pedido.get("fecha_asignacion", pedido.get("created_at", datetime.now())),
                    # AGREGAR estos campos para el frontend:
                    "cliente_nombre": pedido.get("cliente_nombre", ""),
                    "cliente_correo": pedido.get("cliente_correo", ""),
                    "repartidor_nombre": pedido.get("repartidor_nombre", ""),
                    "repartidor_id": pedido.get("repartidor_id", ""),
                    "entregado": pedido.get("estado") == "entregado"  # Campo booleano
                }
                
                # Obtener repartidor si existe
                if "repartidor_id" in pedido and pedido["repartidor_id"] and ObjectId.is_valid(pedido["repartidor_id"]):
                    repartidor = repartidores_collection.find_one({"_id": ObjectId(pedido["repartidor_id"])})
                    if repartidor:
                        orden["repartidor"] = [{
                            "_id": str(repartidor["_id"]),
                            "nombre": repartidor.get("nombre", "Repartidor"),
                            "codigo": repartidor.get("codigo", "N/A")
                        }]
                        # Asegurar que repartidor_nombre esté disponible
                        if not orden["repartidor_nombre"]:
                            orden["repartidor_nombre"] = repartidor.get("nombre", "Repartidor")
                
                # Obtener cliente
                if "cliente_correo" in pedido:
                    cliente = users_collection.find_one({"correo": pedido["cliente_correo"]})
                    if cliente:
                        orden["cliente"] = [{
                            "_id": str(cliente["_id"]),
                            "nombre": cliente.get("nombre", "Cliente"),
                            "correo": cliente.get("correo", "")
                        }]
                        # Asegurar que cliente_nombre esté disponible
                        if not orden["cliente_nombre"]:
                            orden["cliente_nombre"] = cliente.get("nombre", "Cliente")
                
                # Obtener items
                if "items" in pedido:
                    orden["items"] = pedido["items"]
                
                ordenes_formateadas.append(orden)
                
            except Exception as e:
                print(f"⚠️ Error formateando pedido: {str(e)}")
                continue
        
        return {
            "ordenes": ordenes_formateadas,
            "total": len(ordenes_formateadas)
        }
        
    except Exception as e:
        print(f"❌ [ordenes-despacho] Error: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")