# database_mongo.py - VERSIÓN CORREGIDA SIN ERRORES DE ÍNDICES
from pymongo import MongoClient
from datetime import datetime
import os

MONGO_URI = "mongodb://localhost:27017"

print(f"🔗 Conectando a MongoDB: {MONGO_URI}")

try:
    client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=5000)
    client.admin.command('ping')
    print("✅ Conexión a MongoDB exitosa")
except Exception as e:
    print(f"❌ Error conectando a MongoDB: {e}")
    print("💡 Asegúrate de que MongoDB esté corriendo en el puerto 27017")
    exit(1)

db = client["lacava_del_valle"]

# ========== COLECCIONES PRINCIPALES ==========
users_collection = db["users"]
products_collection = db["products"] 
orders_collection = db["orders"]
payments_collection = db["payments"]
caja_collection = db["caja"]
order_items_collection = db["order_items"]
repartidores_collection = db["repartidores"]
failed_attempts_collection = db["failed_login_attempts"] 

# ========== FUNCIÓN PARA CREAR ÍNDICES ==========

def create_indexes():
    """Crear todos los índices necesarios para optimizar la base de datos"""
    try:
        print("🔧 Creando índices de la base de datos...")
        
        # ÍNDICES PARA USUARIOS - CON MANEJO DE ERRORES
        print("  👥 Creando índices para usuarios...")
        try:
            # Primero eliminar índice existente si hay problema
            try:
                users_collection.drop_index("correo_1")
                print("    🔄 Índice anterior eliminado")
            except:
                pass  # Si no existe, no hay problema
                
            # Crear índice SIN unique para evitar error de duplicados
            users_collection.create_index("correo")
            print("    ✅ Índice para correo creado")
        except Exception as e:
            print(f"    ⚠️ Error con índice de correo: {e}")
            print("    ⚠️ Continuando sin índice único...")
            
        try:
            users_collection.create_index("rol")
            users_collection.create_index("created_at")
            print("    ✅ Índices básicos de usuarios creados")
        except Exception as e:
            print(f"    ⚠️ Error con otros índices de usuarios: {e}")
        
        # ÍNDICES PARA SEGURIDAD (INTENTOS FALLIDOS) - IMPORTANTE
        print("  🔒 Creando índices de seguridad...")
        try:
            failed_attempts_collection.create_index("email")
            failed_attempts_collection.create_index("blocked_until")
            failed_attempts_collection.create_index("last_attempt")
            failed_attempts_collection.create_index("ip_address")
            failed_attempts_collection.create_index([("email", "text")])
            print("    ✅ Índices de seguridad creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de seguridad: {e}")
        
        # ÍNDICES PARA PRODUCTOS
        print("  🛍️ Creando índices para productos...")
        try:
            products_collection.create_index("nombre")
            products_collection.create_index("categoria")
            products_collection.create_index("precio")
            products_collection.create_index("stock")
            print("    ✅ Índices de productos creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de productos: {e}")
        
        # ÍNDICES PARA PEDIDOS
        print("  📦 Creando índices para pedidos...")
        try:
            orders_collection.create_index("cliente_correo")
            orders_collection.create_index("estado")
            orders_collection.create_index("fecha", -1)  # Orden descendente
            print("    ✅ Índices de pedidos creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de pedidos: {e}")
        
        # ÍNDICES PARA REPARTIDORES
        print("  🚚 Creando índices para repartidores...")
        try:
            repartidores_collection.create_index("codigo")
            repartidores_collection.create_index("estado")
            repartidores_collection.create_index("zona")
            print("    ✅ Índices de repartidores creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de repartidores: {e}")
        
        # ÍNDICES PARA PAGOS
        print("  💰 Creando índices para pagos...")
        try:
            payments_collection.create_index("pedido_id")
            payments_collection.create_index("fecha", -1)
            payments_collection.create_index("metodo")
            print("    ✅ Índices de pagos creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de pagos: {e}")
        
        # ÍNDICES PARA CAJA
        print("  🏦 Creando índices para caja...")
        try:
            caja_collection.create_index("created_at", -1)
            print("    ✅ Índices de caja creados")
        except Exception as e:
            print(f"    ⚠️ Error con índices de caja: {e}")
        
        print("🎉 Índices creados (algunos podrían faltar debido a errores)")
        return True
        
    except Exception as e:
        print(f"❌ Error crítico creando índices: {e}")
        print("⚠️ Continuando sin índices...")
        return False

# ========== FUNCIÓN PARA AGREGAR DATOS DEMO ==========

def add_demo_data():
    """Agregar datos de demostración a MongoDB"""
    try:
        print("🔄 Cargando datos demo...")
        
        # Primero crear los índices (con manejo de errores)
        create_indexes()
        
        # VERIFICAR Y CREAR USUARIOS DEMO
        print("👥 Configurando usuarios demo...")
        
        # Lista de usuarios demo esenciales
        usuarios_demo = [
            {
                "nombre": "Cliente Demo",
                "correo": "cliente@lacavadelvalle.cl",
                "contraseña": "cliente123",
                "rol": "Cliente",
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "activo": True,
                "ultimo_login": None
            },
            {
                "nombre": "Admin Demo",
                "correo": "admin@lacavadelvalle.cl", 
                "contraseña": "admin123",
                "rol": "Administrador",
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "activo": True,
                "ultimo_login": None
            },
            {
                "nombre": "Dueño Demo", 
                "correo": "dueno@lacavadelvalle.cl",
                "contraseña": "dueno123",
                "rol": "Dueño",
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "activo": True,
                "ultimo_login": None
            }
        ]
        
        # Insertar usuarios solo si no existen
        usuarios_creados = 0
        for usuario in usuarios_demo:
            correo = usuario["correo"].lower()
            # Verificar si ya existe
            existe = users_collection.find_one({"correo": correo})
            if not existe:
                try:
                    users_collection.insert_one(usuario)
                    usuarios_creados += 1
                    print(f"    ✅ {usuario['nombre']} creado")
                except Exception as e:
                    print(f"    ⚠️ Error creando {usuario['nombre']}: {e}")
            else:
                print(f"    ℹ️  {usuario['nombre']} ya existe")
        
        print(f"    📊 Usuarios: {usuarios_creados} nuevos, {users_collection.count_documents({})} total")
        
        # VERIFICAR Y CREAR PRODUCTOS DEMO
        print("🛍️ Configurando productos demo...")
        if products_collection.count_documents({}) == 0:
            productos_demo = [
                {
                    "nombre": "Queso de Cabra Ahumado",
                    "descripcion": "Queso artesanal fresco de cabra con ahumado natural",
                    "categoria": "Fresco",
                    "precio": 8500,
                    "stock": 15,
                    "disponible": True,
                    "imagen_url": "/images/cabra-ahumado.jpg",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "nombre": "Queso Mantecoso Artesanal",
                    "descripcion": "Queso cremoso de leche entera, ideal para untar",
                    "categoria": "Suave",
                    "precio": 7200,
                    "stock": 20,
                    "disponible": True,
                    "imagen_url": "/images/mantecoso.jpg",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "nombre": "Queso Azul Madurado",
                    "descripcion": "Queso curado con vetas azules naturales, intenso sabor",
                    "categoria": "Curado",
                    "precio": 12500,
                    "stock": 8,
                    "disponible": True,
                    "imagen_url": "/images/azul-madurado.jpg",
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            products_collection.insert_many(productos_demo)
            print("    ✅ Productos demo creados")
        else:
            print(f"    ℹ️  Productos ya existen ({products_collection.count_documents({})})")

        # VERIFICAR Y CREAR REPARTIDORES DEMO
        print("🚚 Configurando repartidores demo...")
        if repartidores_collection.count_documents({}) == 0:
            repartidores_demo = [
                {
                    "nombre": "Juan Pérez",
                    "codigo": "R001",
                    "email": "juan@lacavadelvalle.cl",
                    "telefono": "+56912345678",
                    "estado": "disponible",
                    "zona": "Norte",
                    "capacidad_maxima": 5,
                    "pedidos_asignados": [],
                    "activo": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "nombre": "María González",
                    "codigo": "R002", 
                    "email": "maria@lacavadelvalle.cl",
                    "telefono": "+56987654321",
                    "estado": "disponible",
                    "zona": "Sur",
                    "capacidad_maxima": 4,
                    "pedidos_asignados": [],
                    "activo": True,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            repartidores_collection.insert_many(repartidores_demo)
            print("    ✅ Repartidores demo creados")
        else:
            print(f"    ℹ️  Repartidores ya existen ({repartidores_collection.count_documents({})})")

        # VERIFICAR Y CREAR CAJA INICIAL
        print("💰 Configurando caja virtual...")
        if caja_collection.count_documents({}) == 0:
            caja_inicial = {
                "saldo_actual": 150000,
                "ultima_actualizacion": datetime.utcnow(),
                "created_at": datetime.utcnow(),
                "updated_at": datetime.utcnow(),
                "ventas_registradas": 0,
                "total_ingresos": 150000,
                "total_egresos": 0,
                "movimientos": []
            }
            caja_collection.insert_one(caja_inicial)
            print("    ✅ Caja virtual inicializada")
        else:
            print(f"    ℹ️  Caja virtual ya existe")

        # LIMPIAR INTENTOS FALLIDOS ANTIGUOS
        print("🧹 Limpiando intentos fallidos antiguos...")
        try:
            yesterday = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
            delete_result = failed_attempts_collection.delete_many({
                "last_attempt": {"$lt": yesterday}
            })
            
            if delete_result.deleted_count > 0:
                print(f"    ✅ {delete_result.deleted_count} registros antiguos eliminados")
        except Exception as e:
            print(f"    ⚠️ Error limpiando intentos fallidos: {e}")

        # ESTADO FINAL
        print("\n📊 ESTADO FINAL DE LA BASE DE DATOS:")
        print(f"   👥 Usuarios: {users_collection.count_documents({})}")
        print(f"   🛍️  Productos: {products_collection.count_documents({})}")
        print(f"   🚚 Repartidores: {repartidores_collection.count_documents({})}")
        print(f"   📦 Pedidos: {orders_collection.count_documents({})}")
        print(f"   💳 Pagos: {payments_collection.count_documents({})}")
        print(f"   💰 Caja: {caja_collection.count_documents({})}")
        print(f"   🔒 Intentos fallidos: {failed_attempts_collection.count_documents({})}")

        print("✅ Datos demo cargados exitosamente")
        return True
        
    except Exception as e:
        print(f"❌ Error cargando datos demo: {e}")
        import traceback
        traceback.print_exc()
        return False

# ========== ALIAS PARA COMPATIBILIDAD ==========
# Para mantener compatibilidad con main.py
populate_demo_data = add_demo_data

# ========== FUNCIONES ADICIONALES ==========

def reset_database():
    """Función para resetear completamente la base de datos"""
    try:
        print("🔄 Reiniciando base de datos...")
        
        # Limpiar todas las colecciones
        users_collection.delete_many({})
        products_collection.delete_many({})
        orders_collection.delete_many({})
        payments_collection.delete_many({})
        caja_collection.delete_many({})
        order_items_collection.delete_many({})
        repartidores_collection.delete_many({})
        failed_attempts_collection.delete_many({})
        
        print("✅ Base de datos limpiada")
        
        # Volver a cargar datos demo
        add_demo_data()
        
    except Exception as e:
        print(f"❌ Error reiniciando base de datos: {e}")

def get_database_info():
    """Obtener información del estado de la base de datos"""
    try:
        info = {
            "usuarios": users_collection.count_documents({}),
            "productos": products_collection.count_documents({}),
            "repartidores": repartidores_collection.count_documents({}),
            "pedidos": orders_collection.count_documents({}),
            "pagos": payments_collection.count_documents({}),
            "caja": caja_collection.count_documents({}),
            "intentos_fallidos": failed_attempts_collection.count_documents({}),
            "bloqueados_actualmente": failed_attempts_collection.count_documents({
                "blocked_until": {"$gt": datetime.utcnow()}
            }),
            "timestamp": datetime.utcnow().isoformat()
        }
        
        return info
    except Exception as e:
        print(f"❌ Error obteniendo información de BD: {e}")
        return {}

def cleanup_old_data(days=7):
    """Limpiar datos antiguos de la base de datos"""
    try:
        print(f"🧹 Limpiando datos con más de {days} días...")
        
        cutoff_date = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
        cutoff_date = cutoff_date.replace(day=cutoff_date.day - days)
        
        # Limpiar intentos fallidos antiguos
        failed_deleted = failed_attempts_collection.delete_many({
            "last_attempt": {"$lt": cutoff_date}
        })
        
        print(f"✅ {failed_deleted.deleted_count} registros de intentos fallidos eliminados")
        
        return {
            "failed_attempts_deleted": failed_deleted.deleted_count,
            "cutoff_date": cutoff_date.isoformat()
        }
        
    except Exception as e:
        print(f"Error limpiando datos: {e}")
        return {"error": str(e)}

def remove_duplicate_users():
    """Eliminar usuarios duplicados por correo"""
    try:
        print("🔍 Buscando usuarios duplicados...")
        
        pipeline = [
            {"$group": {
                "_id": "$correo",
                "count": {"$sum": 1},
                "ids": {"$push": "$_id"}
            }},
            {"$match": {"count": {"$gt": 1}}}
        ]
        
        duplicates = list(users_collection.aggregate(pipeline))
        
        if not duplicates:
            print("✅ No hay usuarios duplicados")
            return 0
            
        deleted_count = 0
        for dup in duplicates:
            correo = dup["_id"]
            ids = dup["ids"]
            
            # Mantener el primero, eliminar los demás
            keep_id = ids[0]
            delete_ids = ids[1:]
            
            print(f"  ⚠️ Correo duplicado: {correo} ({len(ids)} veces)")
            
            result = users_collection.delete_many({"_id": {"$in": delete_ids}})
            deleted_count += result.deleted_count
            print(f"    🗑️  Eliminados: {result.deleted_count} duplicados")
        
        print(f"✅ Total eliminados: {deleted_count} usuarios duplicados")
        return deleted_count
        
    except Exception as e:
        print(f"❌ Error eliminando duplicados: {e}")
        return 0

# ========== INICIALIZACIÓN AUTOMÁTICA ==========

if __name__ == "__main__":
    print("=== DATABASE MONGO DB ===")
    print("Opciones:")
    print("1. add_demo_data() - Cargar datos demo con índices")
    print("2. reset_database() - Reiniciar BD completa") 
    print("3. get_database_info() - Ver estado de BD")
    print("4. create_indexes() - Solo crear índices")
    print("5. remove_duplicate_users() - Eliminar usuarios duplicados")
    print("6. cleanup_old_data(days=7) - Limpiar datos antiguos")
    
    # Primero eliminar duplicados
    remove_duplicate_users()
    
    # Luego cargar datos demo
    add_demo_data()