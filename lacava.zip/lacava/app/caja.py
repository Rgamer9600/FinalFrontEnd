# caja.py - VERSIÓN MONGODB
from fastapi import APIRouter, HTTPException
from database_mongo import caja_collection, orders_collection, payments_collection
from datetime import datetime
from bson import ObjectId

router = APIRouter(prefix="/caja", tags=["Caja Virtual"])

@router.post("/registrar_venta/")
def registrar_venta(pedido_id: str):
    if not ObjectId.is_valid(pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    pedido = orders_collection.find_one({"_id": ObjectId(pedido_id)})
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")

    pago = payments_collection.find_one({"pedido_id": pedido_id})
    if not pago or pago["estado"] != "exitoso":
        raise HTTPException(status_code=400, detail="Pago no válido o no completado")

    # Obtener o crear registro de caja
    caja = caja_collection.find_one({})
    if not caja:
        caja_data = {
            "saldo_actual": pago["monto"],
            "ultima_actualizacion": datetime.utcnow(),
            "created_at": datetime.utcnow()
        }
        caja_collection.insert_one(caja_data)
    else:
        caja_collection.update_one(
            {},
            {"$inc": {"saldo_actual": pago["monto"]}, "$set": {"ultima_actualizacion": datetime.utcnow()}}
        )

    nuevo_saldo = caja["saldo_actual"] + pago["monto"] if caja else pago["monto"]
    
    return {
        "mensaje": "Venta registrada correctamente", 
        "monto_agregado": pago["monto"],
        "nuevo_saldo": nuevo_saldo
    }

@router.get("/saldo/")
def obtener_saldo():
    caja = caja_collection.find_one({})
    if not caja:
        raise HTTPException(status_code=404, detail="Caja no encontrada")
    
    return {
        "saldo_actual": caja["saldo_actual"], 
        "ultima_actualizacion": caja["ultima_actualizacion"]
    }