# pedidos.py - VERSIÓN MONGODB
from fastapi import APIRouter, HTTPException
from database_mongo import orders_collection, products_collection, users_collection, order_items_collection
from datetime import datetime
from bson import ObjectId
from pydantic import BaseModel
from typing import List, Optional

router = APIRouter(prefix="/pedidos", tags=["Pedidos"])

class ItemPedido(BaseModel):
    producto_id: str
    cantidad: int

# En pedidos.py, modificar la clase CrearPedido
class CrearPedido(BaseModel):
    cliente_correo: str
    items: List[ItemPedido]
    tipo_entrega: str = "delivery"  # "delivery" o "retiro"
    direccion_entrega: Optional[str] = None
    

@router.post("/crear/")
def crear_pedido(pedido: CrearPedido):
    # Verificar que el cliente existe
    cliente = users_collection.find_one({"correo": pedido.cliente_correo})
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")

    total = 0
    items_detalle = []
    
    # Procesar cada item del pedido
    for item in pedido.items:
        if not ObjectId.is_valid(item.producto_id):
            raise HTTPException(status_code=400, detail=f"ID de producto inválido: {item.producto_id}")
        
        producto = products_collection.find_one({"_id": ObjectId(item.producto_id)})
        if not producto:
            raise HTTPException(status_code=404, detail=f"Producto no encontrado: {item.producto_id}")
        
        if producto["stock"] < item.cantidad:
            raise HTTPException(status_code=400, detail=f"Stock insuficiente para {producto['nombre']}")
        
        # Actualizar stock
        products_collection.update_one(
            {"_id": ObjectId(item.producto_id)},
            {"$inc": {"stock": -item.cantidad}}
        )
        
        subtotal = producto["precio"] * item.cantidad
        total += subtotal
        
        items_detalle.append({
            "producto_id": item.producto_id,
            "nombre": producto["nombre"],
            "precio": producto["precio"],
            "cantidad": item.cantidad,
            "subtotal": subtotal
        })

    # Crear pedido
    nuevo_pedido = {
        "cliente_correo": pedido.cliente_correo,
        "items": items_detalle,
        "total": total,
        "estado": "pendiente",
        "tipo_entrega": pedido.tipo_entrega,
        "direccion_entrega": pedido.direccion_entrega if pedido.tipo_entrega == "delivery" else "Retiro en local",
        "created_at": datetime.utcnow()
    }
    
    result = orders_collection.insert_one(nuevo_pedido)

    pedido_id_str = str(result.inserted_id)
    
    return {
        "mensaje": "Pedido creado exitosamente", 
        "pedido_id": str(result.inserted_id), 
        "_id": pedido_id_str,        
        "total": total
    }

@router.get("/listar/")
def listar_pedidos():
    pedidos = list(orders_collection.find({}))
    
    # CORREGIDO: Convertir _id a string y asegurar consistencia
    for pedido in pedidos:
        pedido["_id"] = str(pedido["_id"])  # Convertir a string
        if "id" not in pedido:
            pedido["id"] = pedido["_id"]  # Crear campo id si no existe
    
    return pedidos

@router.put("/anular/{pedido_id}")
def anular_pedido(pedido_id: str, motivo: str):
    if not ObjectId.is_valid(pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    pedido = orders_collection.find_one({"_id": ObjectId(pedido_id)})
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")

    if pedido["estado"] != "pendiente":
        raise HTTPException(status_code=400, detail="No se puede anular este pedido")

    if not motivo.strip():
        raise HTTPException(status_code=400, detail="Debe ingresar un motivo para anular")

    # Restaurar stock de productos
    for item in pedido["items"]:
        products_collection.update_one(
            {"_id": ObjectId(item["producto_id"])},
            {"$inc": {"stock": item["cantidad"]}}
        )

    # Actualizar estado del pedido
    orders_collection.update_one(
        {"_id": ObjectId(pedido_id)},
        {"$set": {"estado": "anulado", "motivo_anulacion": motivo}}
    )

    return {"mensaje": "Pedido anulado correctamente"}

@router.get("/detalle/{pedido_id}")
def detalle_pedido(pedido_id: str):
    if not ObjectId.is_valid(pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    pedido = orders_collection.find_one({"_id": ObjectId(pedido_id)}, {"_id": 0})
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")
    
    return pedido