# pagos.py - VERSIÓN MONGODB
from fastapi import APIRouter, HTTPException
from database_mongo import payments_collection, orders_collection
from datetime import datetime
from bson import ObjectId
from pydantic import BaseModel

router = APIRouter(prefix="/pagos", tags=["Pagos"])

class PagoData(BaseModel):
    pedido_id: str
    metodo: str
    monto: float

@router.post("/procesar/")
def procesar_pago(pago: PagoData):
    # Verificar pedido
    if not ObjectId.is_valid(pago.pedido_id):
        raise HTTPException(status_code=400, detail="ID de pedido inválido")
    
    pedido = orders_collection.find_one({"_id": ObjectId(pago.pedido_id)})
    if not pedido:
        raise HTTPException(status_code=404, detail="Pedido no encontrado")

    if pago.monto <= 0:
        raise HTTPException(status_code=400, detail="Monto inválido")

    if pago.metodo not in ["tarjeta", "transferencia", "efectivo"]:
        raise HTTPException(status_code=400, detail="Método de pago no soportado")

    # Simular validación de pago
    if pago.monto > 50000:
        estado = "rechazado"
        mensaje = "Pago no válido - monto muy alto"
    else:
        estado = "exitoso"
        mensaje = "Pago procesado correctamente"
        
        # Actualizar estado del pedido
        orders_collection.update_one(
    {"_id": ObjectId(pago.pedido_id)},
    {"$set": {
        "estado": "pagado",
        "metodo_pago": pago.metodo  # Guardar el método de pago
    }}
)

    # Registrar pago
    nuevo_pago = {
        "pedido_id": pago.pedido_id,
        "metodo": pago.metodo,
        "monto": pago.monto,
        "estado": estado,
        "fecha": datetime.utcnow()
    }
    
    result = payments_collection.insert_one(nuevo_pago)
    
    return {
        "mensaje": mensaje, 
        "estado": estado, 
        "pago_id": str(result.inserted_id)
    }

@router.get("/listar/")
def listar_pagos():
    pagos = list(payments_collection.find({}, {"_id": 0}))
    return pagos