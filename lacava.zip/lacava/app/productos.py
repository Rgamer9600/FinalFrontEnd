# app/productos.py - CRUD completo de productos

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime
from bson.objectid import ObjectId
from database_mongo import db  # Asegúrate de importar tu conexión a MongoDB

router = APIRouter()

# Modelo Pydantic para Producto
class Producto(BaseModel):
    nombre: str
    descripcion: Optional[str] = None
    precio: float
    stock: int
    categoria: Optional[str] = None
    disponible: bool = True

# Modelo para actualización parcial
class ProductoUpdate(BaseModel):
    nombre: Optional[str] = None
    descripcion: Optional[str] = None
    precio: Optional[float] = None
    stock: Optional[int] = None
    categoria: Optional[str] = None
    disponible: Optional[bool] = None

# ========== ENDPOINTS ==========

# 1. Listar todos los productos
@router.get("/listar/")
async def listar_productos():
    """Obtener todos los productos"""
    try:
        productos = list(db.products.find().sort("nombre", 1))
        for p in productos:
            p["_id"] = str(p["_id"])
        return productos
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 2. Obtener un producto por ID
@router.get("/{producto_id}")
async def obtener_producto(producto_id: str):
    """Obtener un producto específico por ID"""
    try:
        if not ObjectId.is_valid(producto_id):
            raise HTTPException(status_code=400, detail="ID inválido")
            
        producto = db.products.find_one({"_id": ObjectId(producto_id)})
        if producto:
            producto["_id"] = str(producto["_id"])
            return producto
        else:
            raise HTTPException(status_code=404, detail="Producto no encontrado")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 3. Crear nuevo producto
@router.post("/agregar/")
async def agregar_producto(producto: Producto):
    """Agregar un nuevo producto"""
    try:
        # Validar datos
        if producto.precio <= 0:
            raise HTTPException(status_code=400, detail="El precio debe ser mayor a 0")
        if producto.stock < 0:
            raise HTTPException(status_code=400, detail="El stock no puede ser negativo")
        
        producto_dict = producto.dict()
        producto_dict["created_at"] = datetime.now()
        
        # Insertar en la base de datos
        result = db.products.insert_one(producto_dict)
        
        return {
            "mensaje": "Producto agregado correctamente",
            "producto_id": str(result.inserted_id),
            "producto": {
                "nombre": producto.nombre,
                "precio": producto.precio,
                "stock": producto.stock
            }
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 4. Actualizar producto completo
@router.put("/actualizar/{producto_id}")
async def actualizar_producto(producto_id: str, producto: Producto):
    """Actualizar un producto existente"""
    try:
        # Validar ID
        if not ObjectId.is_valid(producto_id):
            raise HTTPException(status_code=400, detail="ID inválido")
        
        # Validar datos
        if producto.precio <= 0:
            raise HTTPException(status_code=400, detail="El precio debe ser mayor a 0")
        if producto.stock < 0:
            raise HTTPException(status_code=400, detail="El stock no puede ser negativo")
        
        # Convertir a dict
        producto_dict = producto.dict()
        producto_dict["updated_at"] = datetime.now()
        
        # Verificar que el producto existe
        if not db.products.find_one({"_id": ObjectId(producto_id)}):
            raise HTTPException(status_code=404, detail="Producto no encontrado")
        
        # Actualizar en la base de datos
        result = db.products.update_one(
            {"_id": ObjectId(producto_id)},
            {"$set": producto_dict}
        )
        
        if result.modified_count == 1:
            return {
                "mensaje": "Producto actualizado correctamente",
                "producto_id": producto_id,
                "producto": {
                    "nombre": producto.nombre,
                    "precio": producto.precio,
                    "stock": producto.stock
                }
            }
        else:
            raise HTTPException(status_code=400, detail="No se pudo actualizar el producto")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 5. Actualizar producto parcialmente
@router.patch("/actualizar-parcial/{producto_id}")
async def actualizar_producto_parcial(producto_id: str, producto: ProductoUpdate):
    """Actualizar parcialmente un producto"""
    try:
        # Validar ID
        if not ObjectId.is_valid(producto_id):
            raise HTTPException(status_code=400, detail="ID inválido")
        
        # Filtrar campos None
        update_data = {k: v for k, v in producto.dict().items() if v is not None}
        
        if not update_data:
            raise HTTPException(status_code=400, detail="No hay datos para actualizar")
        
        # Validaciones específicas
        if "precio" in update_data and update_data["precio"] <= 0:
            raise HTTPException(status_code=400, detail="El precio debe ser mayor a 0")
        
        if "stock" in update_data and update_data["stock"] < 0:
            raise HTTPException(status_code=400, detail="El stock no puede ser negativo")
        
        update_data["updated_at"] = datetime.now()
        
        # Verificar que el producto existe
        if not db.products.find_one({"_id": ObjectId(producto_id)}):
            raise HTTPException(status_code=404, detail="Producto no encontrado")
        
        # Actualizar en la base de datos
        result = db.products.update_one(
            {"_id": ObjectId(producto_id)},
            {"$set": update_data}
        )
        
        if result.modified_count == 1:
            return {
                "mensaje": "Producto actualizado parcialmente",
                "producto_id": producto_id,
                "campos_actualizados": list(update_data.keys())
            }
        else:
            raise HTTPException(status_code=400, detail="No se pudo actualizar el producto")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 6. Eliminar producto
@router.delete("/eliminar/{producto_id}")
async def eliminar_producto(producto_id: str):
    """Eliminar un producto"""
    try:
        # Validar ID
        if not ObjectId.is_valid(producto_id):
            raise HTTPException(status_code=400, detail="ID inválido")
        
        # Verificar que el producto existe
        producto = db.products.find_one({"_id": ObjectId(producto_id)})
        if not producto:
            raise HTTPException(status_code=404, detail="Producto no encontrado")
        
        # Opcional: Verificar si el producto tiene pedidos asociados
        # pedidos_con_producto = db.pedidos.count_documents({
        #     "items.producto_id": producto_id
        # })
        # if pedidos_con_producto > 0:
        #     raise HTTPException(
        #         status_code=400, 
        #         detail=f"No se puede eliminar, hay {pedidos_con_producto} pedidos con este producto"
        #     )
        
        # Eliminar de la base de datos
        result = db.products.delete_one({"_id": ObjectId(producto_id)})
        
        if result.deleted_count == 1:
            return {
                "mensaje": "Producto eliminado correctamente",
                "producto_id": producto_id,
                "producto_nombre": producto.get("nombre", "N/A")
            }
        else:
            raise HTTPException(status_code=400, detail="No se pudo eliminar el producto")
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 7. Buscar productos
@router.get("/buscar/{termino}")
async def buscar_productos(termino: str):
    """Buscar productos por nombre o descripción"""
    try:
        query = {
            "$or": [
                {"nombre": {"$regex": termino, "$options": "i"}},
                {"descripcion": {"$regex": termino, "$options": "i"}},
                {"categoria": {"$regex": termino, "$options": "i"}}
            ]
        }
        
        productos = list(db.products.find(query).sort("nombre", 1))
        for p in productos:
            p["_id"] = str(p["_id"])
        
        return {
            "termino": termino,
            "resultados": len(productos),
            "productos": productos
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")

# 8. Productos por categoría
@router.get("/categoria/{categoria}")
async def productos_por_categoria(categoria: str):
    """Obtener productos por categoría"""
    try:
        productos = list(db.products.find({"categoria": categoria}).sort("nombre", 1))
        for p in productos:
            p["_id"] = str(p["_id"])
        
        return {
            "categoria": categoria,
            "total": len(productos),
            "productos": productos
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error: {str(e)}")