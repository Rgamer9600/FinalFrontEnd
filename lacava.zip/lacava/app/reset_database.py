# reset_database.py - Script para resetear la base de datos
from database_mongo import reset_database, get_database_info

def main():
    print("🔄 INICIANDO RESET DE BASE DE DATOS")
    print("=" * 50)
    
    # Mostrar estado actual
    print("Estado actual de la base de datos:")
    info = get_database_info()
    for key, value in info.items():
        if key != "lista_usuarios":
            print(f"   {key}: {value}")
    
    # Confirmar reset
    confirm = input("\n¿Estás seguro de que quieres resetear la base de datos? (s/n): ")
    
    if confirm.lower() == 's':
        print("\n🔄 Reiniciando base de datos...")
        reset_database()
        print("\n✅ Base de datos reiniciada exitosamente!")
        
        # Mostrar nuevo estado
        print("\nNuevo estado de la base de datos:")
        new_info = get_database_info()
        for key, value in new_info.items():
            if key != "lista_usuarios":
                print(f"   {key}: {value}")
                
        print("\n🎉 ¡Puedes iniciar sesión con:")
        print("   📧 cliente@lacavadelvalle.cl")
        print("   🔑 contraseña: cliente123")
        
    else:
        print("❌ Reset cancelado")

if __name__ == "__main__":
    main()