# test_mongo.py
from pymongo import MongoClient

try:
    client = MongoClient("mongodb://localhost:27017", serverSelectionTimeoutMS=5000)
    client.admin.command('ping')
    print("✅ MongoDB está corriendo correctamente")
    
    # Listar bases de datos
    dbs = client.list_database_names()
    print(f"📁 Bases de datos: {dbs}")
    
except Exception as e:
    print(f"❌ Error: {e}")
    print("💡 Soluciones posibles:")
    print("1. Iniciar MongoDB: net start MongoDB")
    print("2. Instalar MongoDB si no lo tienes")
    print("3. Verificar que el puerto 27017 esté libre")