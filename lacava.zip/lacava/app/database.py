from sqlmodel import SQLModel, Field, create_engine, Session, select
from typing import Optional
from datetime import datetime

DATABASE_URL = "sqlite:///./database.db"
engine = create_engine(DATABASE_URL, echo=False)

class UsuarioDB(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    email: str = Field(index=True)
    password: str
    role: str = "Cliente"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class ProductoDB(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    name: str
    description: Optional[str] = None
    category: str
    price: float
    stock: int
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PedidoDB(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    user_email: str
    product_name: str
    quantity: int
    total_price: float
    status: str = "Pendiente"
    cancel_reason: Optional[str] = None
    created_at: datetime = Field(default_factory=datetime.utcnow)

class PaymentDB(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int
    method: str
    amount: float
    status: str = "Pendiente"
    created_at: datetime = Field(default_factory=datetime.utcnow)

class CajaDB(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    saldo_actual: float = 0.0
    ultimo_movimiento: Optional[datetime] = None

def create_db_and_tables():
    SQLModel.metadata.create_all(engine)

def get_session():
    with Session(engine) as session:
        yield session

def add_demo_data():
    with Session(engine) as session:
        if not session.exec(select(UsuarioDB).where(UsuarioDB.email == "cliente@lacavadelvalle.cl")).first():
            u1 = UsuarioDB(name="Cliente Demo", email="cliente@lacavadelvalle.cl", password="cliente123", role="Cliente")
            u2 = UsuarioDB(name="Admin Demo", email="admin@lacavadelvalle.cl", password="admin123", role="Administrador")
            session.add_all([u1, u2])
        if not session.exec(select(ProductoDB)).first():
            p1 = ProductoDB(name="Queso de Cabra", description="Queso artesanal fresco", category="Fresco", price=4500, stock=20)
            p2 = ProductoDB(name="Queso Azul", description="Queso curado intenso", category="Curado", price=7200, stock=8)
            p3 = ProductoDB(name="Queso Curado", description="Queso maduro de oveja", category="Curado", price=5200, stock=12)
            session.add_all([p1, p2, p3])
        if not session.exec(select(CajaDB)).first():
            caja = CajaDB(saldo_actual=0.0, ultimo_movimiento=None)
            session.add(caja)
        session.commit()
