# main.py - VERSIÓN MONGODB
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from database_mongo import add_demo_data

# Importar routers
from usuarios import router as usuarios_router
from productos import router as productos_router
from pedidos import router as pedidos_router
from pagos import router as pagos_router
from caja import router as caja_router
from asignaciones import router as asignaciones_router
from database_mongo import create_indexes, add_demo_data

app = FastAPI(title="La Cava del Valle API", version="1.0")


app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
#python main.py para ejecutar la aplicacion

@app.on_event("startup")
def on_startup():
    add_demo_data()
    print("✓ MongoDB inicializado con datos demo")

# Incluir routers
app.include_router(usuarios_router)
app.include_router(productos_router)
app.include_router(pedidos_router)
app.include_router(pagos_router)
app.include_router(caja_router)
app.include_router(asignaciones_router)
app.include_router(usuarios_router)

@app.get("/")
def home():
    return {"mensaje": "Bienvenido a La Cava del Valle API - MongoDB"}

@app.get("/routes")
def list_routes():
    routes = []
    for route in app.routes:
        if hasattr(route, 'path'):
            routes.append({
                "path": route.path,
                "methods": list(route.methods) if hasattr(route, 'methods') else []
            })
    return routes