from database_mongo import orders_collection
from datetime import datetime

# Crear pedido de prueba
pedido_test = {
    "cliente_correo": "cliente@lacavadelvalle.cl",
    "items": [
        {
            "producto_id": "692793a314f06a4e7043d0cc",
            "nombre": "Queso de Cabra Ahumado",
            "precio": 8000,
            "cantidad": 1,
            "subtotal": 8000
        },
        {
            "producto_id": "692793a314f06a4e7043d0cd",
            "nombre": "Queso Mantecoso Artesanal", 
            "precio": 6500,
            "cantidad": 2,
            "subtotal": 13000
        }
    ],
    "total": 21000,
    "estado": "pendiente",
    "created_at": datetime.utcnow()
}

result = orders_collection.insert_one(pedido_test)
print(f"✅ Pedido de prueba creado con ID: {result.inserted_id}")