from fastapi import APIRouter, HTTPException
from sqlmodel import Session, select, func
from database import engine
from models import Venta
from datetime import date

router = APIRouter(prefix="/reportes", tags=["Reportes"])

@router.get("/diario/")
def reporte_diario(fecha: date):
    with Session(engine) as session:
        ventas = session.exec(select(Venta).where(func.date(Venta.fecha) == fecha)).all()
        if not ventas:
            raise HTTPException(status_code=404, detail="No hay ventas para esta fecha")

        total = sum(v.monto_total for v in ventas)
        return {"fecha": fecha, "total_ventas": total, "num_pedidos": len(ventas)}

@router.get("/semanal/")
def reporte_semanal(semana: int, año: int):
    with Session(engine) as session:
        ventas = session.exec(select(Venta).all())
        ventas_semana = [
            v for v in ventas if v.fecha.isocalendar()[1] == semana and v.fecha.year == año
        ]
        if not ventas_semana:
            raise HTTPException(status_code=404, detail="No hay ventas para esta semana")

        total = sum(v.monto_total for v in ventas_semana)
        return {"semana": semana, "año": año, "total_ventas": total, "num_pedidos": len(ventas_semana)}

@router.get("/mensual/")
def reporte_mensual(mes: int, año: int):
    with Session(engine) as session:
        ventas = session.exec(
            select(Venta).where(
                func.strftime("%m", Venta.fecha) == f"{mes:02d}",
                func.strftime("%Y", Venta.fecha) == str(año)
            )
        ).all()

        if not ventas:
            raise HTTPException(status_code=404, detail="No hay ventas para este mes")

        total = sum(v.monto_total for v in ventas)
        return {"mes": mes, "año": año, "total_ventas": total, "num_pedidos": len(ventas)}
