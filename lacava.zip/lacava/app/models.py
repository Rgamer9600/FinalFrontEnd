from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, List
from datetime import datetime

class Usuario(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str
    correo: str
    contraseña: str
    rol: str = "Cliente"
    pedidos: List["Pedido"] = Relationship(back_populates="cliente")

class Producto(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    nombre: str
    descripcion: str
    categoria: str
    precio: float
    stock: int
    pedidos: List["PedidoProducto"] = Relationship(back_populates="producto")

class Pedido(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    cliente_id: int = Field(foreign_key="usuario.id")
    fecha: datetime = Field(default_factory=datetime.utcnow)
    total: float
    estado: str = "Pendiente"
    cliente: Optional[Usuario] = Relationship(back_populates="pedidos")
    productos: List["PedidoProducto"] = Relationship(back_populates="pedido")
    pago: Optional["Pago"] = Relationship(back_populates="pedido")

class PedidoProducto(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    pedido_id: int = Field(foreign_key="pedido.id")
    producto_id: int = Field(foreign_key="producto.id")
    cantidad: int

    pedido: Optional[Pedido] = Relationship(back_populates="productos")
    producto: Optional[Producto] = Relationship(back_populates="pedidos")

class Pago(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    pedido_id: int = Field(foreign_key="pedido.id")
    metodo: str
    monto: float
    estado: str
    fecha: datetime = Field(default_factory=datetime.utcnow)
    pedido: Optional[Pedido] = Relationship(back_populates="pago")

class CajaVirtual(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    monto_total: float = 0
    ultima_actualizacion: datetime = Field(default_factory=datetime.utcnow)
