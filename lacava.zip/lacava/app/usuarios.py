# usuarios.py - VERSIÓN CORREGIDA SIN DUPLICADOS
from fastapi import APIRouter, HTTPException, Request
from database_mongo import users_collection, failed_attempts_collection
from datetime import datetime, timedelta
from bson import ObjectId
from pydantic import BaseModel
from typing import Optional
import json
import time

# ========== DEFINICIÓN DEL ROUTER ==========
router = APIRouter(prefix="/usuarios", tags=["Usuarios"])

# ========== MODELOS PYDANTIC ==========

class Usuario(BaseModel):
    nombre: str
    correo: str
    contraseña: str
    rol: str = "Cliente"

class LoginRequest(BaseModel):
    email: str
    password: str

class UsuarioUpdate(BaseModel):
    nombre: Optional[str] = None
    rol: Optional[str] = None
    contraseña: Optional[str] = None

class RecoveryRequest(BaseModel):
    email: str

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str
    confirm_password: str

# ========== CONSTANTES DE SEGURIDAD ==========
MAX_FAILED_ATTEMPTS = 5
BLOCK_TIME_MINUTES = 0.17  # 10 segundos (0.17 minutos)

# ========== VARIABLES GLOBALES ==========
recovery_tokens = {}

# ========== FUNCIONES AUXILIARES ==========

def get_available_emails():
    """
    Obtiene lista de correos disponibles (para debugging).
    """
    try:
        usuarios = list(users_collection.find({}, {"correo": 1}))
        return [usuario["correo"] for usuario in usuarios if "correo" in usuario]
    except:
        return []

def get_features_by_role(rol: str):
    """
    Devuelve las características disponibles según el rol.
    """
    features = {
        "Cliente": [
            "Ver catálogo de productos",
            "Realizar pedidos",
            "Ver historial de pedidos",
            "Anular pedidos propios"
        ],
        "Administrador": [
            "Todas las funciones de Cliente",
            "Ver todos los pedidos del sistema",
            "Gestionar órdenes de despacho",
            "Acceder a caja virtual",
            "Generar reportes",
            "Gestionar productos"
        ],
        "Dueño": [
            "Todas las funciones de Administrador",
            "Gestión completa de usuarios",
            "Acceso a estadísticas avanzadas",
            "Configuración del sistema"
        ]
    }
    
    return features.get(rol, features["Cliente"])

def check_if_blocked(email: str):
    """
    Verifica si un email está bloqueado por intentos fallidos
    """
    try:
        email = email.lower().strip()
        
        # Buscar intentos fallidos recientes
        block_record = failed_attempts_collection.find_one({
            "email": email,
            "blocked_until": {"$gt": datetime.utcnow()}
        })
        
        if block_record:
            # Calcular tiempo restante
            time_left = block_record["blocked_until"] - datetime.utcnow()
            seconds_left = int(time_left.total_seconds())
            
            return {
                "blocked": True,
                "blocked_until": block_record["blocked_until"],
                "seconds_left": seconds_left,
                "attempts": block_record.get("attempt_count", 0)
            }
        
        return {"blocked": False}
        
    except Exception as e:
        print(f"Error verificando bloqueo: {e}")
        return {"blocked": False}

def record_failed_attempt(email: str, ip_address: str = None):
    """
    Registra un intento fallido
    """
    try:
        email = email.lower().strip()
        now = datetime.utcnow()
        
        # Buscar intentos fallidos existentes
        attempt_record = failed_attempts_collection.find_one({"email": email})
        
        if attempt_record:
            # Incrementar contador
            new_count = attempt_record.get("attempt_count", 0) + 1
            last_attempt = attempt_record.get("last_attempt", now)
            
            # Verificar si superó el límite
            if new_count >= MAX_FAILED_ATTEMPTS:
                blocked_until = now + timedelta(minutes=BLOCK_TIME_MINUTES)
                
                failed_attempts_collection.update_one(
                    {"email": email},
                    {"$set": {
                        "attempt_count": new_count,
                        "last_attempt": now,
                        "blocked_until": blocked_until,
                        "blocked_at": now,
                        "ip_address": ip_address,
                        "updated_at": now
                    }}
                )
                
                print(f"🚨 Usuario bloqueado: {email} hasta {blocked_until}")
                return {
                    "blocked": True,
                    "attempts": new_count,
                    "blocked_until": blocked_until
                }
            else:
                # Solo incrementar contador
                failed_attempts_collection.update_one(
                    {"email": email},
                    {"$set": {
                        "attempt_count": new_count,
                        "last_attempt": now,
                        "updated_at": now
                    }}
                )
                
                print(f"⚠️ Intento fallido #{new_count} para: {email}")
                return {
                    "blocked": False,
                    "attempts": new_count,
                    "remaining_attempts": MAX_FAILED_ATTEMPTS - new_count
                }
        else:
            # Primer intento fallido
            failed_attempts_collection.insert_one({
                "email": email,
                "attempt_count": 1,
                "last_attempt": now,
                "first_attempt": now,
                "ip_address": ip_address,
                "created_at": now,
                "updated_at": now
            })
            
            print(f"⚠️ Primer intento fallido para: {email}")
            return {
                "blocked": False,
                "attempts": 1,
                "remaining_attempts": MAX_FAILED_ATTEMPTS - 1
            }
            
    except Exception as e:
        print(f"Error registrando intento fallido: {e}")
        return {"error": str(e)}

def reset_failed_attempts(email: str):
    """
    Reinicia los intentos fallidos (después de un login exitoso)
    """
    try:
        email = email.lower().strip()
        
        result = failed_attempts_collection.delete_one({"email": email})
        
        if result.deleted_count > 0:
            print(f"✅ Intentos fallidos reiniciados para: {email}")
        
        return result.deleted_count > 0
        
    except Exception as e:
        print(f"Error reiniciando intentos fallidos: {e}")
        return False

# ========== ENDPOINT PRINCIPAL DE LOGIN ==========

@router.post("/login")
async def login_usuario(login_data: LoginRequest, request: Request):
    """
    Endpoint principal de login con sistema de bloqueo
    """
    try:
        email = login_data.email.strip().lower()
        password = login_data.password
        
        print(f"🔐 Intento de login para: {email}")
        
        # 1. Verificar si está bloqueado
        block_status = check_if_blocked(email)
        
        if block_status["blocked"]:
            print(f"🚫 Usuario bloqueado: {email}")
            
            raise HTTPException(
                status_code=429,  # Too Many Requests
                detail={
                    "error_type": "ACCOUNT_BLOCKED",
                    "message": "Cuenta temporalmente bloqueada por demasiados intentos fallidos.",
                    "blocked_until": block_status["blocked_until"].isoformat(),
                    "seconds_left": block_status["seconds_left"],
                    "attempts": block_status["attempts"],
                    "suggestion": f"Intenta nuevamente en {block_status['seconds_left']} segundos."
                }
            )
        
        # 2. Buscar usuario
        usuario = users_collection.find_one({
            "correo": {"$regex": f"^{email}$", "$options": "i"}
        })
        
        if not usuario:
            print(f"❌ Usuario no encontrado: {email}")
            
            raise HTTPException(
                status_code=404,
                detail={
                    "error_type": "EMAIL_NOT_FOUND",
                    "message": f"El correo {email} no está registrado.",
                    "suggestion": "Verifica tu correo o regístrate como nuevo usuario."
                }
            )
        
        # 3. Verificar contraseña
        if usuario.get("contraseña") != password:
            print(f"❌ Contraseña incorrecta para: {email}")
            
            # Obtener IP del cliente
            ip_address = request.client.host if request.client else "unknown"
            
            # Registrar intento fallido
            attempt_result = record_failed_attempt(email, ip_address)
            
            # Preparar mensaje de error
            error_detail = {
                "error_type": "INVALID_PASSWORD",
                "message": "Contraseña incorrecta.",
                "attempts": attempt_result.get("attempts", 1),
                "remaining_attempts": attempt_result.get("remaining_attempts", 4)  # 5-1
            }
            
            # Si el usuario fue bloqueado en este intento
            if attempt_result.get("blocked"):
                error_detail.update({
                    "error_type": "ACCOUNT_BLOCKED",
                    "message": "Demasiados intentos fallidos. Cuenta bloqueada por 10 segundos.",
                    "blocked_until": attempt_result["blocked_until"].isoformat(),
                    "seconds_left": int((attempt_result["blocked_until"] - datetime.utcnow()).total_seconds()),
                    "suggestion": "Por seguridad, tu cuenta ha sido bloqueada temporalmente. Intenta nuevamente en 10 segundos."
                })
            else:
                error_detail["suggestion"] = f"Te quedan {error_detail['remaining_attempts']} intentos antes del bloqueo."
            
            raise HTTPException(
                status_code=401 if not attempt_result.get("blocked") else 429,
                detail=error_detail
            )
        
        # 4. Login exitoso - Reiniciar intentos fallidos
        reset_failed_attempts(email)
        
        # Actualizar último login
        users_collection.update_one(
            {"_id": usuario["_id"]},
            {"$set": {"ultimo_login": datetime.utcnow()}}
        )
        
        print(f"✅ Login exitoso para: {email}")
        
        return {
            "success": True,
            "user_id": str(usuario["_id"]),
            "email": usuario["correo"],
            "nombre": usuario.get("nombre", ""),
            "rol": usuario.get("rol", "Cliente"),
            "message": "¡Bienvenido a La Cava del Valle!",
            "features": get_features_by_role(usuario.get("rol", "Cliente")),
            "security": {
                "failed_attempts_reset": True,
                "last_login": datetime.utcnow().isoformat()
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"🔥 Error en login: {str(e)}")
        import traceback
        traceback.print_exc()
        
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "INTERNAL_SERVER_ERROR",
                "message": "Error interno del servidor. Intente nuevamente."
            }
        )

# ========== ENDPOINTS DE RECUPERACIÓN DE CONTRASEÑA ==========

@router.post("/password-recovery/request")
async def request_password_recovery(request: RecoveryRequest):
    """
    Endpoint MOCK para solicitar recuperación de contraseña
    """
    email = request.email.lower().strip()
    
    print(f"📧 Solicitud de recuperación para: {email}")
    
    # Generar token simulado
    import secrets
    token = f"demo_token_{secrets.token_hex(8)}"
    
    # Guardar token simulado (24 horas de validez)
    recovery_tokens[token] = {
        "email": email,
        "created_at": datetime.utcnow(),
        "expires_at": datetime.utcnow() + timedelta(hours=24),
        "used": False
    }
    
    # URL simulada para el frontend
    reset_url = f"http://localhost/lacava/frontend/#recovery?token={token}"
    
    print(f"   Token generado: {token}")
    print(f"   URL simulada: {reset_url}")
    
    return {
        "success": True,
        "message": "Email de recuperación enviado (simulado)",
        "demo_info": {
            "email_sent_to": email,
            "reset_url": reset_url,
            "token": token,
            "valid_until": recovery_tokens[token]["expires_at"].isoformat(),
            "note": "Esta es una simulación. En producción se enviaría un email real."
        }
    }

@router.post("/password-recovery/reset")
async def reset_password(request: ResetPasswordRequest):
    """
    Endpoint MOCK para restablecer contraseña
    """
    token = request.token
    new_password = request.new_password
    confirm_password = request.confirm_password
    
    print(f"🔄 Intento de restablecimiento con token: {token}")
    
    # Validaciones básicas
    if new_password != confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Las contraseñas no coinciden"
        )
    
    if len(new_password) < 6:
        raise HTTPException(
            status_code=400,
            detail="La contraseña debe tener al menos 6 caracteres"
        )
    
    # Verificar token
    if token not in recovery_tokens:
        raise HTTPException(
            status_code=404,
            detail="Token inválido o expirado"
        )
    
    token_data = recovery_tokens[token]
    
    # Verificar expiración
    if datetime.utcnow() > token_data["expires_at"]:
        raise HTTPException(
            status_code=400,
            detail="Token expirado"
        )
    
    if token_data["used"]:
        raise HTTPException(
            status_code=400,
            detail="Token ya utilizado"
        )
    
    # Marcar token como usado
    recovery_tokens[token]["used"] = True
    recovery_tokens[token]["used_at"] = datetime.utcnow()
    
    print(f"✅ Contraseña restablecida para: {token_data['email']}")
    print(f"   Nueva contraseña (simulada): {'*' * len(new_password)}")
    
    return {
        "success": True,
        "message": "Contraseña restablecida exitosamente (simulación)",
        "demo_info": {
            "email": token_data["email"],
            "password_updated": True,
            "updated_at": datetime.utcnow().isoformat(),
            "note": "En producción, la contraseña se actualizaría en la base de datos."
        }
    }

@router.get("/password-recovery/demo-status")
async def get_demo_status():
    """
    Endpoint para ver el estado de la demo
    """
    return {
        "demo_active": True,
        "tokens_generated": len(recovery_tokens),
        "tokens_used": sum(1 for t in recovery_tokens.values() if t.get("used", False)),
        "service": "password_recovery_mock",
        "note": "Esta es una demostración no funcional. En producción se integraría con un servicio de email."
    }

# ========== ENDPOINTS CRUD DE USUARIOS ==========

@router.get("/")
async def listar_usuarios():
    """
    Lista todos los usuarios registrados.
    """
    try:
        print("📋 Listando usuarios...")
        
        # Obtener usuarios de forma simple
        usuarios = list(users_collection.find({}, {
            "_id": 1,
            "nombre": 1,
            "correo": 1,
            "rol": 1,
            "activo": 1
        }))
        
        # Convertir ObjectId a string
        for usuario in usuarios:
            usuario["id"] = str(usuario["_id"])
            del usuario["_id"]
        
        print(f"✅ {len(usuarios)} usuarios encontrados")
        
        return {
            "success": True,
            "count": len(usuarios),
            "usuarios": usuarios
        }
        
    except Exception as e:
        print(f"❌ Error listando usuarios: {e}")
        import traceback
        traceback.print_exc()
        
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "LIST_USERS_ERROR",
                "message": "Error interno del servidor al listar usuarios."
            }
        )

@router.get("/{correo}")
async def obtener_usuario(correo: str):
    """
    Obtiene un usuario específico por correo.
    """
    try:
        usuario = users_collection.find_one({
            "correo": {"$regex": f"^{correo}$", "$options": "i"}
        })
        
        if not usuario:
            raise HTTPException(
                status_code=404,
                detail={
                    "error_type": "USER_NOT_FOUND",
                    "message": f"Usuario con correo '{correo}' no encontrado."
                }
            )
        
        return {
            "id": str(usuario.get("_id", "")),
            "nombre": usuario.get("nombre", ""),
            "correo": usuario.get("correo", ""),
            "rol": usuario.get("rol", "Cliente"),
            "activo": usuario.get("activo", True),
            "created_at": usuario.get("created_at"),
            "updated_at": usuario.get("updated_at")
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error obteniendo usuario: {e}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "GET_USER_ERROR",
                "message": "Error interno del servidor."
            }
        )

@router.post("/register")
async def registrar_usuario(usuario: Usuario):
    """
    Endpoint para registrar nuevos usuarios
    """
    try:
        email = usuario.correo.strip().lower()
        
        print(f"📝 Intentando registrar usuario: {email}")
        
        # Validaciones
        if not email or "@" not in email:
            raise HTTPException(
                status_code=400,
                detail={
                    "error_type": "INVALID_EMAIL",
                    "message": "Correo electrónico no válido."
                }
            )
        
        if len(usuario.contraseña) < 6:
            raise HTTPException(
                status_code=400,
                detail={
                    "error_type": "WEAK_PASSWORD",
                    "message": "La contraseña debe tener al menos 6 caracteres."
                }
            )
        
        # Verificar si ya existe
        existente = users_collection.find_one({
            "correo": {"$regex": f"^{email}$", "$options": "i"}
        })
        
        if existente:
            raise HTTPException(
                status_code=400,
                detail={
                    "error_type": "USER_ALREADY_EXISTS",
                    "message": f"El correo '{email}' ya está registrado."
                }
            )
        
        # Crear nuevo usuario
        nuevo_usuario = {
            "nombre": usuario.nombre.strip(),
            "correo": email,
            "contraseña": usuario.contraseña,
            "rol": usuario.rol if usuario.rol in ["Cliente", "Administrador", "Dueño"] else "Cliente",
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow(),
            "activo": True
        }
        
        result = users_collection.insert_one(nuevo_usuario)
        
        print(f"✅ Usuario registrado exitosamente: {email}")
        
        return {
            "success": True,
            "message": "Usuario creado exitosamente",
            "usuario_id": str(result.inserted_id)
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"🔥 Error registrando usuario: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "REGISTRATION_FAILED",
                "message": "Error interno del servidor."
            }
        )

@router.put("/{correo}")
async def actualizar_usuario(correo: str, datos_actualizacion: UsuarioUpdate):
    """
    Actualiza un usuario existente.
    """
    try:
        usuario = users_collection.find_one({
            "correo": {"$regex": f"^{correo}$", "$options": "i"}
        })
        
        if not usuario:
            raise HTTPException(
                status_code=404,
                detail={
                    "error_type": "USER_NOT_FOUND",
                    "message": f"Usuario con correo '{correo}' no encontrado."
                }
            )
        
        update_data = {}
        
        if datos_actualizacion.nombre:
            update_data["nombre"] = datos_actualizacion.nombre.strip()
        
        if datos_actualizacion.rol:
            update_data["rol"] = datos_actualizacion.rol
        
        if datos_actualizacion.contraseña:
            update_data["contraseña"] = datos_actualizacion.contraseña
        
        if update_data:
            update_data["updated_at"] = datetime.utcnow()
            users_collection.update_one(
                {"_id": usuario["_id"]},
                {"$set": update_data}
            )
        
        return {
            "success": True,
            "message": "Usuario actualizado exitosamente",
            "correo": correo
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error actualizando usuario: {e}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "UPDATE_USER_ERROR",
                "message": "Error interno del servidor."
            }
        )

@router.delete("/{correo}")
async def eliminar_usuario(correo: str):
    """
    Elimina un usuario del sistema.
    """
    try:
        result = users_collection.delete_one({
            "correo": {"$regex": f"^{correo}$", "$options": "i"}
        })
        
        if result.deleted_count == 0:
            raise HTTPException(
                status_code=404,
                detail={
                    "error_type": "USER_NOT_FOUND",
                    "message": f"Usuario con correo '{correo}' no encontrado."
                }
            )
        
        return {
            "success": True,
            "message": f"Usuario {correo} eliminado correctamente"
        }
        
    except HTTPException:
        raise
    except Exception as e:
        print(f"Error eliminando usuario: {e}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "DELETE_USER_ERROR",
                "message": "Error interno del servidor."
            }
        )

# ========== ENDPOINTS DE DIAGNÓSTICO ==========

@router.get("/debug/emails")
async def obtener_emails_registrados():
    """
    Endpoint de debugging: lista todos los correos registrados.
    """
    try:
        usuarios = list(users_collection.find({}, {"correo": 1, "nombre": 1, "rol": 1}))
        
        emails = []
        for usuario in usuarios:
            if usuario.get('correo'):
                emails.append({
                    "correo": usuario.get('correo'),
                    "nombre": usuario.get('nombre', ''),
                    "rol": usuario.get('rol', 'Cliente')
                })
        
        return {
            "success": True,
            "count": len(emails),
            "emails": emails
        }
        
    except Exception as e:
        print(f"Error obteniendo emails: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Error interno: {str(e)}"
        )

@router.get("/health")
async def health_check():
    """
    Endpoint para verificar el estado del servicio de usuarios.
    """
    try:
        count = users_collection.count_documents({})
        
        return {
            "status": "healthy",
            "service": "usuarios",
            "database": "connected",
            "total_users": count,
            "timestamp": datetime.utcnow().isoformat()
        }
    except Exception as e:
        return {
            "status": "unhealthy",
            "service": "usuarios", 
            "database": "disconnected",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat()
        }

@router.post("/setup-demo-data")
async def setup_demo_data():
    """
    Configura datos de demostración si no existen.
    """
    try:
        demo_users = [
            {
                "nombre": "Cliente Demo",
                "correo": "cliente@lacavadelvalle.cl",
                "contraseña": "cliente123",
                "rol": "Cliente",
                "activo": True
            },
            {
                "nombre": "Administrador Sistema",
                "correo": "admin@lacavadelvalle.cl",
                "contraseña": "admin123",
                "rol": "Administrador", 
                "activo": True
            },
            {
                "nombre": "Dueño Empresa",
                "correo": "dueno@lacavadelvalle.cl",
                "contraseña": "dueno123",
                "rol": "Dueño",
                "activo": True
            }
        ]
        
        created = 0
        for user_data in demo_users:
            existing = users_collection.find_one({"correo": user_data["correo"]})
            if not existing:
                user_data.update({
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                })
                users_collection.insert_one(user_data)
                created += 1
                print(f"✅ Usuario demo creado: {user_data['correo']}")
        
        return {
            "success": True,
            "message": f"Datos demo configurados ({created} creados)",
            "created": created
        }
        
    except Exception as e:
        print(f"Error configurando demo data: {e}")
        raise HTTPException(
            status_code=500,
            detail={
                "error_type": "SETUP_DEMO_ERROR",
                "message": "Error al configurar datos de demostración."
            }
        )

# ========== INICIALIZACIÓN ==========

async def initialize_users_module():
    """
    Función para inicializar el módulo de usuarios.
    """
    try:
        print("🔧 Inicializando módulo de usuarios...")
        
        count = users_collection.count_documents({})
        print(f"📊 Usuarios en la base de datos: {count}")
        
        if count == 0:
            await setup_demo_data()
        
        print("✅ Módulo de usuarios inicializado correctamente")
        return True
        
    except Exception as e:
        print(f"❌ Error inicializando módulo de usuarios: {e}")
        return False