// api.js - VERSIÓN CORREGIDA (API_BASE global)
console.log('🌐 Cargando api.js...');

// Configuración de la API - hacerla GLOBAL
if (typeof window.API_BASE === 'undefined') {
  window.API_BASE = 'http://localhost:8000';
}
console.log('✅ API_BASE definida:', window.API_BASE);

// Utilidades básicas
window.$ = id => document.getElementById(id);
const showLoading = (element) => element?.classList?.add('loading');
const hideLoading = (element) => element?.classList?.remove('loading');

// Función principal para llamadas a la API
async function apiCall(endpoint, options = {}) {
  try {
    console.log(`📡 API Call: ${window.API_BASE}${endpoint}`);
    
    const response = await fetch(`${window.API_BASE}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ API Error ${response.status}: ${errorText}`);
      throw new Error(`Error ${response.status}: ${errorText}`);
    }

    const data = await response.json();
    console.log(`✅ API Response ${endpoint}:`, data);
    return data;
    
  } catch (error) {
    console.error('🔥 Error en apiCall:', error);
    throw error;
  }
}

// Funciones específicas de la API
window.api = {
  // Usuarios
  async getUsers() {
    return await apiCall('/usuarios/');
  },

  async createUser(userData) {
    return await apiCall('/usuarios/', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },

  // Productos (CORREGIDO)
  async getProducts() {
    return await apiCall('/listar/');  // ✅ Correcto
  },

  async createProduct(productData) {
    return await apiCall('/agregar/', {  // ✅ Cambiado de /productos/agregar/
      method: 'POST',
      body: JSON.stringify(productData)
    });
  },

  async updateProduct(id, productData) {
    return await apiCall(`/actualizar/${id}`, {  // ✅ Nuevo método
      method: 'PUT',
      body: JSON.stringify(productData)
    });
  },

  async deleteProduct(id) {
    return await apiCall(`/eliminar/${id}`, {  // ✅ Nuevo método
      method: 'DELETE'
    });
  },

  async getProductById(id) {
    return await apiCall(`/${id}`);  // ✅ Nuevo método
  },

  // Pedidos
  async getOrders() {
    return await apiCall('/pedidos/listar/');
  },

  async createOrder(orderData) {
    return await apiCall('/pedidos/crear/', {
      method: 'POST',
      body: JSON.stringify(orderData)
    });
  },

  async cancelOrder(orderId, motivo) {
    return await apiCall(`/pedidos/anular/${orderId}?motivo=${encodeURIComponent(motivo)}`, {
      method: 'PUT'
    });
  },

  // Pagos
  async processPayment(paymentData) {
    // Validar y convertir tipos
    const validatedData = {
      pedido_id: String(paymentData.pedido_id),
      metodo: String(paymentData.metodo),
      monto: parseFloat(paymentData.monto)
    };
    
    console.log('💰 Enviando pago validado:', validatedData);
    
    return await apiCall('/pagos/procesar/', {
      method: 'POST',
      body: JSON.stringify(validatedData)
    });
  },

  // Caja
  async registerSale(orderId) {
    return await apiCall(`/caja/registrar_venta/?pedido_id=${orderId}`, {
      method: 'POST'
    });
  },

  async getCashBalance() {
    return await apiCall('/caja/saldo/');
  },

  // Login y Autenticación
  async login(email, password) {
    return await apiCall('/usuarios/login', {
      method: 'POST',
      body: JSON.stringify({ email, password })
    });
  },

  async register(userData) {
    return await apiCall('/usuarios/register', {
      method: 'POST',
      body: JSON.stringify(userData)
    });
  },

  // Recuperación de contraseña
  async requestPasswordRecovery(email) {
    return await apiCall('/password-recovery/request', {
      method: 'POST',
      body: JSON.stringify({ email })
    });
  },

  async resetPassword(token, newPassword, confirmPassword) {
    return await apiCall('/password-recovery/reset', {
      method: 'POST',
      body: JSON.stringify({
        token,
        new_password: newPassword,
        confirm_password: confirmPassword
      })
    });
  },

  async getRecoveryStatus() {
    return await apiCall('/password-recovery/demo-status');
  }
};

// Exportar apiCall también para uso global
window.apiCall = apiCall;

console.log('✅ api.js cargado correctamente');
console.log('📦 Módulos exportados: api, apiCall, $, API_BASE');