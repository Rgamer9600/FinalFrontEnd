// app.js - VERSIÓN CORREGIDA (manejo flexible de elementos DOM)
(function() {
  console.log('🚀 app.js cargado - La Cava del Valle');
  
  // Esperar a que el DOM esté listo
  document.addEventListener('DOMContentLoaded', function() {
    console.log('📄 DOM completamente cargado');
    
    // Dar más tiempo para que Bootstrap y otros scripts se carguen
    setTimeout(initializeSafe, 300);
  });

  // Función de inicialización segura
  async function initializeSafe() {
    try {
      console.log('🔧 Iniciando aplicación de forma segura...');
      
      // 1. Verificar que los módulos críticos están cargados
      const modulesLoaded = await checkCriticalModules();
      
      if (!modulesLoaded) {
        console.warn('⚠️ Algunos módulos críticos no están cargados, intentando reparar...');
        await repairMissingModules();
      }
      
      // 2. Verificar elementos DOM críticos (con tolerancia)
      const domReady = await checkCriticalDOM();
      if (!domReady) {
        console.warn('⚠️ Algunos elementos DOM no encontrados, continuando de todos modos...');
        // Continuamos aunque algunos elementos no estén, para no bloquear la app
      }
      
      // 3. Inicializar la aplicación principal
      await initializeApplication();
      
      console.log('✅ Aplicación inicializada correctamente');
      
      // 4. Ejecutar test de conexión automático
      setTimeout(async () => {
        await testInitialConnection();
      }, 2000);
      
    } catch (error) {
      console.error('🔥 Error crítico en initializeSafe:', error);
      showErrorToUser(error);
    }
  }

  // Verificar módulos críticos (más flexible)
  async function checkCriticalModules() {
    console.log('🔍 Verificando módulos críticos...');
    
    const criticalModules = {
      'API_BASE': typeof window.API_BASE !== 'undefined',
      'api': typeof window.api !== 'undefined' || typeof window.apiCall !== 'undefined',
      'auth': typeof window.auth !== 'undefined',
      '$': typeof window.$ !== 'undefined'
    };
    
    console.table(criticalModules);
    
    // Solo requerimos API_BASE absoluta, los otros podemos trabajar sin ellos
    const essentialLoaded = criticalModules['API_BASE'];
    
    if (!essentialLoaded) {
      console.error('❌ API_BASE es esencial y no está definida');
      return false;
    }
    
    return true;
  }

  // Verificar elementos DOM críticos (con tolerancia)
  async function checkCriticalDOM() {
    console.log('🏗️ Verificando elementos DOM críticos...');
    
    // Elementos CRÍTICOS (la app no funciona sin estos)
    const criticalElements = [
      'panel-login',
      'btnLogin'
    ];
    
    // Elementos IMPORTANTES (la app puede funcionar sin estos)
    const importantElements = [
      'menu',
      'userInfo',
      'btnLogout',
      'menu-links'
    ];
    
    console.log('Elementos críticos requeridos:');
    criticalElements.forEach(id => {
      const element = document.getElementById(id);
      console.log(`- ${id}: ${element ? '✅' : '❌'}`);
    });
    
    console.log('Elementos importantes:');
    importantElements.forEach(id => {
      const element = document.getElementById(id);
      console.log(`- ${id}: ${element ? '✅' : '❌'}`);
    });
    
    // Verificar que los elementos críticos existan
    const criticalMissing = criticalElements.filter(id => !document.getElementById(id));
    
    if (criticalMissing.length > 0) {
      console.error('❌ Elementos críticos faltantes:', criticalMissing);
      
      // Intentar crear elementos faltantes dinámicamente
      await createMissingElements(criticalMissing);
      
      // Verificar nuevamente
      const stillMissing = criticalMissing.filter(id => !document.getElementById(id));
      if (stillMissing.length > 0) {
        console.error('❌ No se pudieron crear elementos:', stillMissing);
        return false;
      }
    }
    
    return true;
  }

  // Crear elementos faltantes dinámicamente
  async function createMissingElements(missingIds) {
    console.log('🔨 Creando elementos faltantes:', missingIds);
    
    const sidebar = document.querySelector('.sidebar');
    if (!sidebar) {
      console.error('❌ No se encontró el sidebar');
      return;
    }
    
    missingIds.forEach(id => {
      switch(id) {
        case 'panel-login':
          if (!document.getElementById('panel-login')) {
            const panel = document.createElement('div');
            panel.id = 'panel-login';
            panel.innerHTML = `
              <div class="tiny">Inicia sesión</div>
              <input id="email_login" class="form-control form-control-sm mb-1" placeholder="correo@ejemplo.com" />
              <input id="pass_login" class="form-control form-control-sm mb-1" placeholder="contraseña" type="password"/>
              <div class="d-grid gap-1">
                <button id="btnLogin" class="btn btn-sm" style="background:#fff2e6; color:var(--brand);">Acceder</button>
                <button id="btnRegister" class="btn btn-sm btn-outline-light">Registrar</button>
              </div>
            `;
            sidebar.appendChild(panel);
            console.log('✅ panel-login creado dinámicamente');
          }
          break;
          
        case 'menu':
          if (!document.getElementById('menu')) {
            const menu = document.createElement('nav');
            menu.id = 'menu';
            menu.className = 'mt-3 hidden';
            menu.innerHTML = `
              <div class="tiny mb-2">Menú</div>
              <div id="menu-links"></div>
              <hr style="border-color: rgba(255,255,255,0.08)"/>
              <button id="btnLogout" class="btn btn-sm btn-light">Cerrar sesión</button>
            `;
            sidebar.appendChild(menu);
            console.log('✅ menu creado dinámicamente');
          }
          break;
          
        case 'btnLogin':
          // Si btnLogin falta pero panel-login existe, crearlo dentro
          const panel = document.getElementById('panel-login');
          if (panel && !document.getElementById('btnLogin')) {
            const btn = document.createElement('button');
            btn.id = 'btnLogin';
            btn.className = 'btn btn-sm';
            btn.style.cssText = 'background:#fff2e6; color:var(--brand);';
            btn.innerHTML = 'Acceder';
            panel.querySelector('.d-grid').appendChild(btn);
            console.log('✅ btnLogin creado dinámicamente');
          }
          break;
      }
    });
  }

  // Reparar módulos faltantes
  async function repairMissingModules() {
    console.log('🔧 Reparando módulos faltantes...');
    
    // Si API_BASE no existe, crearla
    if (typeof window.API_BASE === 'undefined') {
      window.API_BASE = 'http://localhost:8000';
      console.log('✅ API_BASE creada:', window.API_BASE);
    }
    
    // Si $ no existe, crearla
    if (typeof window.$ === 'undefined') {
      window.$ = id => document.getElementById(id);
      console.log('✅ $ creada');
    }
    
    // Si api no existe pero apiCall sí, crear api
    if (typeof window.api === 'undefined' && typeof window.apiCall !== 'undefined') {
      window.api = {
        login: async (email, password) => {
          return await window.apiCall('/usuarios/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
          });
        }
      };
      console.log('✅ api básica creada');
    }
    
    // Si auth no existe, crearla básica
    if (typeof window.auth === 'undefined') {
      window.auth = {
        getCurrentUser: () => window.currentUser || null,
        login: async (email, password) => {
          console.log('🔐 Login básico:', email);
          // Implementación básica
        }
      };
      console.log('✅ auth básica creada');
    }
    
    return true;
  }

  // Inicializar aplicación
  async function initializeApplication() {
    console.log('🎯 Inicializando aplicación...');
    
    // Opción 1: Si existe initializeApp, usarlo
    if (typeof window.initializeApp === 'function') {
      console.log('🔨 Ejecutando initializeApp()...');
      return window.initializeApp();
    }
    
    // Opción 2: Si existe ui.js y tiene funciones, usarlas
    if (typeof window.showSection === 'function') {
      console.log('🔨 Usando funciones de ui.js...');
      return initializeWithUI();
    }
    
    // Opción 3: Inicialización manual básica
    console.log('🔨 Usando inicialización manual básica...');
    return initializeManual();
  }

  // Inicializar con funciones de UI
  function initializeWithUI() {
    console.log('🎨 Inicializando con funciones UI...');
    
    // Mostrar sección de inicio
    window.showSection('home');
    
    // Inicializar event listeners
    initializeEventListeners();
    
    // Verificar usuario guardado
    checkSavedUser();
  }

  // Inicialización manual
  function initializeManual() {
    console.log('🔨 Inicialización manual...');
    
    // 1. Inicializar event listeners básicos
    initializeBasicEventListeners();
    
    // 2. Mostrar sección de inicio
    const homeSection = document.getElementById('home');
    if (homeSection) {
      homeSection.classList.remove('hidden');
    }
    
    // 3. Ocultar otras secciones
    const sections = document.querySelectorAll('.card-skel[id]');
    sections.forEach(section => {
      if (section.id !== 'home') {
        section.classList.add('hidden');
      }
    });
    
    // 4. Verificar usuario guardado
    checkSavedUser();
  }

  // Inicializar event listeners (compatible con ui.js)
  function initializeEventListeners() {
    console.log('🎮 Inicializando event listeners...');
    
    // Si ui.js tiene su propia función, usarla
    if (typeof window.initializeEventListeners === 'function') {
      console.log('🔌 Usando initializeEventListeners de ui.js');
      return window.initializeEventListeners();
    }
    
    // Si no, usar nuestra implementación
    return initializeBasicEventListeners();
  }

  // Inicializar event listeners básicos
  function initializeBasicEventListeners() {
    console.log('🎮 Inicializando event listeners básicos...');
    
    // Login
    const btnLogin = document.getElementById('btnLogin');
    if (btnLogin) {
      btnLogin.addEventListener('click', handleLoginClick);
      console.log('✅ Listener de login asignado');
    } else {
      console.error('❌ btnLogin no encontrado para asignar listener');
    }
    
    // Logout
    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
      btnLogout.addEventListener('click', handleLogoutClick);
      console.log('✅ Listener de logout asignado');
    }
    
    // Register
    const btnRegister = document.getElementById('btnRegister');
    if (btnRegister) {
      btnRegister.addEventListener('click', handleRegisterClick);
      console.log('✅ Listener de registro asignado');
    }
  }

  // Manejador de login
  async function handleLoginClick() {
    console.log('🎯 Botón login clickeado');
    
    const emailInput = document.getElementById('email_login');
    const passwordInput = document.getElementById('pass_login');
    
    if (!emailInput || !passwordInput) {
      showAlert('Error: Campos de login no encontrados', 'danger');
      return;
    }
    
    const email = emailInput.value.trim();
    const password = passwordInput.value;
    
    if (!email || !password) {
      showAlert('Por favor completa email y contraseña', 'warning');
      return;
    }
    
    try {
      // Mostrar loading
      const btn = document.getElementById('btnLogin');
      const originalText = btn.innerHTML;
      btn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Validando...';
      btn.disabled = true;
      
      // Intentar login con el sistema disponible
      let result;
      
      if (window.api && window.api.login) {
        console.log('🌐 Usando api.login()...');
        result = await window.api.login(email, password);
      } else if (window.auth && window.auth.login) {
        console.log('🔐 Usando auth.login()...');
        result = await window.auth.login(email, password);
      } else {
        // Fallback: login directo
        console.log('🔄 Usando login directo...');
        result = await loginDirect(email, password);
      }
      
      console.log('✅ Login resultado:', result);
      
      // Si el login fue exitoso
      if (result && (result.success || result.user_id)) {
        showAlert('¡Bienvenido!', 'success');
        
        // Actualizar usuario
        updateUserAfterLogin(result, email);
        
      } else {
        // Manejar error específico de correo no registrado
        if (result && result.detail && result.detail.error_type === 'EMAIL_NOT_FOUND') {
          showAlert(`Correo no registrado: ${email}`, 'danger');
          showRegistrationSuggestion(email);
        } else {
          showAlert('Error en el inicio de sesión', 'danger');
        }
      }
      
    } catch (error) {
      console.error('❌ Error en login:', error);
      
      // Mostrar error específico
      if (error.message.includes('Failed to fetch')) {
        showAlert('Error de conexión con el servidor', 'danger');
      } else if (error.message.includes('EMAIL_NOT_FOUND')) {
        showAlert(`El correo ${email} no está registrado`, 'danger');
        showRegistrationSuggestion(email);
      } else {
        showAlert('Error: ' + error.message, 'danger');
      }
      
    } finally {
      // Restaurar botón
      const btn = document.getElementById('btnLogin');
      if (btn) {
        btn.innerHTML = originalText || '<i class="bi bi-box-arrow-in-right me-2"></i>Acceder';
        btn.disabled = false;
      }
    }
  }

  // Login directo (fallback)
  async function loginDirect(email, password) {
    const response = await fetch(`${window.API_BASE}/usuarios/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, password })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail?.error_type || 'Login failed');
    }
    
    return await response.json();
  }

  // Actualizar usuario después del login
  function updateUserAfterLogin(result, email) {
    // Crear objeto de usuario
    const user = {
      correo: result.email || email,
      nombre: result.nombre || email.split('@')[0],
      rol: result.rol || 'Cliente',
      user_id: result.user_id || null
    };
    
    // Guardar en variables globales
    window.currentUser = user;
    if (window.auth) {
      window.auth.currentUser = user;
    }
    
    // Actualizar UI
    updateUIManually(user);
    
    // Guardar en localStorage
    try {
      localStorage.setItem('currentUser', JSON.stringify(user));
    } catch (e) {
      console.warn('No se pudo guardar en localStorage:', e);
    }
  }

  // Actualizar UI manualmente
  function updateUIManually(user) {
    console.log('🎨 Actualizando UI para:', user.correo);
    
    // Actualizar elementos de usuario
    const userEmail = document.getElementById('userEmail');
    const userRole = document.getElementById('userRole');
    const userInfo = document.getElementById('userInfo');
    const panelLogin = document.getElementById('panel-login');
    const menu = document.getElementById('menu');
    
    if (userEmail) userEmail.innerText = user.correo;
    if (userRole) userRole.innerText = user.rol;
    
    // Mostrar/ocultar elementos
    if (userInfo) userInfo.classList.remove('hidden');
    if (panelLogin) panelLogin.classList.add('hidden');
    if (menu) menu.classList.remove('hidden');
    
    // Construir menú
    buildMenuForRole(user.rol);
    
    // Mostrar sección apropiada
    showAppropriateSection(user.rol);
  }

  // Construir menú según rol
  function buildMenuForRole(role) {
    console.log('🔨 Construyendo menú para rol:', role);
    
    const menuLinks = document.getElementById('menu-links');
    if (!menuLinks) {
      console.error('❌ menu-links no encontrado');
      return;
    }
    
    menuLinks.innerHTML = '';
    
    const addLink = (label, target, icon = '') => {
      const a = document.createElement('a');
      a.className = 'nav-link';
      a.innerHTML = `${icon} ${label}`;
      a.onclick = () => {
        console.log(`📌 Navegando a: ${target}`);
        showSection(target);
      };
      menuLinks.appendChild(a);
    };
    
    // Menú base para todos
    addLink('Inicio', 'home', '🏠');
    
    if (role === 'Cliente') {
      addLink('Catálogo', 'catalogo', '🛍️');
      addLink('Mis pedidos', 'misPedidos', '📦');
      addLink('Anular pedido', 'anulacion', '❌');
    } else if (role === 'Administrador' || role === 'Admin' || role === 'Dueño') {
      addLink('Todos los Pedidos', 'listaPedidos', '📋');
      addLink('Órdenes de Despacho', 'asignaciones', '📋');
      addLink('Caja Virtual', 'cajaVirtual', '💰');
      addLink('Reportes', 'reportes', '📊');
      addLink('Gestión Productos', 'gestionProductos', '🛍️');
      addLink('Catálogo', 'catalogo', '🛍️');
    }
    
    console.log('✅ Menú construido con', menuLinks.children.length, 'opciones');
  }

  // Mostrar sección apropiada según rol
  function showAppropriateSection(role) {
    if (typeof window.showSection === 'function') {
      if (role === 'Cliente') {
        window.showSection('catalogo');
      } else {
        window.showSection('listaPedidos');
      }
    } else {
      // Implementación manual
      showSectionManual(role === 'Cliente' ? 'catalogo' : 'listaPedidos');
    }
  }

  // Mostrar sección manualmente
  function showSectionManual(sectionId) {
    console.log(`📌 Mostrando sección manual: ${sectionId}`);
    
    // Ocultar todas las secciones
    const sections = document.querySelectorAll('.card-skel[id]');
    sections.forEach(section => {
      section.classList.add('hidden');
    });
    
    // Mostrar la sección solicitada
    const targetSection = document.getElementById(sectionId);
    if (targetSection) {
      targetSection.classList.remove('hidden');
      console.log(`✅ Sección ${sectionId} mostrada`);
    } else {
      console.error(`❌ Sección ${sectionId} no encontrada`);
    }
  }

  // Mostrar alerta
  function showAlert(message, type = 'info') {
    console.log(`💬 Alert [${type}]: ${message}`);
    
    // Crear alerta
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type} alert-dismissible fade show m-3`;
    alertDiv.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 9999;
      min-width: 300px;
    `;
    alertDiv.innerHTML = `
      ${message}
      <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto-remover
    setTimeout(() => {
      if (alertDiv.parentNode) {
        alertDiv.remove();
      }
    }, 5000);
  }

  // Sugerencia de registro
  function showRegistrationSuggestion(email) {
    const suggestion = document.createElement('div');
    suggestion.className = 'alert alert-info m-3';
    suggestion.innerHTML = `
      <strong>¿Nuevo usuario?</strong><br>
      El correo <em>${email}</em> no está registrado.<br>
      <button onclick="registerUser('${email}')" class="btn btn-success btn-sm mt-2">
        <i class="bi bi-person-plus"></i> Registrar ahora
      </button>
    `;
    
    const panel = document.getElementById('panel-login');
    if (panel) {
      panel.appendChild(suggestion);
    }
  }

  // Registrar usuario
  window.registerUser = async function(email) {
  console.log(`📝 Registrando usuario: ${email}`);
  
  // Pedir nombre si no está disponible
  let nombre = prompt('Ingresa tu nombre:', email.split('@')[0]);
  if (!nombre) {
    showAlert('Se requiere un nombre para registrarse', 'warning');
    return;
  }
  
  // Pedir contraseña
  const password = prompt('Ingresa una contraseña (mínimo 6 caracteres):');
  if (!password) {
    showAlert('Se requiere una contraseña', 'warning');
    return;
  }
  
  if (password.length < 6) {
    showAlert('La contraseña debe tener al menos 6 caracteres', 'warning');
    return;
  }
  
  // Confirmar contraseña
  const confirmPassword = prompt('Confirma tu contraseña:');
  if (password !== confirmPassword) {
    showAlert('Las contraseñas no coinciden', 'danger');
    return;
  }
  
  try {
    showAlert('Registrando cuenta...', 'info');
    
    // Usar auth.register si está disponible
    if (window.auth && window.auth.register) {
      const result = await window.auth.register(email, password, nombre);
      console.log('✅ Registro completado:', result);
      return result;
    }
    
    // Fallback: registro directo
    const response = await fetch(`${window.API_BASE}/usuarios/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        nombre: nombre,
        correo: email,
        contraseña: password,
        rol: 'Cliente'
      })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      showAlert('¡Cuenta creada exitosamente! Ahora puedes iniciar sesión.', 'success');
      
      // Pre-llenar formulario
      const emailInput = document.getElementById('email_login');
      const passwordInput = document.getElementById('pass_login');
      if (emailInput) emailInput.value = email;
      if (passwordInput) passwordInput.value = password;
      
      // Auto-login después de 2 segundos
      setTimeout(async () => {
        if (window.auth && window.auth.login) {
          await window.auth.login(email, password);
        }
      }, 2000);
      
      return result;
      
    } else {
      // Manejo de error específico
      if (result.detail?.error_type === 'USER_ALREADY_EXISTS') {
        showAlert(`El correo ${email} ya está registrado. Intenta iniciar sesión.`, 'warning');
        
        // Ofrecer iniciar sesión
        const login = confirm('¿Deseas iniciar sesión con este correo?');
        if (login) {
          const emailInput = document.getElementById('email_login');
          const passwordInput = document.getElementById('pass_login');
          if (emailInput) emailInput.value = email;
          if (passwordInput) passwordInput.focus();
        }
        
      } else {
        showAlert(`Error: ${result.detail?.message || 'No se pudo crear la cuenta'}`, 'danger');
      }
      throw new Error(result.detail?.message || 'Registration failed');
    }
    
  } catch (error) {
    console.error('❌ Error en registro:', error);
    showAlert('Error al crear la cuenta: ' + error.message, 'danger');
  }
};
  // Manejador de logout
  function handleLogoutClick() {
    console.log('🚪 Logout clickeado');
    
    // Limpiar usuario
    window.currentUser = null;
    if (window.auth) {
      window.auth.currentUser = null;
    }
    
    // Limpiar localStorage
    try {
      localStorage.removeItem('currentUser');
    } catch (e) {}
    
    // Mostrar panel de login
    const panelLogin = document.getElementById('panel-login');
    const menu = document.getElementById('menu');
    const userInfo = document.getElementById('userInfo');
    
    if (panelLogin) panelLogin.classList.remove('hidden');
    if (menu) menu.classList.add('hidden');
    if (userInfo) userInfo.classList.add('hidden');
    
    // Mostrar sección de inicio
    showSectionManual('home');
    
    showAlert('Sesión cerrada correctamente', 'info');
  }

  // Verificar usuario guardado
  function checkSavedUser() {
    try {
      const savedUser = localStorage.getItem('currentUser');
      if (savedUser) {
        const user = JSON.parse(savedUser);
        if (user && user.correo) {
          console.log('👤 Usuario encontrado en localStorage:', user.correo);
          updateUIManually(user);
        }
      }
    } catch (e) {
      console.warn('Error leyendo localStorage:', e);
    }
  }

  // Test de conexión inicial
  async function testInitialConnection() {
    try {
      console.log('🌐 Test de conexión al backend...');
      
      const response = await fetch(window.API_BASE + '/');
      if (response.ok) {
        console.log('✅ Backend respondiendo');
        return true;
      }
      console.error('❌ Backend error:', response.status);
      return false;
    } catch (error) {
      console.error('❌ No se pudo conectar al backend:', error.message);
      return false;
    }
  }

  // Mostrar error al usuario
  function showErrorToUser(error) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger m-3';
    errorDiv.innerHTML = `
      <h4>❌ Error de inicialización</h4>
      <p>${error.message}</p>
      <button onclick="location.reload()" class="btn btn-warning">Reintentar</button>
      <button onclick="window.debug.repairApp()" class="btn btn-info ms-2">Reparar</button>
    `;
    
    const content = document.querySelector('.content');
    if (content) {
      content.prepend(errorDiv);
    }
  }

  // ========== DEBUGGING ==========
  
  window.debug = {
    checkModules: function() {
      console.log('🔍 Módulos cargados:');
      const modules = {
        'API_BASE': window.API_BASE,
        'api': !!window.api,
        'auth': !!window.auth,
        '$': !!window.$,
        'currentUser': window.currentUser,
        'showSection': typeof window.showSection
      };
      console.table(modules);
      return modules;
    },
    
    checkDOM: function() {
      console.log('🏗️ Elementos DOM:');
      const elements = ['panel-login', 'menu', 'userInfo', 'btnLogin', 'btnLogout', 'menu-links'];
      elements.forEach(id => {
        console.log(`- ${id}:`, document.getElementById(id) ? '✅' : '❌');
      });
    },
    
    repairApp: function() {
      console.log('🔧 Reparando aplicación...');
      
      // Limpiar cache
      localStorage.clear();
      sessionStorage.clear();
      
      // Recargar scripts críticos
      const scripts = ['api.js', 'auth.js', 'ui.js', 'app.js'];
      scripts.forEach(script => {
        const old = document.querySelector(`script[src*="${script}"]`);
        if (old) old.remove();
      });
      
      // Recargar página
      setTimeout(() => {
        location.reload();
      }, 1000);
      
      return 'Reparación iniciada, recargando...';
    },
    
    createMissingElements: function() {
      return createMissingElements(['panel-login', 'menu', 'btnLogin']);
    }
  };

  console.log('📜 app.js listo - La Cava del Valle');
})();