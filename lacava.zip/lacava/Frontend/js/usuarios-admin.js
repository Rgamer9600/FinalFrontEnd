// usuarios-admin.js - Gestión de usuarios - VERSIÓN CORREGIDA
console.log("👥 [usuarios-admin.js] Cargando módulo de gestión de usuarios v2.0...");

// Crear módulo global inmediatamente
window.usuariosAdmin = (function() {
    'use strict';
    
    // Estado
    let state = {
        usuarios: [],
        filteredUsuarios: [],
        editingId: null,
        filters: {
            search: '',
            rol: 'todos',
            estado: 'todos'
        },
        isInitialized: false
    };

    // Elementos DOM
    let elements = {};

    // ========== INICIALIZACIÓN ==========
    
    // Inicializar elementos DOM
    function initElements() {
        console.log('🔍 Buscando elementos DOM...');
        
        elements = {
            // Contenedores
            usuariosListContainer: document.getElementById('usuariosListContainer'),
            statsUsuarios: document.getElementById('statsUsuarios'),
            alertUsuarios: document.getElementById('alertUsuarios'),
            formUsuarioContainer: document.getElementById('formUsuarioContainer'),
            
            // Formulario
            formUsuario: document.getElementById('formUsuario'),
            usuarioId: document.getElementById('usuarioId'),
            nombreUsuario: document.getElementById('nombreUsuario'),
            correoUsuario: document.getElementById('correoUsuario'),
            rolUsuario: document.getElementById('rolUsuario'),
            passwordUsuario: document.getElementById('passwordUsuario'),
            confirmPasswordUsuario: document.getElementById('confirmPasswordUsuario'),
            activoUsuario: document.getElementById('activoUsuario'),
            
            // Botones
            btnNuevoUsuario: document.getElementById('btnNuevoUsuario'),
            btnRefreshUsuarios: document.getElementById('btnRefreshUsuarios'),
            btnGuardarUsuario: document.getElementById('btnGuardarUsuario'),
            btnCancelarUsuario: document.getElementById('btnCancelarUsuario'),
            btnGuardarUsuarioText: document.getElementById('btnGuardarUsuarioText'),
            formUsuarioTitle: document.getElementById('formUsuarioTitle'),
            
            // Etiquetas
            passwordRequiredLabel: document.getElementById('passwordRequiredLabel'),
            passwordHelpText: document.getElementById('passwordHelpText'),
            
            // Filtros
            searchUsuarios: document.getElementById('searchUsuarios'),
            filterRolUsuarios: document.getElementById('filterRolUsuarios'),
            filterEstadoUsuarios: document.getElementById('filterEstadoUsuarios'),
            
            // Contadores
            contadorUsuarios: document.getElementById('contadorUsuarios'),
            filtroInfoUsuarios: document.getElementById('filtroInfoUsuarios'),
            
            // Sección completa
            seccionGestionUsuarios: document.getElementById('gestionUsuarios')
        };
        
        // Log de elementos encontrados
        const encontrados = Object.keys(elements).filter(k => elements[k] !== null).length;
        const total = Object.keys(elements).length;
        console.log(`📋 Elementos encontrados: ${encontrados}/${total}`);
        
        // Mostrar qué elementos no se encontraron
        if (encontrados < total) {
            const noEncontrados = Object.keys(elements).filter(k => elements[k] === null);
            console.warn('⚠️ Elementos no encontrados:', noEncontrados);
        }
        
        return encontrados > 0;
    }

    // Inicialización completa
    function init() {
        console.log("🔧 Inicializando gestión de usuarios...");
        
        // Verificar que exista la sección
        if (!document.getElementById('gestionUsuarios')) {
            console.error('❌ Sección "gestionUsuarios" no encontrada en el DOM');
            return false;
        }
        
        // Inicializar elementos
        if (!initElements()) {
            console.error('❌ No se pudieron encontrar los elementos necesarios');
            return false;
        }
        
        // Configurar event listeners
        setupEventListeners();
        
        // Marcar como inicializado
        state.isInitialized = true;
        
        console.log("✅ Gestión de usuarios inicializada correctamente");
        return true;
    }

    // Verificar permisos de usuario
    function checkUserPermissions() {
        try {
            // Intentar obtener usuario de diferentes formas
            let user = null;
            
            if (window.auth && typeof window.auth.getCurrentUser === 'function') {
                user = window.auth.getCurrentUser();
                console.log('👤 Usuario obtenido de auth:', user);
            } else {
                // Intentar del localStorage
                const userData = localStorage.getItem('currentUser');
                if (userData) {
                    user = JSON.parse(userData);
                    console.log('👤 Usuario obtenido de localStorage:', user);
                }
            }
            
            if (!user) {
                console.warn('⚠️ No se pudo obtener información del usuario');
                return false;
            }
            
            // Verificar rol
            const esAdmin = user.rol === 'Administrador' || 
                           user.rol === 'Dueño' || 
                           user.rol === 'Admin';
            
            console.log(`🔑 Usuario: ${user.email || user.correo}, Rol: ${user.rol}, Es admin: ${esAdmin}`);
            return esAdmin;
            
        } catch (error) {
            console.error('❌ Error verificando permisos:', error);
            return false;
        }
    }

    // Configurar event listeners
    function setupEventListeners() {
        console.log('🎮 Configurando event listeners...');
        
        // Botón nuevo usuario
        if (elements.btnNuevoUsuario) {
            elements.btnNuevoUsuario.addEventListener('click', showNewUserForm);
            console.log('✅ Listener para btnNuevoUsuario configurado');
        }
        
        // Botón refresh
        if (elements.btnRefreshUsuarios) {
            elements.btnRefreshUsuarios.addEventListener('click', loadUsuarios);
            console.log('✅ Listener para btnRefreshUsuarios configurado');
        }
        
        // Botón cancelar
        if (elements.btnCancelarUsuario) {
            elements.btnCancelarUsuario.addEventListener('click', cancelEdit);
            console.log('✅ Listener para btnCancelarUsuario configurado');
        }
        
        // Formulario
        if (elements.formUsuario) {
            elements.formUsuario.addEventListener('submit', handleFormSubmit);
            console.log('✅ Listener para formUsuario configurado');
        }
        
        // Filtros
        if (elements.searchUsuarios) {
            elements.searchUsuarios.addEventListener('input', function(e) {
                state.filters.search = e.target.value.toLowerCase();
                filterUsuarios();
            });
        }
        
        if (elements.filterRolUsuarios) {
            elements.filterRolUsuarios.addEventListener('change', function(e) {
                state.filters.rol = e.target.value;
                filterUsuarios();
            });
        }
        
        if (elements.filterEstadoUsuarios) {
            elements.filterEstadoUsuarios.addEventListener('change', function(e) {
                state.filters.estado = e.target.value;
                filterUsuarios();
            });
        }
        
        console.log('✅ Todos los event listeners configurados');
    }

    // ========== FUNCIONES PRINCIPALES ==========

    // Cargar usuarios desde API
    async function loadUsuarios() {
        console.log('🌐 Cargando usuarios desde API...');
        
        try {
            showLoading(true);
            
            const apiBase = window.API_BASE || 'http://localhost:8000';
            const url = `${apiBase}/usuarios/`;
            
            console.log('📡 URL:', url);
            
            const response = await fetch(url);
            
            console.log('📊 Status:', response.status);
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('📦 Datos recibidos:', data);
            
            if (data.success && Array.isArray(data.usuarios)) {
                state.usuarios = data.usuarios.map(user => ({
                    id: user.id,
                    nombre: user.nombre || 'Sin nombre',
                    correo: user.correo || 'Sin correo',
                    rol: user.rol || 'Cliente',
                    activo: user.activo !== false,
                    created_at: user.created_at,
                    updated_at: user.updated_at
                }));
                
                console.log(`✅ ${state.usuarios.length} usuarios cargados`);
                
                // Actualizar UI
                filterUsuarios();
                renderStats();
                
                showAlert(`Se cargaron ${state.usuarios.length} usuarios`, 'success', 3000);
                
            } else {
                console.error('❌ Formato de respuesta inválido:', data);
                throw new Error(data.message || 'Formato de respuesta inválido');
            }
            
        } catch (error) {
            console.error("❌ Error cargando usuarios:", error);
            
            let errorMessage = "Error al cargar usuarios";
            
            if (error.message.includes('Failed to fetch') || error.message.includes('NetworkError')) {
                errorMessage = "Error de conexión con el servidor. Verifica que el backend esté ejecutándose.";
                
                // Mostrar datos de ejemplo
                showDemoData();
            } else {
                errorMessage += ": " + error.message;
            }
            
            showAlert(errorMessage, 'danger');
            
        } finally {
            showLoading(false);
        }
    }

    // Mostrar datos de demostración
    function showDemoData() {
        console.log('🎭 Mostrando datos de demostración...');
        
        state.usuarios = [
            {
                id: '1',
                nombre: 'Cliente Demo',
                correo: 'cliente@lacavadelvalle.cl',
                rol: 'Cliente',
                activo: true,
                created_at: new Date().toISOString()
            },
            {
                id: '2',
                nombre: 'Administrador Sistema',
                correo: 'admin@lacavadelvalle.cl',
                rol: 'Administrador',
                activo: true,
                created_at: new Date().toISOString()
            },
            {
                id: '3',
                nombre: 'Dueño Empresa',
                correo: 'dueno@lacavadelvalle.cl',
                rol: 'Dueño',
                activo: true,
                created_at: new Date().toISOString()
            },
            {
                id: '4',
                nombre: 'Repartidor Ejemplo',
                correo: 'repartidor@lacavadelvalle.cl',
                rol: 'Repartidor',
                activo: true,
                created_at: new Date().toISOString()
            }
        ];
        
        filterUsuarios();
        renderStats();
        
        showAlert('Mostrando datos de demostración. Verifica la conexión con el backend.', 'warning');
    }

    // Filtrar usuarios
    function filterUsuarios() {
        if (state.usuarios.length === 0) {
            state.filteredUsuarios = [];
            renderUsuarios();
            return;
        }
        
        console.log('🔍 Filtrando usuarios...');
        
        state.filteredUsuarios = state.usuarios.filter(usuario => {
            // Filtro de búsqueda
            if (state.filters.search) {
                const search = state.filters.search.toLowerCase();
                if (!usuario.nombre.toLowerCase().includes(search) && 
                    !usuario.correo.toLowerCase().includes(search)) {
                    return false;
                }
            }
            
            // Filtro de rol
            if (state.filters.rol !== 'todos' && usuario.rol !== state.filters.rol) {
                return false;
            }
            
            // Filtro de estado
            if (state.filters.estado === 'activo' && !usuario.activo) return false;
            if (state.filters.estado === 'inactivo' && usuario.activo) return false;
            
            return true;
        });
        
        console.log(`📊 Usuarios filtrados: ${state.filteredUsuarios.length} de ${state.usuarios.length}`);
        
        // Actualizar contadores
        if (elements.contadorUsuarios) {
            elements.contadorUsuarios.textContent = state.filteredUsuarios.length;
        }
        
        if (elements.filtroInfoUsuarios) {
            const total = state.usuarios.length;
            const filtrados = state.filteredUsuarios.length;
            elements.filtroInfoUsuarios.textContent = 
                filtrados === total ? '' : `(${filtrados} de ${total})`;
        }
        
        // Renderizar
        renderUsuarios();
    }

    // Renderizar lista de usuarios
    function renderUsuarios() {
        console.log('🎨 Renderizando lista de usuarios...');
        
        if (!elements.usuariosListContainer) {
            console.error('❌ No se encontró el contenedor de usuarios');
            return;
        }
        
        if (state.filteredUsuarios.length === 0) {
            elements.usuariosListContainer.innerHTML = `
                <div class="alert alert-info py-2">
                    <i class="bi bi-info-circle me-1"></i>
                    ${state.usuarios.length === 0 ? 
                        'No hay usuarios registrados en el sistema.' : 
                        'No se encontraron usuarios con los filtros seleccionados.'}
                </div>
            `;
            return;
        }
        
        // Obtener usuario actual
        let currentEmail = '';
        try {
            const user = window.auth ? window.auth.getCurrentUser() : 
                        JSON.parse(localStorage.getItem('currentUser') || '{}');
            currentEmail = user.email || user.correo || '';
        } catch (e) {
            console.warn('No se pudo obtener usuario actual:', e);
        }
        
        const html = state.filteredUsuarios.map(usuario => {
            const isCurrentUser = currentEmail === usuario.correo;
            
            // Determinar color según rol
            const rolColor = {
                'Cliente': 'primary',
                'Administrador': 'warning',
                'Repartidor': 'info',
                'Dueño': 'success'
            }[usuario.rol] || 'secondary';
            
            return `
                <div class="card mb-2 usuario-item" data-user-id="${usuario.id}">
                    <div class="card-body py-2">
                        <div class="d-flex justify-content-between align-items-start">
                            <div class="flex-grow-1">
                                <div class="d-flex align-items-center mb-1 flex-wrap">
                                    <strong class="me-2">${usuario.nombre}</strong>
                                    <span class="badge bg-${rolColor} me-1">${usuario.rol}</span>
                                    ${isCurrentUser ? 
                                        '<span class="badge bg-secondary me-1"><i class="bi bi-person-check"></i> Tú</span>' : ''}
                                    ${usuario.activo ? 
                                        '<span class="badge bg-success me-1"><i class="bi bi-check-circle"></i> Activo</span>' : 
                                        '<span class="badge bg-danger me-1"><i class="bi bi-x-circle"></i> Inactivo</span>'}
                                </div>
                                <div class="text-muted tiny">
                                    <i class="bi bi-envelope me-1"></i>${usuario.correo}
                                    <span class="ms-2">
                                        <i class="bi bi-calendar me-1"></i>
                                        ${formatDate(usuario.created_at)}
                                    </span>
                                </div>
                            </div>
                            <div class="btn-group btn-group-sm ms-2">
                                <button class="btn btn-outline-primary btn-editar-usuario" 
                                        data-user-id="${usuario.id}"
                                        ${isCurrentUser ? 'disabled title="No puedes editar tu propio usuario"' : ''}>
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-outline-danger btn-eliminar-usuario" 
                                        data-user-id="${usuario.id}"
                                        data-user-email="${usuario.correo}"
                                        data-user-name="${usuario.nombre}"
                                        ${isCurrentUser ? 'disabled title="No puedes eliminar tu propia cuenta"' : ''}>
                                    <i class="bi bi-trash"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
        }).join('');
        
        elements.usuariosListContainer.innerHTML = html;
        
        // Agregar event listeners a los botones
        setTimeout(() => {
            document.querySelectorAll('.btn-editar-usuario').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    editUsuario(btn.dataset.userId);
                });
            });
            
            document.querySelectorAll('.btn-eliminar-usuario').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.preventDefault();
                    confirmDeleteUsuario(
                        btn.dataset.userId, 
                        btn.dataset.userEmail,
                        btn.dataset.userName
                    );
                });
            });
        }, 50);
        
        console.log(`✅ Lista renderizada con ${state.filteredUsuarios.length} usuarios`);
    }

    // Renderizar estadísticas
    function renderStats() {
        if (!elements.statsUsuarios || state.usuarios.length === 0) {
            console.log('No hay datos para estadísticas');
            return;
        }
        
        console.log('📊 Calculando estadísticas...');
        
        const stats = {
            total: state.usuarios.length,
            activos: state.usuarios.filter(u => u.activo).length,
            clientes: state.usuarios.filter(u => u.rol === 'Cliente').length,
            administradores: state.usuarios.filter(u => u.rol === 'Administrador').length,
            repartidores: state.usuarios.filter(u => u.rol === 'Repartidor').length,
            duenos: state.usuarios.filter(u => u.rol === 'Dueño').length
        };
        
        elements.statsUsuarios.innerHTML = `
            <div class="col-6 col-md-3">
                <div class="card text-center border-primary">
                    <div class="card-body py-2">
                        <h5 class="text-primary mb-0">${stats.total}</h5>
                        <p class="tiny text-muted mb-0">Total</p>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card text-center border-success">
                    <div class="card-body py-2">
                        <h5 class="text-success mb-0">${stats.activos}</h5>
                        <p class="tiny text-muted mb-0">Activos</p>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card text-center border-warning">
                    <div class="card-body py-2">
                        <h5 class="text-warning mb-0">${stats.clientes}</h5>
                        <p class="tiny text-muted mb-0">Clientes</p>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card text-center border-info">
                    <div class="card-body py-2">
                        <h5 class="text-info mb-0">${stats.administradores}</h5>
                        <p class="tiny text-muted mb-0">Administradores</p>
                    </div>
                </div>
            </div>
        `;
        
        console.log('✅ Estadísticas renderizadas');
    }

    // Mostrar formulario para nuevo usuario
    function showNewUserForm() {
        console.log('📝 Mostrando formulario para nuevo usuario');
        
        state.editingId = null;
        
        // Resetear formulario
        if (elements.formUsuario) {
            elements.formUsuario.reset();
        }
        
        if (elements.usuarioId) elements.usuarioId.value = '';
        if (elements.activoUsuario) elements.activoUsuario.checked = true;
        if (elements.rolUsuario) elements.rolUsuario.value = 'Cliente';
        
        // Mostrar formulario
        elements.formUsuarioContainer.classList.remove('hidden');
        elements.formUsuarioTitle.textContent = 'Nuevo Usuario';
        if (elements.btnGuardarUsuarioText) {
            elements.btnGuardarUsuarioText.textContent = 'Crear Usuario';
        }
        
        if (elements.passwordRequiredLabel) {
            elements.passwordRequiredLabel.style.display = 'inline';
        }
        
        if (elements.passwordHelpText) {
            elements.passwordHelpText.textContent = '* Contraseña requerida para nuevos usuarios (mínimo 6 caracteres)';
        }
        
        if (elements.passwordUsuario) {
            elements.passwordUsuario.required = true;
        }
        
        // Enfocar primer campo
        setTimeout(() => {
            if (elements.nombreUsuario) {
                elements.nombreUsuario.focus();
            }
        }, 100);
        
        // Scroll suave al formulario
        elements.formUsuarioContainer.scrollIntoView({ 
            behavior: 'smooth', 
            block: 'start' 
        });
    }

    // Editar usuario existente
    async function editUsuario(userId) {
        console.log(`📝 Editando usuario ID: ${userId}`);
        
        try {
            showLoading(true);
            
            const usuario = state.usuarios.find(u => u.id === userId);
            if (!usuario) {
                throw new Error('Usuario no encontrado en la lista local');
            }
            
            console.log(`🔍 Buscando datos completos de: ${usuario.correo}`);
            
            // Cargar datos del usuario desde API
            const apiBase = window.API_BASE || 'http://localhost:8000';
            const url = `${apiBase}/usuarios/${encodeURIComponent(usuario.correo)}`;
            
            const response = await fetch(url);
            
            if (!response.ok) {
                throw new Error(`Error ${response.status} al cargar usuario`);
            }
            
            const userData = await response.json();
            console.log('📋 Datos del usuario:', userData);
            
            // Rellenar formulario
            if (elements.usuarioId) elements.usuarioId.value = userData.id || userId;
            if (elements.nombreUsuario) elements.nombreUsuario.value = userData.nombre || '';
            if (elements.correoUsuario) elements.correoUsuario.value = userData.correo || '';
            if (elements.rolUsuario) elements.rolUsuario.value = userData.rol || 'Cliente';
            if (elements.activoUsuario) elements.activoUsuario.checked = userData.activo !== false;
            
            state.editingId = userId;
            
            // Configurar formulario para edición
            elements.formUsuarioContainer.classList.remove('hidden');
            elements.formUsuarioTitle.textContent = 'Editar Usuario';
            
            if (elements.btnGuardarUsuarioText) {
                elements.btnGuardarUsuarioText.textContent = 'Actualizar Usuario';
            }
            
            if (elements.passwordRequiredLabel) {
                elements.passwordRequiredLabel.style.display = 'none';
            }
            
            if (elements.passwordHelpText) {
                elements.passwordHelpText.textContent = 'Dejar en blanco para mantener la contraseña actual';
            }
            
            if (elements.passwordUsuario) {
                elements.passwordUsuario.required = false;
                elements.passwordUsuario.value = '';
            }
            
            if (elements.confirmPasswordUsuario) {
                elements.confirmPasswordUsuario.value = '';
            }
            
            // Scroll al formulario
            elements.formUsuarioContainer.scrollIntoView({ 
                behavior: 'smooth', 
                block: 'start' 
            });
            
        } catch (error) {
            console.error("❌ Error al editar usuario:", error);
            showAlert(`Error al cargar usuario: ${error.message}`, 'danger');
        } finally {
            showLoading(false);
        }
    }

    // Manejar submit del formulario
    async function handleFormSubmit(e) {
        e.preventDefault();
        console.log('📤 Enviando formulario...');
        
        // Validar formulario
        if (!validateForm()) {
            console.log('❌ Validación fallida');
            return;
        }
        
        const formData = {
            nombre: elements.nombreUsuario ? elements.nombreUsuario.value.trim() : '',
            correo: elements.correoUsuario ? elements.correoUsuario.value.trim().toLowerCase() : '',
            rol: elements.rolUsuario ? elements.rolUsuario.value : 'Cliente',
            activo: elements.activoUsuario ? elements.activoUsuario.checked : true
        };
        
        console.log('📝 Datos del formulario:', formData);
        
        // Verificar contraseña
        const password = elements.passwordUsuario ? elements.passwordUsuario.value : '';
        const confirmPassword = elements.confirmPasswordUsuario ? elements.confirmPasswordUsuario.value : '';
        
        if (password) {
            if (password.length < 6) {
                showAlert('La contraseña debe tener al menos 6 caracteres', 'warning');
                return;
            }
            
            if (password !== confirmPassword) {
                showAlert('Las contraseñas no coinciden', 'warning');
                return;
            }
            
            formData.contraseña = password;
        }
        
        const isEditing = !!state.editingId;
        
        try {
            showLoading(true);
            
            const apiBase = window.API_BASE || 'http://localhost:8000';
            let url, method;
            
            if (isEditing) {
                // Actualizar usuario existente
                method = 'PUT';
                url = `${apiBase}/usuarios/${encodeURIComponent(formData.correo)}`;
            } else {
                // Crear nuevo usuario
                method = 'POST';
                url = `${apiBase}/usuarios/register`;
                
                // Verificar contraseña para nuevo usuario
                if (!password) {
                    throw new Error('La contraseña es requerida para nuevos usuarios');
                }
            }
            
            console.log(`🌐 Enviando ${method} a: ${url}`);
            console.log('📦 Datos enviados:', { ...formData, contraseña: '***' });
            
            const response = await fetch(url, {
                method: method,
                headers: { 
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(formData)
            });
            
            console.log('📊 Status respuesta:', response.status);
            
            const result = await response.json();
            console.log('📨 Respuesta:', result);
            
            if (!response.ok) {
                const errorMsg = result.detail?.message || 
                               result.detail?.error_type || 
                               result.message || 
                               `Error ${response.status}`;
                throw new Error(errorMsg);
            }
            
            // Éxito
            const successMsg = isEditing ? 
                `✅ Usuario "${formData.nombre}" actualizado exitosamente` : 
                `✅ Usuario "${formData.nombre}" creado exitosamente`;
            
            showAlert(successMsg, 'success');
            
            // Ocultar formulario y recargar lista
            cancelEdit();
            await loadUsuarios();
            
        } catch (error) {
            console.error("❌ Error en operación:", error);
            
            // Mensajes amigables
            let userMessage = error.message;
            
            if (error.message.includes('USER_ALREADY_EXISTS')) {
                userMessage = 'El correo electrónico ya está registrado en el sistema';
            } else if (error.message.includes('EMAIL_NOT_FOUND')) {
                userMessage = 'El usuario no existe en el sistema';
            } else if (error.message.includes('WEAK_PASSWORD')) {
                userMessage = 'La contraseña debe tener al menos 6 caracteres';
            } else if (error.message.includes('Failed to fetch')) {
                userMessage = 'Error de conexión con el servidor. Verifica que el backend esté ejecutándose.';
            }
            
            showAlert(userMessage, 'danger');
        } finally {
            showLoading(false);
        }
    }

    // Cancelar edición
    function cancelEdit() {
        console.log('❌ Cancelando edición...');
        
        if (elements.formUsuarioContainer) {
            elements.formUsuarioContainer.classList.add('hidden');
        }
        
        if (elements.formUsuario) {
            elements.formUsuario.reset();
        }
        
        state.editingId = null;
    }

    // Confirmar eliminación de usuario
    function confirmDeleteUsuario(userId, userEmail, userName) {
        console.log(`🗑️ Confirmando eliminación de: ${userEmail}`);
        
        // Verificar que no sea el usuario actual
        let currentEmail = '';
        try {
            const user = window.auth ? window.auth.getCurrentUser() : 
                        JSON.parse(localStorage.getItem('currentUser') || '{}');
            currentEmail = user.email || user.correo || '';
        } catch (e) {
            console.warn('No se pudo obtener usuario actual:', e);
        }
        
        if (currentEmail === userEmail) {
            showAlert('No puedes eliminar tu propia cuenta', 'warning');
            return;
        }
        
        const nombreMostrar = userName || userEmail;
        
        if (confirm(`¿Estás seguro de eliminar al usuario "${nombreMostrar}" (${userEmail})?\n\nEsta acción no se puede deshacer.`)) {
            deleteUsuario(userId, userEmail, nombreMostrar);
        }
    }

    // Eliminar usuario
    async function deleteUsuario(userId, userEmail, userName) {
        console.log(`🗑️ Eliminando usuario: ${userEmail}`);
        
        try {
            showLoading(true);
            
            const apiBase = window.API_BASE || 'http://localhost:8000';
            const url = `${apiBase}/usuarios/${encodeURIComponent(userEmail)}`;
            
            console.log(`🌐 Enviando DELETE a: ${url}`);
            
            const response = await fetch(url, {
                method: 'DELETE'
            });
            
            console.log('📊 Status respuesta:', response.status);
            
            const result = await response.json();
            console.log('📨 Respuesta:', result);
            
            if (!response.ok) {
                const errorMsg = result.detail?.message || 
                               result.message || 
                               `Error ${response.status}`;
                throw new Error(errorMsg);
            }
            
            const nombreMostrar = userName || userEmail;
            showAlert(`✅ Usuario "${nombreMostrar}" eliminado exitosamente`, 'success');
            
            // Recargar lista
            await loadUsuarios();
            
        } catch (error) {
            console.error("❌ Error eliminando usuario:", error);
            
            let userMessage = `Error al eliminar usuario: ${error.message}`;
            if (error.message.includes('USER_NOT_FOUND')) {
                userMessage = 'El usuario no existe o ya fue eliminado';
            } else if (error.message.includes('Failed to fetch')) {
                userMessage = 'Error de conexión con el servidor';
            }
            
            showAlert(userMessage, 'danger');
        } finally {
            showLoading(false);
        }
    }

    // ========== VALIDACIONES ==========

    // Validar formulario
    function validateForm() {
        console.log('🔍 Validando formulario...');
        
        let isValid = true;
        
        // Validar nombre
        if (!elements.nombreUsuario || !elements.nombreUsuario.value.trim()) {
            setInvalid(elements.nombreUsuario, 'El nombre es requerido');
            isValid = false;
        } else {
            setValid(elements.nombreUsuario);
        }
        
        // Validar correo
        if (!elements.correoUsuario || !elements.correoUsuario.value.trim()) {
            setInvalid(elements.correoUsuario, 'El correo es requerido');
            isValid = false;
        } else if (!isValidEmail(elements.correoUsuario.value)) {
            setInvalid(elements.correoUsuario, 'Correo electrónico inválido');
            isValid = false;
        } else {
            setValid(elements.correoUsuario);
        }
        
        // Validar rol
        if (!elements.rolUsuario || !elements.rolUsuario.value) {
            setInvalid(elements.rolUsuario, 'Selecciona un rol');
            isValid = false;
        } else {
            setValid(elements.rolUsuario);
        }
        
        // Validar contraseña para nuevos usuarios
        if (!state.editingId) {
            if (!elements.passwordUsuario || !elements.passwordUsuario.value) {
                setInvalid(elements.passwordUsuario, 'La contraseña es requerida');
                isValid = false;
            } else if (elements.passwordUsuario.value.length < 6) {
                setInvalid(elements.passwordUsuario, 'Mínimo 6 caracteres');
                isValid = false;
            } else {
                setValid(elements.passwordUsuario);
            }
        } else if (elements.passwordUsuario && elements.passwordUsuario.value) {
            // Validar contraseña si se proporciona en edición
            if (elements.passwordUsuario.value.length < 6) {
                setInvalid(elements.passwordUsuario, 'Mínimo 6 caracteres');
                isValid = false;
            } else {
                setValid(elements.passwordUsuario);
            }
        }
        
        // Validar confirmación de contraseña
        if (elements.passwordUsuario && elements.passwordUsuario.value && 
            elements.confirmPasswordUsuario && elements.confirmPasswordUsuario.value) {
            if (elements.passwordUsuario.value !== elements.confirmPasswordUsuario.value) {
                setInvalid(elements.confirmPasswordUsuario, 'Las contraseñas no coinciden');
                isValid = false;
            } else {
                setValid(elements.confirmPasswordUsuario);
            }
        }
        
        console.log(`✅ Validación: ${isValid ? 'APROBADA' : 'RECHAZADA'}`);
        return isValid;
    }

    // Validar email
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    // Marcar campo como inválido
    function setInvalid(element, message) {
        if (!element) return;
        
        element.classList.add('is-invalid');
        element.classList.remove('is-valid');
        
        // Buscar o crear elemento de feedback
        let feedback = element.nextElementSibling;
        if (!feedback || !feedback.classList.contains('invalid-feedback')) {
            feedback = document.createElement('div');
            feedback.className = 'invalid-feedback';
            element.parentNode.appendChild(feedback);
        }
        feedback.textContent = message;
    }

    // Marcar campo como válido
    function setValid(element) {
        if (!element) return;
        
        element.classList.remove('is-invalid');
        element.classList.add('is-valid');
        
        // Limpiar mensaje de error
        const feedback = element.nextElementSibling;
        if (feedback && feedback.classList.contains('invalid-feedback')) {
            feedback.textContent = '';
        }
    }

    // ========== UTILIDADES ==========

    // Mostrar alerta
    function showAlert(message, type = 'info', duration = 5000) {
        console.log(`💬 Alert [${type}]: ${message}`);
        
        if (!elements.alertUsuarios) {
            console.warn('No se encontró contenedor de alertas');
            return;
        }
        
        const icons = {
            success: 'check-circle-fill',
            danger: 'exclamation-triangle-fill',
            warning: 'exclamation-circle-fill',
            info: 'info-circle-fill'
        };
        
        const alertId = 'alert-' + Date.now();
        const icon = icons[type] || 'info-circle-fill';
        
        const alertHTML = `
            <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show" role="alert">
                <div class="d-flex align-items-center">
                    <i class="bi bi-${icon} me-2"></i>
                    <div class="flex-grow-1">${message}</div>
                    <button type="button" class="btn-close btn-close-sm" data-bs-dismiss="alert"></button>
                </div>
            </div>
        `;
        
        elements.alertUsuarios.innerHTML = alertHTML;
        
        // Auto-remover
        if (duration > 0) {
            setTimeout(() => {
                const alert = document.getElementById(alertId);
                if (alert) {
                    alert.remove();
                }
            }, duration);
        }
    }

    // Mostrar loading
    function showLoading(show) {
        const container = elements.usuariosListContainer;
        if (!container) return;
        
        if (show) {
            container.innerHTML = `
                <div class="text-center py-5">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Cargando...</span>
                    </div>
                    <p class="text-muted mt-2 tiny">Cargando usuarios...</p>
                </div>
            `;
            
            // También mostrar loading en estadísticas
            if (elements.statsUsuarios) {
                elements.statsUsuarios.innerHTML = `
                    <div class="col-6 col-md-3">
                        <div class="card text-center">
                            <div class="card-body py-2">
                                <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
                                <p class="tiny text-muted mt-1 mb-0">Cargando...</p>
                            </div>
                        </div>
                    </div>
                `;
            }
        }
    }

    // Formatear fecha
    function formatDate(dateString) {
        if (!dateString) return 'Sin fecha';
        
        try {
            const date = new Date(dateString);
            return date.toLocaleDateString('es-CL', {
                day: '2-digit',
                month: '2-digit',
                year: 'numeric'
            });
        } catch (e) {
            return dateString;
        }
    }

    // ========== FUNCIONES PÚBLICAS ==========
    
    // Función para llamar cuando se muestra la sección
    function onSectionShow() {
        console.log('👁️ Sección de gestión de usuarios mostrada');
        
        // Verificar permisos
        if (!checkUserPermissions()) {
            console.log('⛔ Usuario no tiene permisos de administrador');
            
            if (elements.usuariosListContainer) {
                elements.usuariosListContainer.innerHTML = `
                    <div class="alert alert-warning">
                        <i class="bi bi-shield-exclamation me-2"></i>
                        <strong>Acceso restringido</strong>
                        <p class="mb-0 mt-1">Solo los administradores pueden acceder a esta sección.</p>
                    </div>
                `;
            }
            
            if (elements.btnNuevoUsuario) {
                elements.btnNuevoUsuario.style.display = 'none';
            }
            
            return;
        }
        
        // Si ya está inicializado, solo cargar usuarios
        if (state.isInitialized) {
            console.log('🔄 Módulo ya inicializado, recargando usuarios...');
            loadUsuarios();
        } else {
            // Inicializar por primera vez
            console.log('🚀 Inicializando módulo por primera vez...');
            init();
        }
    }

    // Debug
    function debug() {
        console.log('👥 DEBUG - Estado del módulo:', {
            initialized: state.isInitialized,
            usuariosCount: state.usuarios.length,
            filteredCount: state.filteredUsuarios.length,
            editingId: state.editingId,
            filters: state.filters,
            elementos: Object.keys(elements).filter(k => elements[k] !== null)
        });
    }

    // ========== API PÚBLICA ==========
    return {
        // Inicialización
        init,
        onSectionShow,
        
        // CRUD
        loadUsuarios,
        showNewUserForm,
        cancelEdit,
        
        // Utilidades
        showAlert,
        debug,
        
        // Estado
        getState: () => ({ ...state }),
        getElements: () => ({ ...elements })
    };
})();

// ========== INTEGRACIÓN CON EL SISTEMA ==========

// 1. Integrar con showSection
if (typeof window.showSection === 'function') {
    // Guardar la función original
    const originalShowSection = window.showSection;
    
    // Sobrescribir para inicializar módulos específicos
    window.showSection = function(id) {
        console.log(`🔄 showSection llamado para: ${id}`);
        
        // Llamar a la función original
        originalShowSection(id);
        
        // Inicializar módulos específicos
        if (id === 'gestionUsuarios') {
            console.log('👥 Detectada sección de gestión de usuarios');
            
            // Pequeño delay para asegurar que el DOM esté listo
            setTimeout(() => {
                if (window.usuariosAdmin && window.usuariosAdmin.onSectionShow) {
                    window.usuariosAdmin.onSectionShow();
                } else {
                    console.error('❌ Módulo usuarios-admin no disponible');
                }
            }, 100);
        }
    };
}

// 2. Integrar con auth para recargar cuando se hace login
if (window.auth) {
    // Guardar login original si existe
    const originalLogin = window.auth.login;
    
    if (originalLogin) {
        window.auth.login = async function(...args) {
            const result = await originalLogin.apply(this, args);
            
            // Si el login es exitoso y el usuario es admin, cargar usuarios
            if (result && window.auth.getCurrentUser) {
                const user = window.auth.getCurrentUser();
                if (user && (user.rol === 'Administrador' || user.rol === 'Dueño')) {
                    // Verificar si estamos en la sección de gestión de usuarios
                    const currentSection = document.querySelector('.card-skel:not(.hidden)');
                    if (currentSection && currentSection.id === 'gestionUsuarios') {
                        setTimeout(() => {
                            if (window.usuariosAdmin && window.usuariosAdmin.loadUsuarios) {
                                window.usuariosAdmin.loadUsuarios();
                            }
                        }, 500);
                    }
                }
            }
            
            return result;
        };
    }
}

// 3. Auto-inicialización cuando se carga el script
console.log("✅ [usuarios-admin.js] Módulo completamente cargado");
console.log("💡 Usa: window.usuariosAdmin.debug() para diagnóstico");
console.log("💡 Usa: window.usuariosAdmin.onSectionShow() para forzar inicialización");