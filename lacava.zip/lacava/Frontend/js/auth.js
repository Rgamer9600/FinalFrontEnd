// auth.js - VERSIÓN LIMPIA SIN DUPLICADOS
let currentUser = null;

const auth = {
  // Variables para control de intentos
  failedAttempts: {},
  blockTimers: {},
  debugMode: true,
  
  async login(email, password) {
    try {
      email = email.trim().toLowerCase();
      
      if (this.debugMode) {
        console.log('🔐 [DEBUG] Iniciando login para:', email);
        console.log('🔐 [DEBUG] API_BASE:', window.API_BASE);
      }
      
      // Validaciones básicas
      if (!email || !email.includes('@')) {
        this.showLoginError('Por favor, ingresa un correo electrónico válido.', 'email');
        return;
      }
      
      if (!password) {
        this.showLoginError('Por favor, ingresa tu contraseña.', 'password');
        return;
      }
      
      // Verificar si está bloqueado localmente
      const localBlock = this.checkLocalBlock(email);
      if (localBlock.blocked) {
        this.showAccountBlocked(email, localBlock.secondsLeft, true);
        return;
      }
      
      // Mostrar estado de carga
      this.showLoading(true);
      this.clearLoginMessages();
      
      if (this.debugMode) {
        console.log('⏳ [DEBUG] Realizando fetch...');
      }
      
      // Llamar al endpoint de login
      const url = `${window.API_BASE || 'http://localhost:8000'}/usuarios/login`;
      
      if (this.debugMode) {
        console.log('🌐 [DEBUG] URL:', url);
        console.log('📦 [DEBUG] Datos:', { email, password: '***' });
      }
      
      const inicio = Date.now();
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: email,
          password: password
        })
      });
      
      const tiempo = Date.now() - inicio;
      
      if (this.debugMode) {
        console.log(`⏱️ [DEBUG] Tiempo respuesta: ${tiempo}ms`);
        console.log('📡 [DEBUG] Status:', response.status);
      }
      
      const data = await response.json();
      
      if (this.debugMode) {
        console.log('📨 [DEBUG] Respuesta:', data);
      }
      
      if (response.ok) {
        // ✅ Login exitoso
        if (this.debugMode) {
          console.log('✅ [DEBUG] Login exitoso');
        }
        
        // Limpiar intentos fallidos locales
        this.clearFailedAttempts(email);
        
        // Actualizar usuario actual
        currentUser = {
          correo: data.email,
          nombre: data.nombre,
          rol: data.rol,
          user_id: data.user_id
        };
        
        // Mostrar mensaje de éxito
        this.showLoginSuccess(data.message || '¡Bienvenido a La Cava del Valle!');
        
        // Actualizar UI
        this.updateUIAfterLogin();
        
        return data;
        
      } else {
        // ❌ Error en el login
        if (this.debugMode) {
          console.error('❌ [DEBUG] Error en login:', data);
        }
        
        // Manejo específico de errores
        this.handleLoginError(data, email, response.status);
        throw new Error(data.detail?.message || 'Error en el inicio de sesión');
      }
      
    } catch (error) {
      if (this.debugMode) {
        console.error('🔥 [DEBUG] Error catch en auth.login:', error);
        console.error('🔥 [DEBUG] Error name:', error.name);
        console.error('🔥 [DEBUG] Error message:', error.message);
      }
      
      // Si es un error de red o servidor
      if (error.name === 'TypeError' || error.message.includes('Failed to fetch')) {
        this.showLoginError(
          'Error de conexión con el servidor. Verifica que el backend esté ejecutándose.',
          'connection'
        );
        
        if (this.debugMode) {
          console.error('🌐 [DEBUG] Error de red, verificando backend...');
          this.testBackendConnection();
        }
      } else if (!error.message.includes('Error en el inicio de sesión')) {
        // Solo mostrar error genérico si no fue manejado específicamente
        this.showLoginError(
          error.message || 'Ha ocurrido un error inesperado. Intente nuevamente.',
          'general'
        );
      }
      
      throw error;
    } finally {
      if (this.debugMode) {
        console.log('🔚 [DEBUG] Finalizando login (finally)');
      }
      
      // Ocultar estado de carga
      this.showLoading(false);
    }
  },
  
  // Función para probar conexión al backend
  async testBackendConnection() {
    try {
      console.log('🌐 Probando conexión con backend...');
      const response = await fetch(window.API_BASE || 'http://localhost:8000');
      console.log('Status:', response.status);
      
      if (response.ok) {
        console.log('✅ Backend disponible');
        return true;
      } else {
        console.error('❌ Backend error:', response.status);
        return false;
      }
    } catch (error) {
      console.error('❌ No se puede conectar al backend:', error.message);
      return false;
    }
  },
  
  // Mostrar loading
  showLoading(show) {
    const btnLogin = document.getElementById('btnLogin');
    if (!btnLogin) {
      console.error('❌ btnLogin no encontrado');
      return;
    }
    
    if (show) {
      if (this.debugMode) {
        console.log('⏳ [DEBUG] Mostrando loading...');
      }
      
      btnLogin.innerHTML = `
        <span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>
        Validando...
      `;
      btnLogin.disabled = true;
    } else {
      if (this.debugMode) {
        console.log('✅ [DEBUG] Ocultando loading...');
      }
      
      btnLogin.innerHTML = '<i class="bi bi-box-arrow-in-right me-2"></i>Acceder';
      btnLogin.disabled = false;
    }
  },
  
  // Actualizar UI después del login
  updateUIAfterLogin() {
    if (this.debugMode) {
      console.log('🎭 [DEBUG] Actualizando UI después de login...');
      console.log('🎭 [DEBUG] currentUser:', currentUser);
    }
    
    if (!currentUser) {
      console.error('❌ No hay currentUser para actualizar UI');
      return;
    }
    
    // 1. Ocultar panel de login y mostrar menú
    const panelLogin = document.getElementById('panel-login');
    const menu = document.getElementById('menu');
    const userInfo = document.getElementById('userInfo');
    
    if (panelLogin) panelLogin.classList.add('hidden');
    if (menu) menu.classList.remove('hidden');
    if (userInfo) userInfo.classList.remove('hidden');
    
    // 2. Actualizar información del usuario en el header
    const userEmail = document.getElementById('userEmail');
    const userRole = document.getElementById('userRole');
    
    if (userEmail) userEmail.textContent = currentUser.correo;
    if (userRole) {
      userRole.textContent = currentUser.rol;
      // Agregar clase CSS para el badge según rol
      userRole.className = 'role-badge mt-1';
      if (currentUser.rol === 'Administrador' || currentUser.rol === 'Dueño' || currentUser.rol === 'Admin') {
        userRole.classList.add('admin-role');
      } else if (currentUser.rol === 'Cliente') {
        userRole.classList.add('client-role');
      }
    }
    
    // 3. Construir menú según rol
    if (typeof window.buildMenuForRole === 'function') {
      window.buildMenuForRole(currentUser.rol);
    } else {
      console.warn('⚠️ buildMenuForRole no disponible, usando función básica');
      this.buildMenuForRole(currentUser.rol);
    }
    
    // 4. Mostrar sección por defecto según rol
    setTimeout(() => {
      if (typeof window.showSection === 'function') {
        if (currentUser.rol === 'Cliente') {
          window.showSection('catalogo');
        } else {
          window.showSection('listaPedidos');
        }
      } else {
        console.error('❌ No hay función showSection disponible');
      }
    }, 100);
    
    // 5. Cargar vistas después del login
    setTimeout(() => {
      if (typeof window.populateAllViews === 'function') {
        window.populateAllViews();
      }
    }, 500);
    
    if (this.debugMode) {
      console.log('✅ [DEBUG] UI actualizada correctamente');
    }
  },
  
  // Construir menú según rol
  buildMenuForRole(role) {
    const menu = document.getElementById('menu-links');
    if (!menu) {
      console.error('❌ Menú no encontrado');
      return;
    }
    
    console.log('🔨 Construyendo menú para rol:', role);
    
    menu.innerHTML = '';
    
    const addLink = (label, target, icon = '') => {
      const a = document.createElement('a');
      a.className = 'nav-link';
      a.innerHTML = `${icon} ${label}`;
      a.onclick = () => { 
        if (typeof window.showSection === 'function') {
          window.showSection(target);
        }
      };
      menu.appendChild(a);
    };

    // Menú base para todos
    addLink('Inicio', 'home', '🏠');

    if (role === 'Cliente') {
      addLink('Catálogo', 'catalogo', '🛍️');
      addLink('Mis pedidos', 'misPedidos', '📦');
      addLink('Anular pedido', 'anulacion', '❌');
    } 
    else if (role === 'Administrador' || role === 'Admin' || role === 'Dueño') {
      addLink('👥 Gestión de Usuarios', 'gestionUsuarios', '👥');
      addLink('Todos los Pedidos', 'listaPedidos', '📋');
      addLink('📋 Órdenes de Despacho', 'asignaciones', '📋');
      addLink('Caja Virtual', 'cajaVirtual', '💰');
      addLink('📊 Reportes', 'reportes', '📊');
      addLink('🛍️ Gestión Productos', 'gestionProductos', '🛍️');
      addLink('Catálogo', 'catalogo', '🛍️');
    }
    
    const menuElement = document.getElementById('menu');
    if (menuElement) {
      menuElement.classList.remove('hidden');
      console.log('✅ Menú mostrado');
    }
  },
  
  // Verificar bloqueo local
  checkLocalBlock(email) {
    if (!this.failedAttempts[email]) {
      return { blocked: false };
    }
    
    const attemptData = this.failedAttempts[email];
    
    // Si tiene bloqueo local activo
    if (attemptData.blockedUntil && attemptData.blockedUntil > Date.now()) {
      const secondsLeft = Math.ceil((attemptData.blockedUntil - Date.now()) / 1000);
      return {
        blocked: true,
        secondsLeft: secondsLeft,
        attempts: attemptData.attempts
      };
    }
    
    // Si el bloqueo expiró, limpiarlo
    if (attemptData.blockedUntil && attemptData.blockedUntil <= Date.now()) {
      delete this.failedAttempts[email];
    }
    
    return { blocked: false };
  },
  
  // Registrar intento fallido localmente
  recordFailedAttempt(email) {
    if (!this.failedAttempts[email]) {
      this.failedAttempts[email] = {
        attempts: 0,
        lastAttempt: Date.now()
      };
    }
    
    this.failedAttempts[email].attempts++;
    this.failedAttempts[email].lastAttempt = Date.now();
    
    const attempts = this.failedAttempts[email].attempts;
    const remaining = Math.max(0, 5 - attempts);
    
    // Si alcanza 5 intentos, bloquear localmente por 10 segundos
    if (attempts >= 5) {
      this.blockAccountLocally(email, 10);
    }
    
    return {
      attempts: attempts,
      remaining: remaining
    };
  },
  
  // Bloquear cuenta localmente
  blockAccountLocally(email, seconds) {
    console.log(`🔒 Bloqueando localmente ${email} por ${seconds} segundos`);
    
    if (!this.failedAttempts[email]) {
      this.failedAttempts[email] = {
        attempts: 5,
        lastAttempt: Date.now()
      };
    }
    
    this.failedAttempts[email].blockedUntil = Date.now() + (seconds * 1000);
    
    // Configurar auto-desbloqueo
    setTimeout(() => {
      if (this.failedAttempts[email]) {
        delete this.failedAttempts[email].blockedUntil;
      }
    }, seconds * 1000);
  },
  
  // Limpiar intentos fallidos
  clearFailedAttempts(email) {
    if (this.failedAttempts[email]) {
      delete this.failedAttempts[email];
    }
    
    // También limpiar cualquier timer activo
    if (this.blockTimers[email]) {
      clearInterval(this.blockTimers[email]);
      delete this.blockTimers[email];
    }
  },
  
  // Mostrar cuenta bloqueada
  showAccountBlocked(email, secondsLeft, isLocalBlock) {
    const message = isLocalBlock 
      ? `Cuenta temporalmente bloqueada por seguridad.`
      : `Demasiados intentos fallidos. Cuenta bloqueada por seguridad.`;
    
    this.showLoginError(`
      <strong>🚫 CUENTA BLOQUEADA</strong><br>
      <small>${message}</small><br>
      <small class="text-warning">Tiempo restante: <span id="blockCountdown">${secondsLeft}</span> segundos</small>
    `, 'blocked');
    
    // Deshabilitar campos del formulario
    const emailInput = document.getElementById('email_login');
    const passwordInput = document.getElementById('pass_login');
    const loginButton = document.getElementById('btnLogin');
    
    if (emailInput) emailInput.disabled = true;
    if (passwordInput) passwordInput.disabled = true;
    if (loginButton) loginButton.disabled = true;
    
    // Agregar clase de bloqueo
    const form = document.querySelector('#panel-login');
    if (form) {
      form.classList.add('account-blocked');
    }
  },
  
  // Función para manejar errores específicos
  handleLoginError(errorData, email, statusCode) {
    console.log('🔧 Manejo específico de error:', errorData);
    
    const emailInput = document.getElementById('email_login');
    const passwordInput = document.getElementById('pass_login');
    
    // Bloqueo por muchos intentos (429 Too Many Requests)
    if (statusCode === 429 || errorData.error_type === 'ACCOUNT_BLOCKED') {
      this.handleAccountBlocked(errorData, email);
      return;
    }
    
    // Email no encontrado
    if (errorData.error_type === 'EMAIL_NOT_FOUND') {
      this.showLoginError(`
        <strong>Correo no encontrado</strong><br>
        <small>El correo <em>${email}</em> no está registrado.</small>
      `, 'email');
      
      if (emailInput) {
        emailInput.classList.add('is-invalid');
        emailInput.focus();
      }
      
      this.showSuggestion(`
        ¿Es tu primera vez aquí? 
        <button onclick="auth.showRegisterSuggestion('${email}')" class="btn btn-link p-0">
          Regístrate ahora
        </button>
      `);
      
    } 
    // Contraseña incorrecta (pero no bloqueado aún)
    else if (errorData.error_type === 'INVALID_PASSWORD') {
      // Registrar intento fallido localmente
      const attemptInfo = this.recordFailedAttempt(email);
      
      this.showLoginError(`
        <strong>Contraseña incorrecta</strong><br>
        <small>Intento ${attemptInfo.attempts} de 5.</small>
      `, 'password');
      
      if (passwordInput) {
        passwordInput.classList.add('is-invalid');
        passwordInput.value = '';
        passwordInput.focus();
      }
      
      this.showSuggestion(`
        ${errorData.suggestion || `Te quedan ${attemptInfo.remaining} intentos antes del bloqueo.`}<br>
        <button onclick="auth.showPasswordRecovery()" class="btn btn-link p-0">
          ¿Olvidaste tu contraseña?
        </button>
      `);
      
    } 
    // Error general
    else {
      this.showLoginError(`
        <strong>${errorData.message || 'Error en el inicio de sesión'}</strong><br>
        <small>${errorData.suggestion || 'Intente nuevamente.'}</small>
      `, 'general');
    }
  },
  
  // Manejar cuentas bloqueadas
  handleAccountBlocked(errorData, email) {
    console.log('🚫 Cuenta bloqueada:', email);
    
    // Extraer tiempo de bloqueo
    let secondsLeft = 10; // Default 10 segundos
    
    if (errorData.seconds_left) {
      secondsLeft = errorData.seconds_left;
    } else if (errorData.blocked_until) {
      const blockedUntil = new Date(errorData.blocked_until);
      secondsLeft = Math.max(1, Math.floor((blockedUntil - new Date()) / 1000));
    }
    
    // Bloquear localmente
    this.blockAccountLocally(email, secondsLeft);
    
    // Mostrar mensaje de bloqueo
    this.showAccountBlocked(email, secondsLeft, false);
  },
  
  // Mostrar error en la UI
  showLoginError(message, type = 'general') {
    console.log(`⚠️ Mostrando error de login (${type}):`, message);
    
    // Contenedor para mensajes
    let errorContainer = document.getElementById('loginErrorContainer');
    
    if (!errorContainer) {
      errorContainer = document.createElement('div');
      errorContainer.id = 'loginErrorContainer';
      errorContainer.className = 'mt-3';
      
      // Insertar después del formulario de login
      const loginPanel = document.getElementById('panel-login');
      if (loginPanel) {
        loginPanel.appendChild(errorContainer);
      } else {
        document.body.appendChild(errorContainer);
      }
    }
    
    // Limpiar y crear nueva alerta
    errorContainer.innerHTML = '';
    
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-danger alert-dismissible fade show';
    alertDiv.setAttribute('role', 'alert');
    alertDiv.style.cssText = `
      animation: slideIn 0.3s ease-out;
      border-left: 4px solid #dc3545;
    `;
    
    alertDiv.innerHTML = `
      <div class="d-flex align-items-center">
        <i class="bi bi-exclamation-triangle-fill me-2 fs-5"></i>
        <div class="flex-grow-1">
          ${message}
        </div>
        <button type="button" class="btn-close btn-close-white" 
                onclick="this.parentElement.parentElement.remove()"></button>
      </div>
    `;
    
    errorContainer.appendChild(alertDiv);
    
    // Auto-eliminar después de 8 segundos
    setTimeout(() => {
      if (alertDiv.parentNode) {
        alertDiv.remove();
      }
    }, 8000);
    
    // Agregar animación si no existe
    this.ensureAnimations();
  },

  // Mostrar éxito en login
  showLoginSuccess(message) {
    console.log('✅ Mostrando éxito de login:', message);
    
    let successContainer = document.getElementById('loginSuccessContainer');
    
    if (!successContainer) {
      successContainer = document.createElement('div');
      successContainer.id = 'loginSuccessContainer';
      successContainer.className = 'mt-3';
      
      const loginPanel = document.getElementById('panel-login');
      if (loginPanel) {
        loginPanel.appendChild(successContainer);
      }
    }
    
    successContainer.innerHTML = '';
    
    const alertDiv = document.createElement('div');
    alertDiv.className = 'alert alert-success alert-dismissible fade show';
    alertDiv.setAttribute('role', 'alert');
    alertDiv.style.cssText = `
      animation: slideIn 0.3s ease-out;
      border-left: 4px solid #28a745;
    `;
    
    alertDiv.innerHTML = `
      <div class="d-flex align-items-center">
        <i class="bi bi-check-circle-fill me-2 fs-5"></i>
        <div class="flex-grow-1">
          ${message}
        </div>
        <button type="button" class="btn-close" 
                onclick="this.parentElement.parentElement.remove()"></button>
      </div>
    `;
    
    successContainer.appendChild(alertDiv);
    
    // Auto-eliminar después de 5 segundos
    setTimeout(() => {
      if (alertDiv.parentNode) {
        alertDiv.remove();
      }
    }, 5000);
  },

  // Mostrar sugerencias
  showSuggestion(message) {
    console.log('💡 Mostrando sugerencia:', message);
    
    let suggestionContainer = document.getElementById('loginSuggestionContainer');
    
    if (!suggestionContainer) {
      suggestionContainer = document.createElement('div');
      suggestionContainer.id = 'loginSuggestionContainer';
      suggestionContainer.className = 'mt-2';
      
      const loginPanel = document.getElementById('panel-login');
      if (loginPanel) {
        loginPanel.appendChild(suggestionContainer);
      }
    }
    
    suggestionContainer.innerHTML = '';
    
    const suggestionDiv = document.createElement('div');
    suggestionDiv.className = 'alert alert-info';
    suggestionDiv.setAttribute('role', 'alert');
    suggestionDiv.style.cssText = `
      animation: slideIn 0.3s ease-out;
      border-left: 4px solid #17a2b8;
      font-size: 0.9rem;
    `;
    
    suggestionDiv.innerHTML = `
      <div class="d-flex align-items-center">
        <i class="bi bi-lightbulb-fill me-2"></i>
        <div class="flex-grow-1">
          ${message}
        </div>
      </div>
    `;
    
    suggestionContainer.appendChild(suggestionDiv);
    
    // Auto-eliminar después de 10 segundos
    setTimeout(() => {
      if (suggestionDiv.parentNode) {
        suggestionDiv.remove();
      }
    }, 10000);
  },

  // Limpiar todos los mensajes
  clearLoginMessages() {
    console.log('🧹 Limpiando mensajes de login');
    
    const containers = ['loginErrorContainer', 'loginSuccessContainer', 'loginSuggestionContainer'];
    
    containers.forEach(id => {
      const container = document.getElementById(id);
      if (container) {
        container.innerHTML = '';
      }
    });
    
    // Remover clases de error de los inputs
    const emailInput = document.getElementById('email_login');
    const passwordInput = document.getElementById('pass_login');
    
    if (emailInput) emailInput.classList.remove('is-invalid');
    if (passwordInput) passwordInput.classList.remove('is-invalid');
  },

  // Asegurar que las animaciones CSS estén disponibles
  ensureAnimations() {
    if (!document.getElementById('login-animations')) {
      const style = document.createElement('style');
      style.id = 'login-animations';
      style.textContent = `
        @keyframes slideIn {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          10%, 30%, 50%, 70%, 90% { transform: translateX(-5px); }
          20%, 40%, 60%, 80% { transform: translateX(5px); }
        }
        
        .is-invalid {
          animation: shake 0.5s ease-in-out;
          border-color: #dc3545 !important;
        }
        
        .is-invalid:focus {
          border-color: #dc3545;
          box-shadow: 0 0 0 0.25rem rgba(220, 53, 69, 0.25);
        }
        
        .role-badge {
          display: inline-block;
          padding: 0.25rem 0.5rem;
          border-radius: 0.25rem;
          font-size: 0.75rem;
          font-weight: 600;
          background: rgba(255, 255, 255, 0.1);
          color: white;
        }
        
        .role-badge.admin-role {
          background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
          color: white;
        }
        
        .role-badge.client-role {
          background: linear-gradient(135deg, #11998e 0%, #38ef7d 100%);
          color: white;
        }
      `;
      document.head.appendChild(style);
    }
  },

  // Sugerencia de registro
  showRegisterSuggestion(email) {
    console.log(`📝 Mostrando sugerencia de registro para: ${email}`);
    
    this.clearLoginMessages();
    
    this.showSuggestion(`
      <strong>¿Nuevo en La Cava del Valle?</strong><br>
      El correo <em>${email}</em> no está registrado. ¿Deseas crear una cuenta?
    `);
    
    // Agregar botón de registro rápido
    setTimeout(() => {
      const suggestionContainer = document.getElementById('loginSuggestionContainer');
      if (suggestionContainer) {
        const registerBtn = document.createElement('button');
        registerBtn.className = 'btn btn-success btn-sm mt-2';
        registerBtn.innerHTML = '<i class="bi bi-person-plus me-1"></i> Crear cuenta ahora';
        registerBtn.onclick = () => this.register(email, 'temporal123', email.split('@')[0]);
        suggestionContainer.appendChild(registerBtn);
      }
    }, 300);
  },

  // Función de registro
  async register(email, password, nombre) {
    try {
      console.log(`📝 Iniciando registro para: ${email}`);
      
      // Mostrar loading
      this.showLoading(true);
      this.clearLoginMessages();
      
      // Validaciones en frontend
      if (!email || !email.includes('@')) {
        this.showLoginError('Por favor, ingresa un correo electrónico válido.', 'email');
        this.showLoading(false);
        return;
      }
      
      if (!password || password.length < 6) {
        this.showLoginError('La contraseña debe tener al menos 6 caracteres.', 'password');
        this.showLoading(false);
        return;
      }
      
      // Llamar al endpoint de registro
      const response = await fetch(`${window.API_BASE || 'http://localhost:8000'}/usuarios/register`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({
          nombre: nombre || email.split('@')[0],
          correo: email,
          contraseña: password,
          rol: 'Cliente'
        })
      });
      
      const result = await response.json();
      
      if (response.ok) {
        console.log('✅ Registro exitoso:', result);
        
        // Mostrar mensaje de éxito detallado
        this.showLoginSuccess(`
          <strong>¡Cuenta creada exitosamente!</strong><br>
          <small>Ahora puedes iniciar sesión con tu correo y contraseña.</small>
        `);
        
        // Pre-llenar el formulario de login
        const emailInput = document.getElementById('email_login');
        const passwordInput = document.getElementById('pass_login');
        
        if (emailInput) emailInput.value = email;
        if (passwordInput) passwordInput.value = password;
        
        return result;
        
      } else {
        // Manejo de errores de registro
        this.handleRegistrationError(result, email);
        throw new Error(result.detail?.message || 'Error al crear la cuenta');
      }
      
    } catch (error) {
      console.error('❌ Error en registro:', error);
      
      // Si no fue un error manejado específicamente
      if (!error.message.includes('Error al crear la cuenta')) {
        this.showLoginError(`
          <strong>Error al crear la cuenta</strong><br>
          <small>${error.message || 'Intenta con un correo diferente.'}</small>
        `, 'register');
      }
      
      throw error;
    } finally {
      this.showLoading(false);
    }
  },
  
  // Manejar errores de registro específicos
  handleRegistrationError(errorData, email) {
    console.log('🔧 Manejo de error de registro:', errorData);
    
    if (errorData.error_type === 'USER_ALREADY_EXISTS') {
      // Correo ya registrado
      this.showLoginError(`
        <strong>Correo ya registrado</strong><br>
        <small>El correo <em>${email}</em> ya está en uso.</small>
      `, 'email');
      
      // Sugerencias específicas
      this.showSuggestion(`
        ${errorData.suggestion || 'Intenta iniciar sesión o usa un correo diferente.'}<br>
        <button onclick="auth.showLoginWithEmail('${email}')" class="btn btn-link p-0" style="text-decoration: underline;">
          Iniciar sesión con este correo
        </button>
      `);
      
      // Resaltar campo email
      const emailInput = document.getElementById('email_login');
      if (emailInput) {
        emailInput.classList.add('is-invalid');
        emailInput.focus();
      }
      
    } else if (errorData.error_type === 'INVALID_EMAIL_FORMAT') {
      // Formato de email inválido
      this.showLoginError(`
        <strong>Formato de correo inválido</strong><br>
        <small>El correo ingresado no tiene un formato válido.</small>
      `, 'email');
      
      this.showSuggestion('Ejemplo de formato válido: usuario@ejemplo.com');
      
    } else if (errorData.error_type === 'WEAK_PASSWORD') {
      // Contraseña débil
      this.showLoginError(`
        <strong>Contraseña muy corta</strong><br>
        <small>La contraseña debe tener al menos 6 caracteres.</small>
      `, 'password');
      
      const passwordInput = document.getElementById('pass_login');
      if (passwordInput) {
        passwordInput.classList.add('is-invalid');
        passwordInput.focus();
      }
      
    } else {
      // Error general
      this.showLoginError(`
        <strong>${errorData.message || 'Error al crear la cuenta'}</strong><br>
        <small>${errorData.suggestion || 'Intenta nuevamente.'}</small>
      `, 'register');
    }
  },
  
  // Mostrar formulario de login con email pre-llenado
  showLoginWithEmail(email) {
    this.clearLoginMessages();
    
    const emailInput = document.getElementById('email_login');
    const passwordInput = document.getElementById('pass_login');
    
    if (emailInput) {
      emailInput.value = email;
      emailInput.focus();
    }
    
    if (passwordInput) {
      passwordInput.value = '';
      passwordInput.placeholder = 'Ingresa tu contraseña';
    }
    
    this.showSuggestion(`
      <strong>Iniciar sesión</strong><br>
      El correo ${email} ya está registrado. Ingresa tu contraseña para continuar.
    `);
  },
  
  // Recuperación de contraseña
  showPasswordRecovery() {
    console.log('🔑 Mostrando panel de recuperación de contraseña');
    
    // Ocultar panel de login
    const loginPanel = document.getElementById('panel-login');
    const recoveryPanel = document.getElementById('panel-password-recovery');
    
    if (loginPanel) loginPanel.classList.add('hidden');
    if (recoveryPanel) {
      recoveryPanel.classList.remove('hidden');
      recoveryPanel.classList.add('fade-in');
    }
    
    // Limpiar campos
    this.clearRecoveryFields();
    
    // Enfocar el campo de email
    setTimeout(() => {
      const emailInput = document.getElementById('recovery_email');
      if (emailInput) emailInput.focus();
    }, 100);
  },
  
  // Volver al login desde recuperación
  backToLogin() {
    console.log('↩️ Volviendo al login');
    
    const loginPanel = document.getElementById('panel-login');
    const recoveryPanel = document.getElementById('panel-password-recovery');
    
    if (recoveryPanel) recoveryPanel.classList.add('hidden');
    if (loginPanel) {
      loginPanel.classList.remove('hidden');
      loginPanel.classList.add('fade-in');
    }
    
    // Limpiar mensajes
    this.clearLoginMessages();
  },
  
  // Simular envío de email de recuperación
  async sendRecoveryEmail() {
    const emailInput = document.getElementById('recovery_email');
    if (!emailInput) return;
    
    const email = emailInput.value.trim();
    
    if (!email || !email.includes('@')) {
      this.showRecoveryError('Por favor, ingresa un correo electrónico válido.');
      return;
    }
    
    console.log(`📧 Simulando envío de email de recuperación a: ${email}`);
    
    // Mostrar loading
    const sendBtn = document.getElementById('btnSendRecovery');
    const originalText = sendBtn.innerHTML;
    sendBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Enviando...';
    sendBtn.disabled = true;
    
    // Simular delay de red
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Restaurar botón
    sendBtn.innerHTML = originalText;
    sendBtn.disabled = false;
    
    // Mostrar pasos de recuperación
    this.showRecoverySteps(email);
  },
  
  // Mostrar los pasos de recuperación (simulados)
  showRecoverySteps(email) {
    const recoverySteps = document.getElementById('recovery-steps');
    const demoEmail = document.getElementById('demo-email');
    const demoEmailAddress = document.getElementById('demo-email-address');
    
    if (recoverySteps && demoEmail && demoEmailAddress) {
      recoverySteps.classList.remove('hidden');
      recoverySteps.classList.add('fade-in');
      
      demoEmail.textContent = email;
      demoEmailAddress.textContent = email;
      
      // Scroll a la sección
      recoverySteps.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  },
  
  // Simular clic en enlace de recuperación
  simulateResetPassword() {
    console.log('🔄 Simulando restablecimiento de contraseña');
    
    // Ocultar pasos de email
    const recoverySteps = document.getElementById('recovery-steps');
    const resetPanel = document.getElementById('panel-reset-password');
    
    if (recoverySteps) recoverySteps.classList.add('hidden');
    if (resetPanel) {
      resetPanel.classList.remove('hidden');
      resetPanel.classList.add('fade-in');
      
      // Enfocar campo de nueva contraseña
      setTimeout(() => {
        const newPassInput = document.getElementById('new_password');
        if (newPassInput) newPassInput.focus();
      }, 100);
    }
  },
  
  // Simular actualización de contraseña
  async simulatePasswordUpdate() {
    const newPassword = document.getElementById('new_password')?.value;
    const confirmPassword = document.getElementById('confirm_password')?.value;
    
    if (!newPassword || !confirmPassword) {
      this.showRecoveryError('Por favor, completa ambos campos.');
      return;
    }
    
    if (newPassword !== confirmPassword) {
      this.showRecoveryError('Las contraseñas no coinciden.');
      return;
    }
    
    if (newPassword.length < 6) {
      this.showRecoveryError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    
    console.log('🔐 Simulando actualización de contraseña');
    
    // Mostrar loading
    const confirmBtn = document.getElementById('btnConfirmReset');
    const originalText = confirmBtn.innerHTML;
    confirmBtn.innerHTML = '<span class="spinner-border spinner-border-sm"></span> Actualizando...';
    confirmBtn.disabled = true;
    
    // Simular delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mostrar éxito
    this.showRecoverySuccess('¡Contraseña actualizada exitosamente! (simulación)');
    
    // Después de 2 segundos, volver al login
    setTimeout(() => {
      this.backToLogin();
      
      // Pre-llenar el email en el login
      const email = document.getElementById('recovery_email')?.value;
      const loginEmail = document.getElementById('email_login');
      if (email && loginEmail) {
        loginEmail.value = email;
      }
      
      // Mostrar mensaje de éxito en el login
      this.showLoginSuccess('Demo completada. En producción, tu contraseña habría sido actualizada.');
    }, 2000);
  },
  
  // Mostrar error en recuperación
  showRecoveryError(message) {
    const recoveryPanel = document.getElementById('panel-password-recovery');
    if (!recoveryPanel) return;
    
    // Eliminar mensajes anteriores
    const existingError = recoveryPanel.querySelector('.recovery-error');
    if (existingError) existingError.remove();
    
    // Crear nuevo mensaje
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger recovery-error mt-2';
    errorDiv.innerHTML = `
      <i class="bi bi-exclamation-triangle-fill me-1"></i>
      ${message}
    `;
    
    recoveryPanel.insertBefore(errorDiv, recoveryPanel.firstChild);
    
    // Auto-eliminar después de 5 segundos
    setTimeout(() => {
      if (errorDiv.parentNode) {
        errorDiv.remove();
      }
    }, 5000);
  },
  
  // Mostrar éxito en recuperación
  showRecoverySuccess(message) {
    const recoveryPanel = document.getElementById('panel-password-recovery');
    if (!recoveryPanel) return;
    
    // Eliminar mensajes anteriores
    const existingSuccess = recoveryPanel.querySelector('.recovery-success');
    if (existingSuccess) existingSuccess.remove();
    
    // Crear nuevo mensaje
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success recovery-success mt-2';
    successDiv.innerHTML = `
      <i class="bi bi-check-circle-fill me-1"></i>
      ${message}
    `;
    
    recoveryPanel.insertBefore(successDiv, recoveryPanel.firstChild);
  },
  
  // Limpiar campos de recuperación
  clearRecoveryFields() {
    const emailInput = document.getElementById('recovery_email');
    const newPassInput = document.getElementById('new_password');
    const confirmPassInput = document.getElementById('confirm_password');
    
    if (emailInput) emailInput.value = '';
    if (newPassInput) newPassInput.value = '';
    if (confirmPassInput) confirmPassInput.value = '';
    
    // Ocultar secciones
    const recoverySteps = document.getElementById('recovery-steps');
    const resetPanel = document.getElementById('panel-reset-password');
    
    if (recoverySteps) recoverySteps.classList.add('hidden');
    if (resetPanel) resetPanel.classList.add('hidden');
    
    // Limpiar mensajes
    const recoveryPanel = document.getElementById('panel-password-recovery');
    if (recoveryPanel) {
      const messages = recoveryPanel.querySelectorAll('.alert');
      messages.forEach(msg => msg.remove());
    }
  },
  
  // Inicializar event listeners para recuperación
  initPasswordRecoveryListeners() {
    // Botón "¿Olvidaste tu contraseña?"
    const btnForgotPassword = document.getElementById('btnForgotPassword');
    if (btnForgotPassword) {
      btnForgotPassword.addEventListener('click', () => {
        this.showPasswordRecovery();
      });
    }
    
    // Botón "Volver al login"
    const btnBackToLogin = document.getElementById('btnBackToLogin');
    if (btnBackToLogin) {
      btnBackToLogin.addEventListener('click', () => {
        this.backToLogin();
      });
    }
    
    // Botón "Enviar enlace de recuperación"
    const btnSendRecovery = document.getElementById('btnSendRecovery');
    if (btnSendRecovery) {
      btnSendRecovery.addEventListener('click', () => {
        this.sendRecoveryEmail();
      });
      
      // También permitir Enter en el campo de email
      const recoveryEmail = document.getElementById('recovery_email');
      if (recoveryEmail) {
        recoveryEmail.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
            this.sendRecoveryEmail();
          }
        });
      }
    }
    
    // Botón "Simular restablecimiento de contraseña"
    const btnResetDemo = document.getElementById('btnResetPasswordDemo');
    if (btnResetDemo) {
      btnResetDemo.addEventListener('click', () => {
        this.simulateResetPassword();
      });
    }
    
    // Botón "Actualizar contraseña"
    const btnConfirmReset = document.getElementById('btnConfirmReset');
    if (btnConfirmReset) {
      btnConfirmReset.addEventListener('click', () => {
        this.simulatePasswordUpdate();
      });
      
      // Permitir Enter en campos de contraseña
      const newPassword = document.getElementById('new_password');
      const confirmPassword = document.getElementById('confirm_password');
      
      if (newPassword) {
        newPassword.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
            this.simulatePasswordUpdate();
          }
        });
      }
      
      if (confirmPassword) {
        confirmPassword.addEventListener('keypress', (e) => {
          if (e.key === 'Enter') {
            this.simulatePasswordUpdate();
          }
        });
      }
    }
  },
  
  // Logout
  logout() {
    console.log('🚪 Cerrando sesión');
    
    currentUser = null;
    
    // Limpiar UI
    const panelLogin = document.getElementById('panel-login');
    const menu = document.getElementById('menu');
    const userInfo = document.getElementById('userInfo');
    
    if (panelLogin) panelLogin.classList.remove('hidden');
    if (menu) menu.classList.add('hidden');
    if (userInfo) userInfo.classList.add('hidden');
    
    // Limpiar menú
    const menuLinks = document.getElementById('menu-links');
    if (menuLinks) menuLinks.innerHTML = '';
    
    // Limpiar mensajes
    this.clearLoginMessages();
    
    // Mostrar sección de inicio
    if (typeof window.showSection === 'function') {
      window.showSection('home');
    }
    
    // Mostrar mensaje de despedida
    this.showLoginSuccess('Sesión cerrada correctamente. ¡Vuelve pronto!');
  },
  
  // Verificar si es admin
  esAdmin: function() {
    return currentUser && (currentUser.rol === 'Administrador' || currentUser.rol === 'Admin' || currentUser.rol === 'Dueño');
  },
  
  // Obtener usuario actual
  getCurrentUser() {
    return currentUser;
  },
  
  // Función para forzar menú de admin (para debugging)
  forzarMenuAdmin() {
    console.log('👑 Forzando menú de administrador...');
    
    // Simular usuario admin
    currentUser = {
      correo: 'admin@lacavadelvalle.cl',
      rol: 'Administrador',
      nombre: 'Admin Forzado'
    };
    
    const userEmail = document.getElementById('userEmail');
    const userRole = document.getElementById('userRole');
    const userInfo = document.getElementById('userInfo');
    const panelLogin = document.getElementById('panel-login');
    
    if (userEmail) userEmail.innerText = currentUser.correo;
    if (userRole) userRole.innerText = currentUser.rol;
    if (userInfo) userInfo.classList.remove('hidden');
    if (panelLogin) panelLogin.classList.add('hidden');
    
    this.buildMenuForRole('Administrador');
    
    if (typeof showSection === 'function') {
      showSection('asignaciones');
    }
    
    return currentUser;
  }
};

// Exportar para uso global
window.auth = auth;
window.currentUser = currentUser;

// Inicializar listeners de recuperación cuando se cargue el DOM
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(() => {
    if (auth.initPasswordRecoveryListeners) {
      auth.initPasswordRecoveryListeners();
    }
  }, 500);
});

console.log('✅ auth.js (versión limpia) cargado correctamente');