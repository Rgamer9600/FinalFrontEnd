// Gestión del catálogo de productos - VERSIÓN CORREGIDA
const catalog = {
  // ✅ INICIALIZAR products como array vacío
  products: [],
  
  async loadProducts() {
    try {
      console.log('🔄 [catalog.js] Cargando productos...');
      const data = await api.getProducts();
      
      // ✅ Guardar en this.products para uso futuro
      this.products = data.map(product => ({
        id: product._id || product.id,
        _id: product._id,
        nombre: product.nombre,
        descripcion: product.descripcion,
        precio: product.precio,
        categoria: product.categoria,
        stock: product.stock,
        disponible: product.disponible !== false
      }));
      
      console.log(`✅ [catalog.js] ${this.products.length} productos cargados`);
      return this.products;
    } catch (error) {
      console.error('❌ [catalog.js] Error cargando productos:', error);
      this.products = [];
      return [];
    }
  },

  async populateCatalog() {
    console.log('📦 [catalog.js] Populando catálogo...');
    
    try {
      // ✅ 1. Primero cargar productos
      const products = await this.loadProducts();
      
      // ✅ 2. Ahora sí podemos usar products
      console.log(`📊 [catalog.js] ${products.length} productos cargados`);
      if (products.length > 0) {
        console.log('📋 Primer producto:', products[0]);
      }
      
      // ✅ 3. Obtener el grid
      const grid = $('catalogoGrid');
      if (!grid) {
        console.error('❌ [catalog.js] No se encontró #catalogoGrid');
        return;
      }
      
      // ✅ 4. Limpiar grid
      grid.innerHTML = '';

      // ✅ 5. Verificar si hay productos
      if (products.length === 0) {
        grid.innerHTML = `
          <div class="col-12">
            <div class="alert alert-info">
              No hay productos disponibles en este momento.
            </div>
          </div>
        `;
        return;
      }

      // ✅ 6. Renderizar cada producto
      products.forEach(product => {
        const productId = product._id || product.id;
        const col = document.createElement('div');
        col.className = 'col-md-4 mb-3';
        col.innerHTML = `
          <div class="card p-2 product-card">
            <h5>${product.nombre}</h5>
            <div class="tiny">Categoría: ${product.categoria} / Stock: ${product.stock}</div>
            <div class="mt-2"><strong>$ ${product.precio.toLocaleString()}</strong></div>
            <div class="mt-2 d-flex gap-2">
              <input type="number" class="form-control form-control-sm" 
                     id="qty-${productId}" value="1" min="1" max="${product.stock}" 
                     style="max-width:80px;">
              <button class="btn btn-sm btn-primary" onclick="catalog.addToCart('${productId}')">
                Agregar
              </button>
            </div>
          </div>`;
        grid.appendChild(col);
      });
      
      console.log(`✅ [catalog.js] Catálogo poblado con ${products.length} productos`);
      
    } catch (error) {
      console.error('❌ [catalog.js] Error en populateCatalog:', error);
      
      // Mostrar mensaje de error en el grid
      const grid = $('catalogoGrid');
      if (grid) {
        grid.innerHTML = `
          <div class="col-12">
            <div class="alert alert-danger">
              Error cargando productos: ${error.message}
            </div>
          </div>
        `;
      }
    }
  },

  addToCart(productId) {
    console.log(`🛒 [catalog.js] Agregando producto ${productId} al carrito`);
    
    if (!auth.getCurrentUser()) {
      alert('Debes iniciar sesión para agregar productos al carrito');
      return;
    }

    const qtyInput = $(`qty-${productId}`);
    const qty = Number(qtyInput?.value) || 1;

    console.log(`📦 Cantidad: ${qty}`);
    
    // Verificar que cart esté disponible
    if (typeof cart !== 'undefined' && typeof cart.addItem === 'function') {
      cart.addItem(productId, qty);
    } else {
      console.error('❌ [catalog.js] cart.addItem no disponible');
      alert('Error: Carrito no disponible temporalmente');
    }
  }
};

// Exportar para uso global
window.catalog = catalog;

// Debug helper
console.log('✅ catalog.js cargado correctamente');
console.log('📦 catalog.populateCatalog disponible:', typeof catalog.populateCatalog);