// Gestión del carrito de compras
let currentCart = [];
let currentOrderId = null;
let checkoutInProgress = false; // ✅ Nueva variable para prevenir doble ejecución

const cart = {
  // Agregar item al carrito
  addItem(productId, quantity) {
    console.log(`🛒 [cart.js] Agregando producto ${productId} x${quantity}`);
    
    // Buscar si el producto ya está en el carrito
    const existingItem = currentCart.find(item => item.producto_id === productId);
    
    if (existingItem) {
      existingItem.cantidad += quantity;
      console.log(`✅ [cart.js] Cantidad actualizada: ${existingItem.producto_id} x${existingItem.cantidad}`);
    } else {
      currentCart.push({
        producto_id: productId,
        cantidad: quantity
      });
      console.log(`✅ [cart.js] Producto agregado: ${productId} x${quantity}`);
    }

    this.render();
    this.showMessage('Producto agregado al carrito', 'success');
  },

  // Remover item del carrito
  removeItem(productId) {
    console.log(`🗑️ [cart.js] Removiendo producto ${productId}`);
    currentCart = currentCart.filter(item => item.producto_id !== productId);
    this.render();
    this.showMessage('Producto removido del carrito', 'info');
  },

  // Limpiar carrito
  clear() {
    console.log('🧹 [cart.js] Limpiando carrito');
    currentCart = [];
    this.render();
    this.showMessage('Carrito vaciado', 'info');
  },

  // Renderizar carrito en UI
  async render() {
    const out = document.getElementById('carritoList');
    if (!out) {
      console.warn('⚠️ [cart.js] No se encontró #carritoList');
      return;
    }
    
    out.innerHTML = '';

    if (currentCart.length === 0) {
      out.innerHTML = '<li class="list-group-item tiny text-center py-3"><i class="bi bi-cart-x me-2"></i>Carrito vacío</li>';
      return;
    }

    try {
      // Obtener productos completos para mostrar información
      const products = await this.loadProductsForCart();
      
      if (!products || products.length === 0) {
        out.innerHTML = '<li class="list-group-item tiny text-center py-3 text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Error cargando productos</li>';
        return;
      }
      
      let totalCarrito = 0;
      
      currentCart.forEach(item => {
        const product = products.find(p => p.id === item.producto_id);
        if (product) {
          const subtotal = product.precio * item.cantidad;
          totalCarrito += subtotal;
          
          const li = document.createElement('li');
          li.className = 'list-group-item d-flex justify-content-between align-items-center cart-item';
          li.innerHTML = `
            <div class="flex-grow-1">
              <div class="d-flex justify-content-between">
                <div>
                  <strong>${product.nombre}</strong><br>
                  <small class="text-muted">${product.categoria || 'Sin categoría'}</small>
                </div>
                <div class="text-end">
                  <small class="d-block">$${product.precio.toLocaleString()} c/u</small>
                  <small class="d-block text-muted">Subtotal: $${subtotal.toLocaleString()}</small>
                </div>
              </div>
              <div class="d-flex align-items-center mt-2">
                <small class="me-3">Cantidad: ${item.cantidad}</small>
                <button class="btn btn-sm btn-outline-danger ms-auto" 
                        onclick="cart.removeItem('${item.producto_id}')"
                        title="Eliminar del carrito">
                  <i class="bi bi-trash"></i> Quitar
                </button>
              </div>
            </div>
          `;
          out.appendChild(li);
        } else {
          console.warn(`⚠️ [cart.js] Producto ${item.producto_id} no encontrado en catálogo`);
        }
      });
      
      // Agregar total del carrito
      const totalLi = document.createElement('li');
      totalLi.className = 'list-group-item list-group-item-success d-flex justify-content-between align-items-center';
      totalLi.innerHTML = `
        <div>
          <strong>TOTAL CARRITO</strong>
          <small class="d-block text-muted">${currentCart.reduce((sum, item) => sum + item.cantidad, 0)} productos</small>
        </div>
        <div>
          <h5 class="mb-0">$${totalCarrito.toLocaleString()}</h5>
        </div>
      `;
      out.appendChild(totalLi);
      
      console.log(`✅ [cart.js] Carrito renderizado: ${currentCart.length} items, Total: $${totalCarrito}`);
      
    } catch (error) {
      console.error('❌ [cart.js] Error renderizando carrito:', error);
      out.innerHTML = '<li class="list-group-item text-danger"><i class="bi bi-exclamation-triangle me-2"></i>Error cargando carrito</li>';
    }
  },

  // Cargar productos para el carrito
  async loadProductsForCart() {
    try {
      console.log('🔄 [cart.js] Cargando productos para carrito...');
      
      // Intentar usar el catálogo existente
      if (window.catalog && typeof catalog.loadProducts === 'function') {
        const products = await catalog.loadProducts();
        console.log(`✅ [cart.js] ${products.length} productos cargados desde catalog.js`);
        return products;
      }
      
      // Fallback: cargar directamente desde API
      console.log('⚠️ [cart.js] catalog.js no disponible, cargando desde API...');
      const response = await fetch('http://localhost:8000/listar/');
      if (!response.ok) throw new Error('Error cargando productos');
      
      const products = await response.json();
      console.log(`✅ [cart.js] ${products.length} productos cargados desde API`);
      return products.map(p => ({
        id: p._id || p.id,
        nombre: p.nombre,
        precio: p.precio,
        categoria: p.categoria,
        descripcion: p.descripcion
      }));
      
    } catch (error) {
      console.error('❌ [cart.js] Error cargando productos:', error);
      return [];
    }
  },

  // Obtener items del carrito
  getItems() {
    return [...currentCart];
  },

  // Verificar si carrito está vacío
  isEmpty() {
    return currentCart.length === 0;
  },

  // Checkout - crear pedido
  async checkout() {
    console.log('🚀 [cart.js] Iniciando checkout...');
    
    // Verificar autenticación y carrito
    if (!auth.getCurrentUser()) {
      this.showMessage('Debes iniciar sesión para realizar un pedido', 'error');
      return null;
    }
    
    if (this.isEmpty()) {
      this.showMessage('El carrito está vacío', 'error');
      return null;
    }

    // ✅ PREVENIR DOBLE EJECUCIÓN
    if (checkoutInProgress) {
      console.log('⚠️ [cart.js] checkout ya en progreso, ignorando...');
      return null;
    }
    checkoutInProgress = true;

    try {
      // Preguntar tipo de entrega (SOLO UNA VEZ)
      const tipoEntrega = prompt('¿Cómo quieres recibir tu pedido?\n\n1. 🚚 Delivery (entrega a domicilio)\n2. 🏪 Retiro en local\n\nIngresa 1 o 2:', '1');
      
      if (!tipoEntrega) {
        console.log('❌ [cart.js] Usuario canceló selección de entrega');
        checkoutInProgress = false;
        return null;
      }
      
      const esDelivery = tipoEntrega === '1';
      let direccion = '';
      
      if (esDelivery) {
        direccion = prompt('📍 Por favor ingresa la dirección de entrega (calle, número, comuna):');
        if (!direccion || direccion.trim() === '') {
          alert('❌ Debes ingresar una dirección para delivery');
          checkoutInProgress = false;
          return null;
        }
        console.log(`📍 [cart.js] Dirección de entrega: ${direccion}`);
      }

      // OBTENER INFORMACIÓN COMPLETA DE LOS PRODUCTOS
      console.log('🔄 [cart.js] Obteniendo información completa de productos...');
      const products = await this.loadProductsForCart();
      const itemsCompletos = [];
      let itemsConError = false;
      
      for (const item of currentCart) {
        const product = products.find(p => p.id === item.producto_id);
        if (!product) {
          console.error(`❌ [cart.js] Producto ${item.producto_id} no encontrado en catálogo`);
          this.showMessage(`Error: Producto ${item.producto_id} no disponible`, 'error');
          itemsConError = true;
          continue;
        }
        
        itemsCompletos.push({
          producto_id: item.producto_id,
          nombre_producto: product.nombre,
          cantidad: item.cantidad,
          precio_unitario: product.precio
        });
        
        console.log(`✅ [cart.js] Producto procesado: ${product.nombre} x${item.cantidad}`);
      }
      
      if (itemsConError || itemsCompletos.length === 0) {
        this.showMessage('Error: No se pudo obtener información de algunos productos', 'error');
        checkoutInProgress = false;
        return null;
      }
      
      // Calcular total
      const total = itemsCompletos.reduce((sum, item) => {
        return sum + (item.precio_unitario * item.cantidad);
      }, 0);
      
      console.log(`💰 [cart.js] Total calculado: $${total.toLocaleString()}`);

      // Preparar datos del pedido
      const orderData = {
        cliente_correo: auth.getCurrentUser().correo,
        items: itemsCompletos,  // ✅ AHORA TIENE TODA LA INFORMACIÓN
        tipo_entrega: esDelivery ? "delivery" : "retiro",
        direccion_entrega: esDelivery ? direccion : null,
        total: total,
        estado: "pendiente"
      };

      console.log('📤 [cart.js] Enviando pedido a API:', orderData);
      
      // Crear pedido en backend
      const result = await api.createOrder(orderData);
      console.log('📦 [cart.js] Respuesta del pedido:', result);
      
      // Obtener ID del pedido creado
      currentOrderId = result._id || result.pedido_id || result.id;
      
      if (!currentOrderId) {
        console.error('❌ [cart.js] No se pudo obtener ID del pedido de la respuesta:', result);
        this.showMessage('Error al crear pedido: No se recibió ID', 'error');
        checkoutInProgress = false;
        return null;
      }
      
      console.log('✅ [cart.js] Pedido creado. ID:', currentOrderId);
      
      // Limpiar carrito después de éxito
      this.clear();
      
      // Mostrar mensaje de éxito
      const mensajeEntrega = esDelivery 
        ? `🚚 Pedido creado para delivery en: ${direccion}`
        : '🏪 Pedido creado para retiro en local';
      
      this.showMessage(`✅ Pedido creado exitosamente! ${mensajeEntrega}`, 'success');

      // Mostrar sección de pago
      console.log('💳 [cart.js] Mostrando sección de pago...');
      if (window.payments && typeof payments.showPaymentSection === 'function') {
        payments.showPaymentSection({
          pedido_id: currentOrderId,
          total: total,
          tipo_entrega: orderData.tipo_entrega
        });
      } else {
        console.error('❌ [cart.js] Módulo payments no disponible');
        this.showMessage('Error: Sistema de pagos no disponible', 'error');
      }
      
      checkoutInProgress = false;
      return {
        pedido_id: currentOrderId,
        total: total,
        tipo_entrega: orderData.tipo_entrega
      };
      
    } catch (error) {
      console.error('❌ [cart.js] Error en checkout:', error);
      this.showMessage(`Error al crear pedido: ${error.message}`, 'error');
      checkoutInProgress = false;
      return null;
    }
  },

  // Mostrar mensajes
  showMessage(message, type = 'info') {
    console.log(`💬 [cart.js] Mensaje (${type}): ${message}`);
    
    const msgElement = document.getElementById('msgCheckout');
    if (msgElement) {
      // Limpiar mensajes anteriores
      msgElement.innerHTML = '';
      
      // Crear alerta de Bootstrap
      const alertDiv = document.createElement('div');
      alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
      alertDiv.innerHTML = `
        ${type === 'error' ? '❌' : type === 'success' ? '✅' : 'ℹ️'} ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
      `;
      
      msgElement.appendChild(alertDiv);
      
      // Auto-remover después de 5 segundos
      setTimeout(() => {
        if (alertDiv.parentNode) {
          alertDiv.remove();
        }
      }, 5000);
    } else {
      // Fallback: usar alert nativo
      alert(message);
    }
  },

  // Obtener ID del pedido actual
  getCurrentOrderId() {
    return currentOrderId;
  },

  // Obtener total del carrito
  getTotal() {
    // Esta función sería útil para mostrar el total en tiempo real
    return currentCart.reduce((total, item) => {
      // Necesitaríamos los precios de los productos
      return total; // Placeholder
    }, 0);
  },

  // Actualizar cantidad de un producto
  updateQuantity(productId, newQuantity) {
    const item = currentCart.find(item => item.producto_id === productId);
    if (item) {
      if (newQuantity <= 0) {
        this.removeItem(productId);
      } else {
        item.cantidad = newQuantity;
        this.render();
        this.showMessage('Cantidad actualizada', 'info');
      }
    }
  },

  // Debug: mostrar estado del carrito
  debug() {
    console.log('🔍 [cart.js] Debug - Estado del carrito:');
    console.log(`  - Items: ${currentCart.length}`);
    console.log(`  - Contenido:`, currentCart);
    console.log(`  - Order ID actual: ${currentOrderId}`);
    console.log(`  - checkoutInProgress: ${checkoutInProgress}`);
    console.log(`  - Usuario:`, auth.getCurrentUser());
  }
};

// Función de utilidad para debug
window.debugCart = function() {
  cart.debug();
  
  // Mostrar en UI también
  const debugDiv = document.createElement('div');
  debugDiv.className = 'alert alert-info mt-3';
  debugDiv.innerHTML = `
    <h6>🔍 Debug Carrito</h6>
    <p>Items: ${currentCart.length}</p>
    <p>Order ID: ${currentOrderId || 'Ninguno'}</p>
    <p>Usuario: ${auth.getCurrentUser()?.correo || 'No logueado'}</p>
    <button class="btn btn-sm btn-outline-secondary" onclick="cart.render()">🔄 Renderizar</button>
    <button class="btn btn-sm btn-outline-danger ms-1" onclick="cart.clear()">🧹 Limpiar</button>
  `;
  
  const container = document.getElementById('msgCheckout') || document.body;
  container.appendChild(debugDiv);
  
  setTimeout(() => {
    if (debugDiv.parentNode) debugDiv.remove();
  }, 10000);
};

// Inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
  console.log('🛒 [cart.js] Módulo carrito cargado');
  
  // Renderizar carrito inicial
  setTimeout(() => {
    cart.render();
  }, 1000);
  
  // Agregar botón de debug en desarrollo
  if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
    console.log('🐛 [cart.js] Modo desarrollo: funciones debug disponibles');
    console.log('💡 Usa debugCart() para ver estado del carrito');
  }
});

// Exportar para uso global
window.cart = cart;
window.currentCart = currentCart;

// Hacer que currentCart sea reactivo (opcional)
Object.defineProperty(window, 'currentCart', {
  get() {
    return currentCart;
  },
  set(newValue) {
    currentCart = newValue;
    cart.render(); // Auto-renderizar cuando cambia
  }
});