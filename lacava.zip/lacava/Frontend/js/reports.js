// reports.js - Sistema de Reportes para La Cava del Valle (SIN GRÁFICOS)
const reports = {
    // Configuración
    initialized: false,
    
    // Métodos de inicialización
    async initialize() {
        if (this.initialized) return;
        
        console.log('📊 [reports.js] Inicializando sistema de reportes...');
        this.initialized = true;
        console.log('✅ [reports.js] Sistema de reportes inicializado');
    },
    
    // Obtener datos para reportes
    async getReportData(tipo, fechaInicio, fechaFin) {
        try {
            console.log(`📈 [reports.js] Obteniendo datos para ${tipo}: ${fechaInicio} a ${fechaFin}`);
            
            // Obtener todos los pedidos
            const response = await fetch(`${API_BASE}/pedidos/listar/`);
            const pedidos = await response.json();
            
            // Filtrar por fecha
            const pedidosFiltrados = pedidos.filter(pedido => {
                const fechaPedido = new Date(pedido.fecha || pedido.created_at);
                return fechaPedido >= new Date(fechaInicio) && 
                       fechaPedido <= new Date(fechaFin);
            });
            
            console.log(`📦 [reports.js] ${pedidosFiltrados.length} pedidos en el período`);
            return this.processReportData(pedidosFiltrados, tipo);
            
        } catch (error) {
            console.error('❌ [reports.js] Error obteniendo datos:', error);
            throw error;
        }
    },
    
    // Procesar datos para diferentes tipos de reportes
    processReportData(pedidos, tipo) {
        console.log(`🔄 [reports.js] Procesando ${pedidos.length} pedidos para reporte ${tipo}`);
        
        const reporte = {
            resumen: this.calcularResumen(pedidos),
            ventasPorDia: this.calcularVentasPorDia(pedidos),
            ventasPorProducto: this.calcularVentasPorProducto(pedidos),
            ventasPorMetodoPago: this.calcularVentasPorMetodoPago(pedidos),
            ventasPorTipoEntrega: this.calcularVentasPorTipoEntrega(pedidos),
            topClientes: this.calcularTopClientes(pedidos),
            datosCompletos: pedidos,
            tipo: tipo
        };
        
        return reporte;
    },
    
    // Cálculos de resumen
    calcularResumen(pedidos) {
        const totalVentas = pedidos.reduce((sum, p) => sum + (p.total || 0), 0);
        const pedidosPagados = pedidos.filter(p => p.estado === 'pagado' || p.estado === 'entregado');
        const pedidosPendientes = pedidos.filter(p => p.estado === 'pendiente');
        const pedidosAnulados = pedidos.filter(p => p.estado === 'anulado');
        
        const ventasPorMetodo = pedidos.reduce((acc, p) => {
            const metodo = p.metodo_pago || 'desconocido';
            acc[metodo] = (acc[metodo] || 0) + (p.total || 0);
            return acc;
        }, {});
        
        return {
            totalPedidos: pedidos.length,
            totalVentas: totalVentas,
            promedioVenta: pedidos.length > 0 ? totalVentas / pedidos.length : 0,
            pedidosPagados: pedidosPagados.length,
            pedidosPendientes: pedidosPendientes.length,
            pedidosAnulados: pedidosAnulados.length,
            ventasPorMetodo: ventasPorMetodo,
            pedidosDelivery: pedidos.filter(p => p.tipo_entrega === 'delivery').length,
            pedidosRetiro: pedidos.filter(p => p.tipo_entrega === 'retiro').length
        };
    },
    
    calcularVentasPorDia(pedidos) {
        const ventasPorDia = {};
        
        pedidos.forEach(pedido => {
            const fecha = new Date(pedido.fecha || pedido.created_at);
            const dia = fecha.toISOString().split('T')[0];
            
            if (!ventasPorDia[dia]) {
                ventasPorDia[dia] = {
                    fecha: dia,
                    fechaFormateada: fecha.toLocaleDateString('es-CL'),
                    total: 0,
                    cantidadPedidos: 0,
                    productosVendidos: 0
                };
            }
            
            ventasPorDia[dia].total += pedido.total || 0;
            ventasPorDia[dia].cantidadPedidos += 1;
            ventasPorDia[dia].productosVendidos += (pedido.items || []).reduce((sum, item) => sum + (item.cantidad || 0), 0);
        });
        
        return Object.values(ventasPorDia).sort((a, b) => new Date(a.fecha) - new Date(b.fecha));
    },
    
    calcularVentasPorProducto(pedidos) {
        const productosMap = {};
        
        pedidos.forEach(pedido => {
            (pedido.items || []).forEach(item => {
                const productoId = item.producto_id || item.nombre;
                const productoNombre = item.nombre || 'Producto sin nombre';
                
                if (!productosMap[productoId]) {
                    productosMap[productoId] = {
                        id: productoId,
                        nombre: productoNombre,
                        cantidadVendida: 0,
                        totalVendido: 0,
                        pedidosConProducto: 0
                    };
                }
                
                productosMap[productoId].cantidadVendida += item.cantidad || 0;
                productosMap[productoId].totalVendido += (item.precio || 0) * (item.cantidad || 0);
                productosMap[productoId].pedidosConProducto += 1;
            });
        });
        
        return Object.values(productosMap).sort((a, b) => b.totalVendido - a.totalVendido);
    },
    
    calcularVentasPorMetodoPago(pedidos) {
        const metodosMap = {};
        
        pedidos.forEach(pedido => {
            const metodo = pedido.metodo_pago || 'desconocido';
            
            if (!metodosMap[metodo]) {
                metodosMap[metodo] = {
                    metodo: metodo,
                    totalVentas: 0,
                    cantidadPedidos: 0,
                    promedio: 0
                };
            }
            
            metodosMap[metodo].totalVentas += pedido.total || 0;
            metodosMap[metodo].cantidadPedidos += 1;
        });
        
        // Calcular promedios
        Object.values(metodosMap).forEach(metodo => {
            metodo.promedio = metodo.cantidadPedidos > 0 ? metodo.totalVentas / metodo.cantidadPedidos : 0;
        });
        
        return Object.values(metodosMap).sort((a, b) => b.totalVentas - a.totalVentas);
    },
    
    calcularVentasPorTipoEntrega(pedidos) {
        const tiposMap = {};
        
        pedidos.forEach(pedido => {
            const tipo = pedido.tipo_entrega || 'desconocido';
            
            if (!tiposMap[tipo]) {
                tiposMap[tipo] = {
                    tipo: tipo,
                    totalVentas: 0,
                    cantidadPedidos: 0,
                    promedio: 0
                };
            }
            
            tiposMap[tipo].totalVentas += pedido.total || 0;
            tiposMap[tipo].cantidadPedidos += 1;
        });
        
        // Calcular promedios
        Object.values(tiposMap).forEach(tipo => {
            tipo.promedio = tipo.cantidadPedidos > 0 ? tipo.totalVentas / tipo.cantidadPedidos : 0;
        });
        
        return Object.values(tiposMap).sort((a, b) => b.totalVentas - a.totalVentas);
    },
    
    calcularTopClientes(pedidos) {
        const clientesMap = {};
        
        pedidos.forEach(pedido => {
            const clienteId = pedido.cliente_correo;
            const clienteNombre = pedido.cliente_nombre || pedido.cliente_correo;
            
            if (!clientesMap[clienteId]) {
                clientesMap[clienteId] = {
                    clienteId: clienteId,
                    nombre: clienteNombre,
                    totalCompras: 0,
                    cantidadPedidos: 0,
                    promedioCompra: 0,
                    ultimaCompra: pedido.fecha || pedido.created_at,
                    productosComprados: new Set()
                };
            }
            
            clientesMap[clienteId].totalCompras += pedido.total || 0;
            clientesMap[clienteId].cantidadPedidos += 1;
            clientesMap[clienteId].ultimaCompra = pedido.fecha || pedido.created_at;
            
            // Agregar productos únicos
            (pedido.items || []).forEach(item => {
                clientesMap[clienteId].productosComprados.add(item.nombre || item.producto_id);
            });
        });
        
        // Calcular promedios y convertir Set a número
        const clientes = Object.values(clientesMap).map(cliente => {
            cliente.promedioCompra = cliente.cantidadPedidos > 0 ? cliente.totalCompras / cliente.cantidadPedidos : 0;
            cliente.productosUnicos = cliente.productosComprados.size;
            delete cliente.productosComprados;
            return cliente;
        });
        
        return clientes.sort((a, b) => b.totalCompras - a.totalCompras).slice(0, 10);
    },
    
    // Generar reportes
    async generarReporteDiario() {
        const hoy = new Date();
        const inicioDia = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate());
        const finDia = new Date(hoy.getFullYear(), hoy.getMonth(), hoy.getDate(), 23, 59, 59);
        
        return await this.getReportData('diario', inicioDia, finDia);
    },
    
    async generarReporteSemanal() {
        const hoy = new Date();
        const inicioSemana = new Date(hoy);
        inicioSemana.setDate(hoy.getDate() - hoy.getDay());
        inicioSemana.setHours(0, 0, 0, 0);
        
        const finSemana = new Date(hoy);
        finSemana.setDate(inicioSemana.getDate() + 6);
        finSemana.setHours(23, 59, 59, 999);
        
        return await this.getReportData('semanal', inicioSemana, finSemana);
    },
    
    async generarReporteMensual() {
        const hoy = new Date();
        const inicioMes = new Date(hoy.getFullYear(), hoy.getMonth(), 1);
        const finMes = new Date(hoy.getFullYear(), hoy.getMonth() + 1, 0, 23, 59, 59);
        
        return await this.getReportData('mensual', inicioMes, finMes);
    },
    
    async generarReportePersonalizado(fechaInicio, fechaFin) {
        return await this.getReportData('personalizado', fechaInicio, fechaFin);
    },
    
    // Renderizar reportes en HTML (SIN GRÁFICOS)
    async renderReporteDiario() {
        try {
            const reporte = await this.generarReporteDiario();
            this.renderReporte(reporte, '📅 Reporte Diario');
        } catch (error) {
            console.error('❌ [reports.js] Error generando reporte diario:', error);
            this.mostrarError('Error generando reporte diario');
        }
    },
    
    async renderReporteSemanal() {
        try {
            const reporte = await this.generarReporteSemanal();
            this.renderReporte(reporte, '📆 Reporte Semanal');
        } catch (error) {
            console.error('❌ [reports.js] Error generando reporte semanal:', error);
            this.mostrarError('Error generando reporte semanal');
        }
    },
    
    async renderReporteMensual() {
        try {
            const reporte = await this.generarReporteMensual();
            this.renderReporte(reporte, '📈 Reporte Mensual');
        } catch (error) {
            console.error('❌ [reports.js] Error generando reporte mensual:', error);
            this.mostrarError('Error generando reporte mensual');
        }
    },
    
    renderReporte(reporte, titulo) {
        const container = this.getContenedorReporte(reporte.tipo);
        if (!container) {
            console.error('❌ [reports.js] No se encontró el contenedor de reportes');
            return;
        }
        
        container.innerHTML = this.generarHTMLReporte(reporte, titulo);
    },
    
    getContenedorReporte(tipo) {
        switch(tipo) {
            case 'diario': return document.getElementById('reportesContainer');
            case 'semanal': return document.getElementById('reportesContainerSemanal');
            case 'mensual': return document.getElementById('reportesContainerMensual');
            default: return document.getElementById('reportePersonalizadoContainer');
        }
    },
    
    generarHTMLReporte(reporte, titulo) {
        const fechaHoy = new Date().toLocaleDateString('es-CL', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        return `
            <div class="reporte-container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3>${titulo}</h3>
                    <div class="text-muted">${fechaHoy}</div>
                </div>
                
                <!-- Resumen General -->
                ${this.generarResumenHTML(reporte.resumen)}
                
                <!-- Ventas por Día (Tabla en lugar de gráfico) -->
                ${this.generarTablaVentasPorDia(reporte.ventasPorDia)}
                
                <!-- Métodos de Pago y Tipo Entrega -->
                <div class="row mb-4">
                    <div class="col-lg-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6>💳 Métodos de Pago</h6>
                            </div>
                            <div class="card-body">
                                ${this.generarTablaMetodosPago(reporte.ventasPorMetodoPago)}
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        <div class="card h-100">
                            <div class="card-header">
                                <h6>🚚 Tipo de Entrega</h6>
                            </div>
                            <div class="card-body">
                                ${this.generarTablaTipoEntrega(reporte.ventasPorTipoEntrega)}
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Top Clientes -->
                ${this.generarTablaTopClientes(reporte.topClientes)}
                
                <!-- Productos Más Vendidos -->
                ${this.generarTablaProductosVendidos(reporte.ventasPorProducto)}
                
                <!-- Botones de acción -->
                <div class="mt-4 d-flex justify-content-between">
                    <button class="btn btn-outline-primary" onclick="reports.imprimirReporte()">
                        🖨️ Imprimir Reporte
                    </button>
                    <button class="btn btn-secondary" onclick="reports.actualizarReportes()">
                        🔄 Actualizar
                    </button>
                </div>
            </div>
        `;
    },
    
    generarResumenHTML(resumen) {
        return `
            <div class="card mb-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">📈 Resumen General</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3 col-6 mb-3">
                            <div class="text-center p-3 border rounded bg-light">
                                <div class="h2 text-primary mb-1">${resumen.totalPedidos}</div>
                                <div class="small">Total Pedidos</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-3">
                            <div class="text-center p-3 border rounded bg-light">
                                <div class="h2 text-success mb-1">$${resumen.totalVentas.toLocaleString()}</div>
                                <div class="small">Total Ventas</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-3">
                            <div class="text-center p-3 border rounded bg-light">
                                <div class="h2 text-info mb-1">$${resumen.promedioVenta.toFixed(0).toLocaleString()}</div>
                                <div class="small">Promedio por Pedido</div>
                            </div>
                        </div>
                        <div class="col-md-3 col-6 mb-3">
                            <div class="text-center p-3 border rounded bg-light">
                                <div class="h2 text-warning mb-1">${resumen.pedidosPagados}</div>
                                <div class="small">Pedidos Pagados</div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="row mt-2">
                        <div class="col-md-4">
                            <div class="d-flex justify-content-between border-bottom py-1">
                                <span>Pedidos Pendientes:</span>
                                <strong class="text-warning">${resumen.pedidosPendientes}</strong>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex justify-content-between border-bottom py-1">
                                <span>Pedidos Anulados:</span>
                                <strong class="text-danger">${resumen.pedidosAnulados}</strong>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="d-flex justify-content-between border-bottom py-1">
                                <span>Delivery vs Retiro:</span>
                                <strong>${resumen.pedidosDelivery}/${resumen.pedidosRetiro}</strong>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },
    
    generarTablaVentasPorDia(ventasPorDia) {
        if (ventasPorDia.length === 0) return '';
        
        return `
            <div class="card mb-4">
                <div class="card-header">
                    <h6>📅 Ventas por Día</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th class="text-end">Pedidos</th>
                                    <th class="text-end">Productos</th>
                                    <th class="text-end">Total Ventas</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${ventasPorDia.map(dia => `
                                    <tr>
                                        <td>${dia.fechaFormateada}</td>
                                        <td class="text-end">${dia.cantidadPedidos}</td>
                                        <td class="text-end">${dia.productosVendidos}</td>
                                        <td class="text-end text-success">$${dia.total.toLocaleString()}</td>
                                    </tr>
                                `).join('')}
                                <tr class="table-active">
                                    <td><strong>TOTAL</strong></td>
                                    <td class="text-end"><strong>${ventasPorDia.reduce((sum, d) => sum + d.cantidadPedidos, 0)}</strong></td>
                                    <td class="text-end"><strong>${ventasPorDia.reduce((sum, d) => sum + d.productosVendidos, 0)}</strong></td>
                                    <td class="text-end"><strong class="text-success">$${ventasPorDia.reduce((sum, d) => sum + d.total, 0).toLocaleString()}</strong></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },
    
    generarTablaMetodosPago(metodos) {
        if (metodos.length === 0) return '<p class="text-muted">No hay datos de métodos de pago</p>';
        
        return `
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Método</th>
                        <th class="text-end">Ventas</th>
                        <th class="text-end">Pedidos</th>
                        <th class="text-end">Promedio</th>
                    </tr>
                </thead>
                <tbody>
                    ${metodos.map(metodo => `
                        <tr>
                            <td>${this.getIconoMetodoPago(metodo.metodo)} ${metodo.metodo}</td>
                            <td class="text-end text-success">$${metodo.totalVentas.toLocaleString()}</td>
                            <td class="text-end">${metodo.cantidadPedidos}</td>
                            <td class="text-end">$${metodo.promedio.toFixed(0).toLocaleString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    },
    
    generarTablaTipoEntrega(tipos) {
        if (tipos.length === 0) return '<p class="text-muted">No hay datos de tipo de entrega</p>';
        
        return `
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Tipo</th>
                        <th class="text-end">Ventas</th>
                        <th class="text-end">Pedidos</th>
                        <th class="text-end">Promedio</th>
                    </tr>
                </thead>
                <tbody>
                    ${tipos.map(tipo => `
                        <tr>
                            <td>${this.getIconoTipoEntrega(tipo.tipo)} ${tipo.tipo}</td>
                            <td class="text-end text-success">$${tipo.totalVentas.toLocaleString()}</td>
                            <td class="text-end">${tipo.cantidadPedidos}</td>
                            <td class="text-end">$${tipo.promedio.toFixed(0).toLocaleString()}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    },
    
    generarTablaTopClientes(clientes) {
        if (clientes.length === 0) return '';
        
        return `
            <div class="card mb-4">
                <div class="card-header bg-info text-white">
                    <h5 class="mb-0">👥 Top 10 Clientes</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Cliente</th>
                                    <th>Total Compras</th>
                                    <th>Pedidos</th>
                                    <th>Promedio</th>
                                    <th>Productos Únicos</th>
                                    <th>Última Compra</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${clientes.map((cliente, index) => `
                                    <tr>
                                        <td>${index + 1}</td>
                                        <td>${cliente.nombre}</td>
                                        <td class="text-success">$${cliente.totalCompras.toLocaleString()}</td>
                                        <td>${cliente.cantidadPedidos}</td>
                                        <td>$${cliente.promedioCompra.toFixed(0).toLocaleString()}</td>
                                        <td>${cliente.productosUnicos}</td>
                                        <td>${new Date(cliente.ultimaCompra).toLocaleDateString()}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },
    
    generarTablaProductosVendidos(productos) {
        const productosTop10 = productos.slice(0, 10);
        if (productosTop10.length === 0) return '';
        
        return `
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">🏆 Top 10 Productos Más Vendidos</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Producto</th>
                                    <th>Cantidad Vendida</th>
                                    <th>Total Vendido</th>
                                    <th>Pedidos</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${productosTop10.map((producto, index) => `
                                    <tr>
                                        <td>${index + 1}</td>
                                        <td>${producto.nombre}</td>
                                        <td class="text-primary">${producto.cantidadVendida} unidades</td>
                                        <td class="text-success">$${producto.totalVendido.toLocaleString()}</td>
                                        <td>${producto.pedidosConProducto}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;
    },
    
    getIconoMetodoPago(metodo) {
        const iconos = {
            'tarjeta': '💳',
            'efectivo': '💰',
            'transferencia': '🏦',
            'desconocido': '❓'
        };
        return iconos[metodo.toLowerCase()] || '📄';
    },
    
    getIconoTipoEntrega(tipo) {
        const iconos = {
            'delivery': '🚚',
            'retiro': '🏪',
            'desconocido': '❓'
        };
        return iconos[tipo.toLowerCase()] || '📦';
    },
    
    // Funciones de UI adicionales
    imprimirReporte() {
        window.print();
    },
    
    actualizarReportes() {
        const activeTab = document.querySelector('#reportesTabs .nav-link.active');
        if (activeTab) {
            const tabId = activeTab.getAttribute('href');
            if (tabId === '#diario') {
                this.renderReporteDiario();
            } else if (tabId === '#semanal') {
                this.renderReporteSemanal();
            } else if (tabId === '#mensual') {
                this.renderReporteMensual();
            }
        }
    },
    
    mostrarError(mensaje) {
        const container = document.getElementById('reportesContainer');
        if (container) {
            container.innerHTML = `
                <div class="alert alert-danger">
                    <h5>❌ Error</h5>
                    <p>${mensaje}</p>
                    <button class="btn btn-sm btn-outline-danger" onclick="reports.actualizarReportes()">
                        Reintentar
                    </button>
                </div>
            `;
        }
    },
    
    // Funciones para reporte personalizado
    generarReportePersonalizadoUI: async function() {
        const fechaInicio = document.getElementById('fechaInicio').value;
        const fechaFin = document.getElementById('fechaFin').value;
        
        if (!fechaInicio || !fechaFin) {
            alert('Por favor selecciona ambas fechas');
            return;
        }
        
        if (new Date(fechaInicio) > new Date(fechaFin)) {
            alert('La fecha de inicio no puede ser mayor a la fecha final');
            return;
        }
        
        const container = document.getElementById('reportePersonalizadoContainer');
        if (!container) {
            console.error('❌ [reports.js] No se encontró #reportePersonalizadoContainer');
            return;
        }
        
        // Mostrar carga
        container.innerHTML = `
            <div class="alert alert-info">
                <p>📊 Generando reporte personalizado...</p>
                <div class="spinner-border spinner-border-sm" role="status"></div>
            </div>
        `;
        
        try {
            // Ajustar fechas para incluir todo el día
            const inicio = new Date(fechaInicio);
            inicio.setHours(0, 0, 0, 0);
            
            const fin = new Date(fechaFin);
            fin.setHours(23, 59, 59, 999);
            
            const reporte = await this.generarReportePersonalizado(inicio, fin);
            
            // Renderizar el reporte
            container.innerHTML = this.generarHTMLReporte(reporte, 
                `📊 Reporte Personalizado (${inicio.toLocaleDateString()} - ${fin.toLocaleDateString()})`);
            
        } catch (error) {
            console.error('❌ [reports.js] Error generando reporte personalizado:', error);
            container.innerHTML = `
                <div class="alert alert-danger">
                    <h5>❌ Error</h5>
                    <p>No se pudo generar el reporte: ${error.message}</p>
                    <button class="btn btn-sm btn-outline-danger" onclick="reports.generarReportePersonalizadoUI()">
                        Reintentar
                    </button>
                </div>
            `;
        }
    },
    
    limpiarFechas: function() {
        const hoy = new Date();
        const hace7Dias = new Date();
        hace7Dias.setDate(hoy.getDate() - 7);
        
        const fechaInicioInput = document.getElementById('fechaInicio');
        const fechaFinInput = document.getElementById('fechaFin');
        
        if (fechaInicioInput) {
            fechaInicioInput.value = hace7Dias.toISOString().split('T')[0];
        }
        
        if (fechaFinInput) {
            fechaFinInput.value = hoy.toISOString().split('T')[0];
        }
        
        const container = document.getElementById('reportePersonalizadoContainer');
        if (container) {
            container.innerHTML = '';
        }
    },
    
    inicializarFechas: function() {
        const fechaInicioInput = document.getElementById('fechaInicio');
        const fechaFinInput = document.getElementById('fechaFin');
        
        if (fechaInicioInput && !fechaInicioInput.value) {
            const hoy = new Date();
            const hace7Dias = new Date();
            hace7Dias.setDate(hoy.getDate() - 7);
            
            fechaInicioInput.value = hace7Dias.toISOString().split('T')[0];
            fechaFinInput.value = hoy.toISOString().split('T')[0];
        }
    },
    
    // Funciones de navegación
    cargarReporteDiario: function() {
        showSection('reportes');
        setTimeout(() => {
            const tab = document.querySelector('#reportesTabs button[data-bs-target="#diario"]');
            if (tab) {
                new bootstrap.Tab(tab).show();
                setTimeout(() => this.renderReporteDiario(), 300);
            }
        }, 100);
    },
    
    cargarReporteSemanal: function() {
        showSection('reportes');
        setTimeout(() => {
            const tab = document.querySelector('#reportesTabs button[data-bs-target="#semanal"]');
            if (tab) {
                new bootstrap.Tab(tab).show();
                setTimeout(() => this.renderReporteSemanal(), 300);
            }
        }, 100);
    },
    
    cargarReporteMensual: function() {
        showSection('reportes');
        setTimeout(() => {
            const tab = document.querySelector('#reportesTabs button[data-bs-target="#mensual"]');
            if (tab) {
                new bootstrap.Tab(tab).show();
                setTimeout(() => this.renderReporteMensual(), 300);
            }
        }, 100);
    }
};

// Auto-inicialización
document.addEventListener('DOMContentLoaded', function() {
    console.log('📊 [reports.js] Script cargado');
    
    setTimeout(() => {
        if (window.reports && window.reports.initialize) {
            window.reports.initialize();
            
            // Configurar eventos para las pestañas
            const reportesTabs = document.getElementById('reportesTabs');
            if (reportesTabs) {
                reportesTabs.addEventListener('shown.bs.tab', function(event) {
                    const target = event.target.getAttribute('data-bs-target');
                    
                    // Inicializar fechas cuando se muestra la pestaña personalizado
                    if (target === '#personalizado') {
                        setTimeout(() => {
                            reports.inicializarFechas();
                        }, 100);
                    }
                    
                    // Cargar el reporte correspondiente
                    setTimeout(() => {
                        switch(target) {
                            case '#diario':
                                reports.renderReporteDiario();
                                break;
                            case '#semanal':
                                reports.renderReporteSemanal();
                                break;
                            case '#mensual':
                                reports.renderReporteMensual();
                                break;
                        }
                    }, 300);
                });
            }
        }
    }, 1000);
});

// Hacer disponible globalmente
window.reports = reports;