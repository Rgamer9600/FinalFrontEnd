// ui.js - Gestión de la interfaz de usuario - VERSIÓN CORREGIDA SIN ERRORES
const sections = [
    'home', 'catalogo', 'misPedidos', 'anulacion', 
    'listaPedidos', 'cajaVirtual', 'asignaciones', 
    'reportes', 'gestionProductos', 'gestionUsuarios'  // <-- AÑADIR ESTA
];

function showNotification(message, type = 'info') {
  console.log(`💬 [ui.js] ${type}: ${message}`);
  
  // Puedes implementar notificaciones visuales aquí
  const notification = document.createElement('div');
  notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
  notification.style.cssText = `
    top: 20px;
    right: 20px;
    z-index: 9999;
    min-width: 300px;
  `;
  notification.innerHTML = `
    ${message}
    <button type="button" class="btn-close" onclick="this.parentElement.remove()"></button>
  `;
  
  document.body.appendChild(notification);
  
  // Auto-remover después de 5 segundos
  setTimeout(() => {
    if (notification.parentNode) {
      notification.remove();
    }
  }, 5000);
}

// Exportar para uso global
window.showNotification = showNotification;

// En ui.js, en la función showSection o createShowSection
function showSection(id) {
    console.log(`🔄 Mostrando sección: ${id}`);
    
    // Ocultar todas las secciones
    sections.forEach(s => {
        const element = document.getElementById(s);
        if (element) {
            element.classList.add('hidden');
        }
    });
    
    // Mostrar la sección solicitada
    if (id) {
        const targetElement = document.getElementById(id);
        if (targetElement) {
            targetElement.classList.remove('hidden');
            
            // Inicializar módulos específicos según la sección
            if (id === 'gestionUsuarios' && window.usuariosAdmin) {
                console.log('👥 Inicializando gestión de usuarios...');
                setTimeout(() => {
                    window.usuariosAdmin.onSectionShow();
                }, 100);
            }
            
            // Inicializar otros módulos según necesidad
            if (id === 'gestionProductos' && window.productosAdmin) {
                setTimeout(() => {
                    if (window.productosAdmin.init) window.productosAdmin.init();
                }, 100);
            }
            
            console.log(`✅ Sección ${id} mostrada`);
        }
    }
    
    // Scroll al inicio
    window.scrollTo({top: 0, behavior: 'smooth'});
}

function buildMenuForRole(role) {
  console.log(`👷 Construyendo menú para rol: ${role}`);
  
  const menu = document.getElementById('menu-links');
  if (!menu) {
    console.error('❌ No se encontró el elemento menu-links');
    return;
  }
  
  menu.innerHTML = '';
  
  const addLink = (label, target, icon = '') => {
    const a = document.createElement('a');
    a.className = 'nav-link';
    a.innerHTML = `${icon} ${label}`;
    a.onclick = () => { 
      console.log(`📌 Navegando a: ${target}`);
      showSection(target); 
      
      // Acciones especiales al cambiar de sección
      if (target === 'asignaciones' && role !== 'Cliente') {
        setTimeout(() => {
          if (typeof asignaciones !== 'undefined' && asignaciones.renderizarPanelAsignaciones) {
            console.log('🚚 Inicializando panel de asignaciones...');
            asignaciones.renderizarPanelAsignaciones();
          }
        }, 100);
      }
    };
    menu.appendChild(a);
  };

  // Menú base para todos
  addLink('Inicio', 'home', '🏠');

  if (role === 'Cliente') {
    addLink('Catálogo', 'catalogo', '🛍️');
    addLink('Mis pedidos', 'misPedidos', '📦');
    addLink('Anular pedido', 'anulacion', '❌');
  } 
  else if (role === 'Administrador' || role === 'Admin' || role === 'Dueño') {
    addLink('👥 Gestión de Usuarios', 'gestionUsuarios', '👥');
    addLink('Todos los Pedidos', 'listaPedidos', '📋');
    addLink('📋 Órdenes de Despacho', 'asignaciones', '📋');
    addLink('Caja Virtual', 'cajaVirtual', '💰');
    addLink('📊 Reportes', 'reportes', '📊');
    addLink('🛍️ Gestión Productos', 'gestionProductos', '🛍️');
    addLink('Catálogo', 'catalogo', '🛍️');
  }
  
  const menuElement = document.getElementById('menu');
  if (menuElement) {
    menuElement.classList.remove('hidden');
    console.log('✅ Menú mostrado');
  }
}

function initializeEventListeners() {
  console.log('🔄 Inicializando event listeners...');
  
  // 1. Configurar listeners de autenticación
  setTimeout(() => {
    console.log('🔧 Configurando listeners de autenticación...');
    
    // LOGIN
    const btnLogin = document.getElementById('btnLogin');
    if (btnLogin) {
      console.log('✅ Configurando btnLogin...');
      
      // Clonar botón para eliminar listeners anteriores
      const newBtn = btnLogin.cloneNode(true);
      btnLogin.parentNode.replaceChild(newBtn, btnLogin);
      
      // Obtener referencia actualizada
      const currentBtnLogin = document.getElementById('btnLogin');
      
      currentBtnLogin.addEventListener('click', function(e) {
        console.log('🎯 Botón login clickeado!');
        e.preventDefault();
        e.stopPropagation();
        
        const email = document.getElementById('email_login')?.value.trim();
        const password = document.getElementById('pass_login')?.value;
        
        console.log('📧 Credenciales ingresadas:', { email, password: '***' });
        
        if (!email || !password) {
          alert('Por favor completa email y contraseña');
          return;
        }
        
        // Usar auth.login si está disponible
        if (typeof auth !== 'undefined' && typeof auth.login === 'function') {
          console.log('🔐 Usando auth.login()...');
          auth.login(email, password);
        } else {
          console.error('❌ auth.login no disponible');
          alert('Error: Sistema de login temporalmente no disponible');
        }
      });
      
      console.log('✅ Event listener de login asignado correctamente');
    } else {
      console.error('❌ ERROR: btnLogin no encontrado!');
    }
    
    // REGISTRO
    const btnRegister = document.getElementById('btnRegister');
    if (btnRegister) {
      btnRegister.addEventListener('click', function() {
        console.log('📝 Botón registrar clickeado');
        const email = document.getElementById('email_login')?.value.trim();
        const password = document.getElementById('pass_login')?.value;
        
        if (!email || !password) {
          alert('Completa email y contraseña para registrar');
          return;
        }
        
        if (typeof auth !== 'undefined' && typeof auth.register === 'function') {
          auth.register(email, password);
        } else {
          alert('Función de registro no disponible temporalmente');
        }
      });
    }
    
    // LOGOUT
    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
      btnLogout.addEventListener('click', function() {
        console.log('🚪 Botón logout clickeado');
        if (typeof auth !== 'undefined' && typeof auth.logout === 'function') {
          auth.logout();
        }
      });
    }
    
    console.log('✅ Listeners de autenticación configurados');
  }, 100);
  
  // 2. Inicializar el resto de event listeners
  inicializarRestoEventListeners();
  
  console.log('✅ Todos los event listeners inicializados');
}

// Función de fallback para login manual
async function loginManual(email, password) {
  console.log('🛠️ Usando login manual de emergencia...');
  
  try {
    const response = await fetch('http://localhost:8000/usuarios/');
    const users = await response.json();
    
    const user = users.find(u => u.correo === email && u.contraseña === password);
    
    if (user) {
      console.log('✅ Login manual exitoso:', user.correo);
      
      // Actualizar UI manualmente
      document.getElementById('panel-login').classList.add('hidden');
      document.getElementById('menu').classList.remove('hidden');
      document.getElementById('userEmail').textContent = user.correo;
      document.getElementById('userRole').textContent = user.rol;
      document.getElementById('userInfo').classList.remove('hidden');
      
      // Construir menú
      buildMenuForRole(user.rol);
      
      // Mostrar sección por defecto
      if (user.rol === 'Cliente') {
        showSection('catalogo');
      } else {
        showSection('listaPedidos');
      }
      
      // Actualizar vistas
      setTimeout(() => {
        if (typeof populateAllViews === 'function') {
          populateAllViews();
        }
      }, 500);
      
    } else {
      alert('Credenciales incorrectas');
    }
  } catch (error) {
    console.error('❌ Error en login manual:', error);
    alert('Error de conexión con el servidor');
  }
}

// Función separada para el resto de event listeners
function inicializarRestoEventListeners() {
  console.log('🔧 Inicializando resto de event listeners...');
  
  // Carrito y pedidos
  const btnCheckout = document.getElementById('btnCheckout');
  if (btnCheckout) {
    // Remover listeners anteriores
    const nuevoBtn = btnCheckout.cloneNode(true);
    btnCheckout.parentNode.replaceChild(nuevoBtn, btnCheckout);
    
    // Agregar nuevo listener
    document.getElementById('btnCheckout').addEventListener('click', async function() {
      console.log('🛒 Botón checkout clickeado (listener único)');
      if (typeof cart !== 'undefined' && typeof cart.checkout === 'function') {
        const result = await cart.checkout();
        if (result && typeof payments !== 'undefined' && typeof payments.showPaymentSection === 'function') {
          payments.showPaymentSection(result);
        }
      }
    });
  }

  // Pagos
  const btnPagar = document.getElementById('btnPagar');
  if (btnPagar) {
    btnPagar.addEventListener('click', function() {
      console.log('💳 Botón pagar clickeado');
      const metodo = document.getElementById('metodoPago')?.value;
      if (!metodo) {
        alert('Selecciona un método de pago');
        return;
      }
      if (typeof payments !== 'undefined' && typeof payments.processPayment === 'function') {
        payments.processPayment(metodo);
      }
    });
  }

  // Anulaciones
  const btnAnularPedido = document.getElementById('btnAnularPedido');
  if (btnAnularPedido) {
    btnAnularPedido.addEventListener('click', async function() {
      console.log('❌ Botón anular pedido clickeado');
      const orderId = document.getElementById('anulaPedidoSel')?.value;
      const motivo = document.getElementById('anulaMotivoSel')?.value;

      if (!orderId) {
        const msgDiv = document.getElementById('msgAnulacion');
        if (msgDiv) msgDiv.innerHTML = '<div class="alert alert-warning">Selecciona un pedido</div>';
        return;
      }

      if (!motivo) {
        const msgDiv = document.getElementById('msgAnulacion');
        if (msgDiv) msgDiv.innerHTML = '<div class="alert alert-danger">Debe ingresar un motivo para anular</div>';
        return;
      }

      try {
        if (typeof orders !== 'undefined' && typeof orders.cancelOrder === 'function') {
          const result = await orders.cancelOrder(orderId, motivo);
          const msgDiv = document.getElementById('msgAnulacion');
          if (msgDiv) msgDiv.innerHTML = `<div class="alert alert-success">${result.mensaje}</div>`;
          if (typeof populateAllViews === 'function') {
            populateAllViews();
          }
        }
      } catch (error) {
        const msgDiv = document.getElementById('msgAnulacion');
        if (msgDiv) msgDiv.innerHTML = `<div class="alert alert-danger">Error: ${error.message}</div>`;
      }
    });
  }

  // Caja
  const btnRegistrarCaja = document.getElementById('btnRegistrarCaja');
  const btnRevisarCaja = document.getElementById('btnRevisarCaja');
  
  if (btnRegistrarCaja) {
    btnRegistrarCaja.addEventListener('click', function() {
      console.log('💰 Botón registrar caja clickeado');
      const orderId = document.getElementById('cajaPedidoId')?.value;
      if (typeof cash !== 'undefined' && typeof cash.registerSale === 'function') {
        cash.registerSale(orderId);
      }
    });
  }
  
  if (btnRevisarCaja) {
    btnRevisarCaja.addEventListener('click', function() {
      console.log('📊 Botón revisar caja clickeado');
      if (typeof cash !== 'undefined' && typeof cash.checkBalance === 'function') {
        cash.checkBalance();
      }
    });
  }
  
  console.log('✅ Resto de event listeners inicializados');
}

// Función global para poblar todas las vistas
async function populateAllViews() {
    try {
        console.log('🔄 [ui.js] populateAllViews() llamado');
        
        // Obtener usuario actual de forma segura
        let currentUser = null;
        
        // Intentar obtener de auth si está disponible
        if (typeof window.auth !== 'undefined' && window.auth.getCurrentUser) {
            currentUser = window.auth.getCurrentUser();
        } 
        // Si no, intentar obtener de la variable global
        else if (typeof window.currentUser !== 'undefined') {
            currentUser = window.currentUser;
        }
        
        console.log('👤 Usuario en populateAllViews:', currentUser);
        
        if (!currentUser) {
            console.warn('⚠️ No hay usuario logueado, omitiendo populateAllViews');
            return;
        }
        
        console.log('📋 Rol del usuario:', currentUser.rol);
        
        // Actualizar catálogo (SIEMPRE con try-catch)
        if (window.catalog && typeof catalog.populateCatalog === 'function') {
            try {
                console.log('🛍️ Actualizando catálogo...');
                await catalog.populateCatalog();
                console.log('✅ Catálogo actualizado');
            } catch (catalogError) {
                console.error('❌ Error actualizando catálogo:', catalogError);
            }
        } else {
            console.warn('⚠️ catalog.populateCatalog no disponible');
        }
        
        // Actualizar carrito (con try-catch)
        if (window.cart && typeof cart.render === 'function') {
            try {
                console.log('🛒 Actualizando carrito...');
                await cart.render();
            } catch (cartError) {
                console.error('❌ Error actualizando carrito:', cartError);
            }
        }
        
        // Actualizar pedidos según rol (con try-catch)
        if (window.orders) {
            try {
                if (currentUser.rol === 'Cliente') {
                    console.log('📦 Actualizando pedidos del cliente...');
                    if (typeof orders.renderUserOrders === 'function') {
                        await orders.renderUserOrders();
                    }
                    
                    // Actualizar selector de anulación
                    if (typeof orders.populateAnulacionSelect === 'function') {
                        await orders.populateAnulacionSelect();
                    }
                } else {
                    // Es admin/dueño
                    console.log('📋 Actualizando todos los pedidos (admin)...');
                    if (typeof orders.renderAllOrders === 'function') {
                        await orders.renderAllOrders();
                    }
                }
            } catch (ordersError) {
                console.error('❌ Error actualizando pedidos:', ordersError);
            }
        } else {
            console.warn('⚠️ Módulo orders no disponible');
        }
        
        console.log('✅ populateAllViews completado');
        
    } catch (error) {
        console.error('❌ [ui.js] Error crítico en populateAllViews:', error);
    }
}

// Función segura para obtener usuario
function getCurrentUserSafe() {
    try {
        if (typeof window.auth !== 'undefined' && window.auth.getCurrentUser) {
            return window.auth.getCurrentUser();
        }
        if (typeof window.currentUser !== 'undefined') {
            return window.currentUser;
        }
        return null;
    } catch (error) {
        console.error('❌ Error obteniendo usuario:', error);
        return null;
    }
}

// Inicialización principal
function initializeApp() {
  console.log('🚀 Inicializando aplicación...');
  
  // Asignar buildMenuForRole a auth si existe
  if (typeof window.auth !== 'undefined') {
    window.auth.buildMenuForRole = buildMenuForRole;
  }
  
  // Inicializar event listeners
  initializeEventListeners();
  
  // Mostrar sección inicial
  showSection('home');
  
  // Poblar vistas solo si hay usuario
  const user = getCurrentUserSafe();
  if (user) {
    populateAllViews();
  }
  
  console.log('✅ Aplicación inicializada correctamente');
}

// Función para actualizar solo la sección de asignaciones
async function actualizarAsignaciones() {
  if (typeof asignaciones !== 'undefined' && typeof asignaciones.actualizarPanel === 'function') {
    try {
      console.log('🔄 Actualizando panel de asignaciones...');
      await asignaciones.actualizarPanel();
    } catch (error) {
      console.error('❌ Error actualizando asignaciones:', error);
    }
  }
}

function initPasswordRecovery() {
  console.log('🔐 Inicializando sistema de recuperación de contraseña (demo)');
  
  if (window.auth && window.auth.initPasswordRecoveryListeners) {
    window.auth.initPasswordRecoveryListeners();
  }
}

// Inicializar cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
  setTimeout(initPasswordRecovery, 500);
});

// Función helper para debug
function debugUI() {
  console.log('🔍 DEBUG UI:');
  console.log('- sections:', sections);
  console.log('- showSection:', typeof showSection);
  console.log('- buildMenuForRole:', typeof buildMenuForRole);
  console.log('- initializeEventListeners:', typeof initializeEventListeners);
  console.log('- populateAllViews:', typeof populateAllViews);
  console.log('- initializeApp:', typeof initializeApp);
  
  // Verificar elementos clave
  console.log('📋 Elementos clave:');
  console.log('  - btnLogin:', document.getElementById('btnLogin'));
  console.log('  - panel-login:', document.getElementById('panel-login'));
  console.log('  - menu:', document.getElementById('menu'));
  console.log('  - userInfo:', document.getElementById('userInfo'));
}

// Función de reparación de emergencia
window.repararUI = function() {
  console.log('🔧 Reparando UI de emergencia...');
  
  // Re-asignar event listeners
  initializeEventListeners();
  
  // Verificar y re-asignar login si es necesario
  const btnLogin = document.getElementById('btnLogin');
  if (btnLogin && !btnLogin.onclick) {
    console.log('🔄 Re-asignando listener a btnLogin...');
    btnLogin.onclick = function() {
      const email = document.getElementById('email_login')?.value;
      const password = document.getElementById('pass_login')?.value;
      if (email && password) {
        loginManual(email, password);
      }
    };
  }
  
  console.log('✅ UI reparada');
  return true;
};

// ========== EXPORTAR FUNCIONES ==========
window.showSection = showSection;
window.populateAllViews = populateAllViews;
window.initializeApp = initializeApp;
window.buildMenuForRole = buildMenuForRole;
window.actualizarAsignaciones = actualizarAsignaciones;
window.debugUI = debugUI;
window.loginManual = loginManual;
window.getCurrentUserSafe = getCurrentUserSafe;
window.auth = window.auth || {};
window.initPasswordRecovery = initPasswordRecovery;

// Auto-inicialización cuando se carga el script
console.log('📜 ui.js cargado correctamente');
console.log('💡 Usa repararUI() si los botones no funcionan');
console.log('💡 Usa debugUI() para diagnóstico');