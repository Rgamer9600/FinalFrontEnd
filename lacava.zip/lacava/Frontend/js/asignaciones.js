// asignaciones.js - Sistema de Órdenes de Despacho - VERSIÓN COMPLETA CORREGIDA
const asignaciones = {
    // Estado
    repartidores: [],
    ordenesFiltradas: [],
    filtroRepartidor: 'todos',
    
limpiarEstadoInicial() {
    const container = document.getElementById('asignacionesContainer');
    if (container) {
        // Limpiar completamente el contenedor
        container.innerHTML = `
            <div class="text-center py-5" id="loadingState">
                <div class="spinner-border text-primary mb-3" role="status">
                    <span class="visually-hidden">Cargando...</span>
                </div>
                <p>Cargando órdenes de despacho...</p>
            </div>
        `;
    }
},

    // Inicialización
    async initialize() {
    console.log('🚚 Inicializando sistema de órdenes de despacho...');
    this.limpiarEstadoInicial();  // <-- Agregar esta línea
    await this.cargarRepartidores();
    await this.cargarOrdenesDespacho();
    this.configurarEventos();
},
    
    // Cargar repartidores para filtro
    async cargarRepartidores() {
        try {
            console.log('👥 Cargando repartidores...');
            const response = await fetch('http://localhost:8000/asignaciones/repartidores/');
            this.repartidores = await response.json();
            console.log(`✅ ${this.repartidores.length} repartidores cargados`);
            this.actualizarSelectRepartidores();
        } catch (error) {
            console.error('❌ Error cargando repartidores:', error);
        }
    },
    
    // Actualizar select de repartidores
    actualizarSelectRepartidores() {
        const select = document.getElementById('filtroRepartidorSelect');
        if (!select) {
            console.error('❌ No se encontró el elemento #filtroRepartidorSelect');
            return;
        }
        
        let html = '<option value="todos">Todos los repartidores</option>';
        
        this.repartidores.forEach(repartidor => {
            const id = repartidor._id || repartidor.id;
            const nombre = repartidor.nombre || 'Sin nombre';
            const codigo = repartidor.codigo || 'N/A';
            html += `<option value="${id}">${nombre} (${codigo})</option>`;
        });
        
        select.innerHTML = html;
        
        // Event listener para filtro
        select.addEventListener('change', (e) => {
            this.filtroRepartidor = e.target.value;
            console.log(`🎯 Repartidor seleccionado: ${this.filtroRepartidor}`);
            this.filtrarOrdenes();
        });
        
        console.log('✅ Select de repartidores actualizado');
    },
    
    // Cargar órdenes de despacho
    async cargarOrdenesDespacho() {
    try {
        console.log('📦 Cargando órdenes de despacho...');
        const response = await fetch('http://localhost:8000/asignaciones/ordenes-despacho/');
        const data = await response.json();
        this.todasOrdenes = data.ordenes || [];
        
        // Debug: mostrar estructura de las órdenes
        if (this.todasOrdenes.length > 0) {
            console.log('📋 Estructura de la primera orden:');
            const primera = this.todasOrdenes[0];
            console.log('- repartidor_id:', primera.repartidor_id);
            console.log('- repartidor_nombre:', primera.repartidor_nombre);
            console.log('- repartidor (array):', primera.repartidor);
            console.log('- estado:', primera.estado);
        }
        
        // Asegurar que tenemos datos antes de mostrar estadísticas
        if (this.todasOrdenes && this.todasOrdenes.length > 0) {
            // 1. Mostrar estadísticas primero
            this.mostrarEstadisticas();
            
            // 2. Filtrar órdenes después
            this.filtrarOrdenes();
        } else {
            // Si no hay datos, mostrar estadísticas en 0
            this.mostrarEstadisticas();
            this.filtrarOrdenes();
        }
        
        console.log(`✅ ${this.todasOrdenes.length} órdenes cargadas`);
    } catch (error) {
        console.error('❌ Error cargando órdenes:', error);
        this.mostrarError('Error al cargar órdenes de despacho');
        
        // Mostrar estadísticas en 0 en caso de error
        this.mostrarEstadisticas();
    }
},
    
    mostrarEstadisticas() {
    console.log('📊 Mostrando estadísticas...');
    
    // Calcular estadísticas (manejar caso de datos no disponibles)
    const total = this.todasOrdenes ? this.todasOrdenes.length : 0;
    const asignadas = this.todasOrdenes ? 
        this.todasOrdenes.filter(o => o.estado === 'asignado').length : 0;
    const enCamino = this.todasOrdenes ? 
        this.todasOrdenes.filter(o => o.estado === 'en_camino').length : 0;
    const entregadas = this.todasOrdenes ? 
        this.todasOrdenes.filter(o => o.estado === 'entregado').length : 0;
    
    console.log(`📈 Estadísticas: Total=${total}, Asignadas=${asignadas}, EnCamino=${enCamino}, Entregadas=${entregadas}`);
    
    // Buscar o crear el contenedor de estadísticas
    let statsContainer = document.getElementById('estadisticasOrdenes');
    
    if (!statsContainer) {
        // Crear contenedor si no existe
        const asignacionesContainer = document.getElementById('asignacionesContainer');
        if (!asignacionesContainer) {
            console.error('❌ No se encontró #asignacionesContainer');
            return;
        }
        
        console.log('🆕 Creando contenedor de estadísticas...');
        
        // Crear HTML de estadísticas
        const statsHTML = `
            <div class="row mb-4" id="estadisticasOrdenes">
                <div class="col-md-3">
                    <div class="card text-white bg-primary">
                        <div class="card-body text-center">
                            <h3 class="card-title" id="totalOrdenes">${total}</h3>
                            <p class="card-text">Total Órdenes</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-info">
                        <div class="card-body text-center">
                            <h3 class="card-title" id="asignadasCount">${asignadas}</h3>
                            <p class="card-text">Asignadas</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body text-center">
                            <h3 class="card-title" id="enCaminoCount">${enCamino}</h3>
                            <p class="card-text">En Camino</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-success">
                        <div class="card-body text-center">
                            <h3 class="card-title" id="entregadasCount">${entregadas}</h3>
                            <p class="card-text">Entregadas</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Insertar al inicio del contenedor
        asignacionesContainer.insertAdjacentHTML('afterbegin', statsHTML);
        console.log('✅ Contenedor de estadísticas creado');
    } else {
        // Actualizar valores si el contenedor ya existe
        console.log('🔄 Actualizando estadísticas existentes...');
        document.getElementById('totalOrdenes').textContent = total;
        document.getElementById('asignadasCount').textContent = asignadas;
        document.getElementById('enCaminoCount').textContent = enCamino;
        document.getElementById('entregadasCount').textContent = entregadas;
    }
},
    
    // Filtrar órdenes por repartidor
    filtrarOrdenes() {
        if (!this.todasOrdenes) return;
        
        console.log(`🔍 Filtrando órdenes. Repartidor seleccionado: ${this.filtroRepartidor}`);
        console.log(`📊 Total órdenes disponibles: ${this.todasOrdenes.length}`);
        
        if (this.filtroRepartidor === 'todos') {
            this.ordenesFiltradas = [...this.todasOrdenes];
            console.log(`✅ Mostrando TODAS las órdenes: ${this.ordenesFiltradas.length}`);
        } else {
            // Buscar por repartidor_id directamente o en repartidor[0]
            this.ordenesFiltradas = this.todasOrdenes.filter(orden => {
                // Opción 1: Si tiene repartidor_id directamente (string)
                if (orden.repartidor_id === this.filtroRepartidor) {
                    console.log(`✅ Orden ${orden._id} - Coincide por repartidor_id: ${orden.repartidor_id}`);
                    return true;
                }
                
                // Opción 2: Si tiene repartidor como array
                if (orden.repartidor && orden.repartidor[0]) {
                    const repartidorObj = orden.repartidor[0];
                    if (repartidorObj._id === this.filtroRepartidor) {
                        console.log(`✅ Orden ${orden._id} - Coincide por repartidor[0]._id: ${repartidorObj._id}`);
                        return true;
                    }
                }
                
                // Opción 3: Comparar string vs ObjectId
                if (orden.repartidor_id) {
                    // Normalizar IDs para comparación
                    const idOrden = String(orden.repartidor_id).toLowerCase();
                    const idFiltro = String(this.filtroRepartidor).toLowerCase();
                    
                    // Si son iguales después de normalizar
                    if (idOrden === idFiltro) {
                        console.log(`✅ Orden ${orden._id} - Coincide después de normalizar: ${idOrden} === ${idFiltro}`);
                        return true;
                    }
                    
                    // Si el filtro es un ObjectId válido y coincide
                    if (/^[0-9a-f]{24}$/.test(this.filtroRepartidor) && 
                        orden.repartidor_id.toString() === this.filtroRepartidor) {
                        console.log(`✅ Orden ${orden._id} - Coincide como ObjectId: ${orden.repartidor_id}`);
                        return true;
                    }
                }
                
                return false;
            });
            
            console.log(`✅ Órdenes filtradas para este repartidor: ${this.ordenesFiltradas.length}`);
        }
        
        // Ordenar por fecha de salida
        this.ordenesFiltradas.sort((a, b) => {
            return new Date(a.fecha_salida) - new Date(b.fecha_salida);
        });
        
        this.renderizarOrdenes();
    },
    
    // Renderizar tabla de órdenes
    renderizarOrdenes() {
        const container = document.getElementById('asignacionesContainer');
        if (!container) {
            console.error('❌ No se encontró #asignacionesContainer');
            return;
        }
        
        // Si ya hay estadísticas, remover la tabla anterior pero mantener estadísticas
        const estadisticas = document.getElementById('estadisticasOrdenes');
        const contenidoAnterior = container.innerHTML;
        
        if (estadisticas) {
            // Mantener solo las estadísticas
            container.innerHTML = '';
            container.appendChild(estadisticas);
        }
        
        if (this.ordenesFiltradas.length === 0) {
            container.innerHTML += `
                <div class="alert alert-info">
                    <h5>📭 No hay órdenes de despacho pendientes</h5>
                    <p class="mb-0">No se encontraron órdenes asignadas para despacho.</p>
                    <p><small>Filtro activo: ${this.filtroRepartidor === 'todos' ? 'Todos' : 'Repartidor específico'}</small></p>
                    <button class="btn btn-sm btn-outline-secondary mt-2" onclick="asignaciones.cargarOrdenesDespacho()">
                        🔄 Reintentar
                    </button>
                </div>
            `;
            return;
        }
        
        let html = `
            <div class="card">
                <div class="card-header bg-primary text-white d-flex justify-content-between align-items-center">
                    <div>
                        <h5 class="mb-0">📋 Órdenes de Despacho</h5>
                        <small>Total: ${this.ordenesFiltradas.length} órdenes | Filtro: ${this.filtroRepartidor === 'todos' ? 'Todos' : 'Repartidor específico'}</small>
                    </div>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-light" onclick="asignaciones.debugEstructuraOrdenes()" title="Debug">
                            🐛
                        </button>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Orden #</th>
                                    <th>Cliente</th>
                                    <th>Repartidor</th>
                                    <th>Salida</th>
                                    <th>Productos</th>
                                    <th>Total</th>
                                    <th>Estado</th>
                                    <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
        `;
        
        this.ordenesFiltradas.forEach(orden => {
            // Obtener repartidor de múltiples maneras
            let repartidorNombre = orden.repartidor_nombre;
            let repartidorCodigo = '';
            
            if (orden.repartidor && orden.repartidor[0]) {
                // Si viene como array
                const repartidorObj = orden.repartidor[0];
                if (!repartidorNombre) repartidorNombre = repartidorObj.nombre;
                repartidorCodigo = repartidorObj.codigo || '';
            }
            
            const cliente = orden.cliente && orden.cliente[0];
            const clienteNombre = cliente ? cliente.nombre : orden.cliente_nombre || 'N/A';
            const fechaSalida = orden.fecha_salida ? 
                new Date(orden.fecha_salida).toLocaleString('es-CL') : 'Por definir';
            
            html += `
                <tr data-orden-id="${orden._id}">
                    <td><strong>#${orden.numero_pedido || orden._id.substring(18, 24)}</strong></td>
                    <td>
                        <strong>${clienteNombre}</strong><br>
                        <small class="text-muted">${orden.direccion_entrega || 'Sin dirección'}</small>
                        <br><small class="text-muted">${orden.cliente_correo || ''}</small>
                    </td>
                    <td>
                        ${repartidorNombre ? `
                            <strong>${repartidorNombre}</strong><br>
                            <small class="text-muted">${repartidorCodigo || 'N/A'}</small>
                            ${orden.repartidor_id ? `<br><small class="text-muted">ID: ${orden.repartidor_id.substring(0, 8)}...</small>` : ''}
                        ` : 'Sin asignar'}
                    </td>
                    <td>${fechaSalida}</td>
                    <td>
                        <small>${orden.items ? orden.items.length : 0} productos</small>
                        ${orden.items ? `<br><small class="text-muted">${this.obtenerResumenProductos(orden.items)}</small>` : ''}
                    </td>
                    <td><strong>$${orden.total ? orden.total.toLocaleString() : '0'}</strong></td>
                    <td>
                        <span class="badge ${this.getEstadoBadgeClass(orden.estado)}">
                            ${this.getEstadoTexto(orden.estado)}
                        </span>
                    </td>
                    <td class="text-center">
                        <div class="btn-group btn-group-sm">
                            <button class="btn btn-outline-primary" onclick="asignaciones.imprimirOrden('${orden._id}')" title="Imprimir orden">
                                🖨️
                            </button>
                            <button class="btn btn-outline-info" onclick="asignaciones.verDetallesOrden('${orden._id}')" title="Ver detalles">
                                👁️
                            </button>
                            ${orden.estado === 'entregado' ? `
                            <button class="btn btn-outline-success" title="Ya entregado">
                                ✅
                            </button>
                            ` : `
                            <button class="btn btn-outline-warning" onclick="asignaciones.marcarComoEntregado('${orden._id}')" title="Marcar como entregado">
                                📦
                            </button>
                            `}
                        </div>
                    </td>
                </tr>
            `;
        });
        
        html += `
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="mt-3 d-flex justify-content-between">
                        <div>
                            <button class="btn btn-success" onclick="asignaciones.imprimirTodas()">
                                🖨️ Imprimir Todas
                            </button>
                            <button class="btn btn-outline-success ms-2" onclick="asignaciones.marcarTodasComoEntregadas()">
                                ✅ Marcar Todas Entregadas
                            </button>
                        </div>
                        <div>
                            <button class="btn btn-outline-secondary" onclick="asignaciones.actualizarPanel()">
                                🔄 Actualizar Lista
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        container.innerHTML += html;
    },
    
    // Helper: obtener resumen de productos
    obtenerResumenProductos(items) {
        if (!items || items.length === 0) return 'Sin productos';
        
        const productos = items.slice(0, 2).map(item => 
            `${item.cantidad}x ${item.nombre_producto || item.nombre || 'Producto'}`
        ).join(', ');
        
        return items.length > 2 ? `${productos}... (+${items.length - 2})` : productos;
    },
    
    // Helper: clase CSS para estado
    getEstadoBadgeClass(estado) {
        const clases = {
            'pendiente': 'bg-warning',
            'asignado': 'bg-info',
            'en_camino': 'bg-primary',
            'entregado': 'bg-success',
            'cancelado': 'bg-danger'
        };
        return clases[estado] || 'bg-secondary';
    },
    
    // Helper: texto para estado
    getEstadoTexto(estado) {
        const textos = {
            'pendiente': 'Pendiente',
            'asignado': 'Asignado',
            'en_camino': 'En Camino',
            'entregado': 'Entregado',
            'cancelado': 'Cancelado'
        };
        return textos[estado] || estado;
    },
    
    // Marcar orden como entregada
    async marcarComoEntregado(ordenId) {
        if (!confirm('¿Estás seguro de marcar esta orden como entregada?')) return;
        
        try {
            console.log(`📦 Marcando orden ${ordenId} como entregada...`);
            
            // Primero obtener la orden actual
            const orden = this.ordenesFiltradas.find(o => o._id === ordenId);
            if (!orden) {
                this.mostrarError('No se encontró la orden');
                return;
            }
            
            // Actualizar estado en backend
            const response = await fetch(`http://localhost:8000/pedidos/${ordenId}/estado/`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ estado: 'entregado' })
            });
            
            if (response.ok) {
                this.mostrarMensaje(`✅ Orden #${orden.numero_pedido || ordenId.substring(18, 24)} marcada como entregada`, 'success');
                
                // Actualizar localmente
                orden.estado = 'entregado';
                orden.entregado = true;
                
                // Re-renderizar
                this.renderizarOrdenes();
                
                // Actualizar estadísticas
                this.mostrarEstadisticas();
                
                // Actualizar desde backend después de un momento
                setTimeout(() => this.cargarOrdenesDespacho(), 1000);
            } else {
                throw new Error('Error en el servidor');
            }
            
        } catch (error) {
            console.error('❌ Error marcando como entregado:', error);
            this.mostrarError('Error al marcar como entregado');
        }
    },
    
    // Marcar todas como entregadas
    async marcarTodasComoEntregadas() {
        if (this.ordenesFiltradas.length === 0) {
            this.mostrarError('No hay órdenes para marcar como entregadas');
            return;
        }
        
        if (!confirm(`¿Estás seguro de marcar TODAS las ${this.ordenesFiltradas.length} órdenes como entregadas?`)) {
            return;
        }
        
        try {
            console.log(`📦 Marcando ${this.ordenesFiltradas.length} órdenes como entregadas...`);
            
            const promises = this.ordenesFiltradas.map(orden => 
                fetch(`http://localhost:8000/pedidos/${orden._id}/estado/`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ estado: 'entregado' })
                })
            );
            
            await Promise.all(promises);
            this.mostrarMensaje(`✅ ${this.ordenesFiltradas.length} órdenes marcadas como entregadas`, 'success');
            
            // Actualizar desde backend
            setTimeout(() => {
                this.cargarOrdenesDespacho();
                this.mostrarEstadisticas();
            }, 1000);
            
        } catch (error) {
            console.error('❌ Error marcando todas como entregadas:', error);
            this.mostrarError('Error al marcar órdenes como entregadas');
        }
    },
    
    // Imprimir orden individual
    imprimirOrden(ordenId) {
        const orden = this.ordenesFiltradas.find(o => o._id === ordenId);
        if (!orden) {
            this.mostrarError('Orden no encontrada');
            return;
        }
        
        const ventanaImpresion = window.open('', '_blank');
        ventanaImpresion.document.write(this.generarHTMLImpresion([orden]));
        ventanaImpresion.document.close();
        ventanaImpresion.focus();
        setTimeout(() => ventanaImpresion.print(), 500);
    },
    
    // Imprimir todas las órdenes filtradas
    imprimirTodas() {
        if (this.ordenesFiltradas.length === 0) {
            this.mostrarError('No hay órdenes para imprimir');
            return;
        }
        
        const ventanaImpresion = window.open('', '_blank');
        ventanaImpresion.document.write(this.generarHTMLImpresion(this.ordenesFiltradas));
        ventanaImpresion.document.close();
        ventanaImpresion.focus();
        setTimeout(() => ventanaImpresion.print(), 500);
    },
    
    // Generar HTML para impresión
    generarHTMLImpresion(ordenes) {
        const fecha = new Date().toLocaleDateString('es-CL');
        const hora = new Date().toLocaleTimeString('es-CL');
        
        let html = `
<!DOCTYPE html>
<html>
<head>
    <title>Órdenes de Despacho - La Cava del Valle</title>
    <style>
        @media print {
            body { font-family: Arial, sans-serif; font-size: 12px; }
            .no-print { display: none !important; }
            .page-break { page-break-after: always; }
        }
        .orden-despacho { 
            border: 2px solid #000; 
            padding: 20px; 
            margin-bottom: 20px;
            page-break-inside: avoid;
        }
        .header { text-align: center; margin-bottom: 20px; }
        .logo { font-size: 24px; font-weight: bold; color: #8B4513; }
        .info-orden { display: flex; justify-content: space-between; margin-bottom: 15px; }
        .tabla-productos { width: 100%; border-collapse: collapse; margin: 15px 0; }
        .tabla-productos th, .tabla-productos td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        .tabla-productos th { background-color: #f2f2f2; }
        .total { text-align: right; font-size: 16px; font-weight: bold; margin-top: 15px; }
        .firma { margin-top: 50px; border-top: 1px solid #000; padding-top: 10px; }
        .estado-entregado { background-color: #d4edda; padding: 5px; border-radius: 3px; }
    </style>
</head>
<body>
    <button class="no-print" onclick="window.print()" style="position:fixed; top:10px; right:10px; padding:10px; background:#007bff; color:white; border:none; cursor:pointer;">
        🖨️ Imprimir
    </button>
        `;
        
        ordenes.forEach((orden, index) => {
            const repartidor = orden.repartidor && orden.repartidor[0];
            const repartidorNombre = repartidor ? repartidor.nombre : orden.repartidor_nombre;
            const cliente = orden.cliente && orden.cliente[0];
            const clienteNombre = cliente ? cliente.nombre : orden.cliente_nombre;
            const estadoEntregado = orden.estado === 'entregado';
            
            html += `
    <div class="orden-despacho">
        <div class="header">
            <div class="logo">🧀 La Cava del Valle</div>
            <h2>ORDEN DE DESPACHO #${orden.numero_pedido || orden._id.substring(18, 24)}</h2>
            <p>Fecha: ${fecha} | Hora: ${hora}</p>
            ${estadoEntregado ? '<div class="estado-entregado"><strong>✅ ESTADO: ENTREGADO</strong></div>' : ''}
        </div>
        
        <div class="info-orden">
            <div>
                <h4>Información del Cliente</h4>
                <p><strong>Nombre:</strong> ${clienteNombre || 'N/A'}</p>
                <p><strong>Email:</strong> ${orden.cliente_correo || 'No especificado'}</p>
                <p><strong>Teléfono:</strong> ${orden.telefono_cliente || 'No especificado'}</p>
                <p><strong>Dirección:</strong> ${orden.direccion_entrega || 'No especificada'}</p>
            </div>
            <div>
                <h4>Información de Despacho</h4>
                <p><strong>Repartidor:</strong> ${repartidorNombre || 'Por asignar'}</p>
                <p><strong>Código:</strong> ${repartidor ? repartidor.codigo : 'N/A'}</p>
                <p><strong>Estado:</strong> ${this.getEstadoTexto(orden.estado)}</p>
                <p><strong>Salida estimada:</strong> ${orden.fecha_salida ? new Date(orden.fecha_salida).toLocaleString('es-CL') : 'Por definir'}</p>
            </div>
        </div>
        
        <h4>Productos a Despachar</h4>
        <table class="tabla-productos">
            <thead>
                <tr>
                    <th>Producto</th>
                    <th>Cantidad</th>
                    <th>Precio Unitario</th>
                    <th>Subtotal</th>
                </tr>
            </thead>
            <tbody>
            `;
            
            if (orden.items && orden.items.length > 0) {
                orden.items.forEach(item => {
                    const precio = item.precio_unitario || item.precio || 0;
                    const cantidad = item.cantidad || 0;
                    html += `
                <tr>
                    <td>${item.nombre_producto || item.nombre || 'Producto'}</td>
                    <td>${cantidad}</td>
                    <td>$${precio.toLocaleString()}</td>
                    <td>$${(cantidad * precio).toLocaleString()}</td>
                </tr>`;
                });
            }
            
            html += `
            </tbody>
        </table>
        
        <div class="total">
            <h3>TOTAL: $${orden.total ? orden.total.toLocaleString() : '0'}</h3>
        </div>
        
        <div class="firma">
            <p>_________________________________________</p>
            <p>Firma del Repartidor</p>
            <p>Fecha de entrega: _________________________</p>
            <p>Hora de entrega: _________________________</p>
            <p>Observaciones: ___________________________</p>
        </div>
    </div>
    
    ${index < ordenes.length - 1 ? '<div class="page-break"></div>' : ''}
            `;
        });
        
        html += `
</body>
</html>`;
        
        return html;
    },
    
    // Ver detalles de orden
    verDetallesOrden(ordenId) {
        const orden = this.ordenesFiltradas.find(o => o._id === ordenId);
        if (!orden) {
            this.mostrarError('Orden no encontrada');
            return;
        }
        
        const repartidor = orden.repartidor && orden.repartidor[0];
        const repartidorNombre = repartidor ? repartidor.nombre : orden.repartidor_nombre;
        const cliente = orden.cliente && orden.cliente[0];
        const clienteNombre = cliente ? cliente.nombre : orden.cliente_nombre;
        
        const modalHTML = `
            <div class="modal fade" id="modalDetallesOrden" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">📋 Detalles Orden #${orden.numero_pedido || orden._id.substring(18, 24)}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <h6>👤 Cliente</h6>
                                    <p><strong>Nombre:</strong> ${clienteNombre || 'N/A'}</p>
                                    <p><strong>Email:</strong> ${orden.cliente_correo || 'N/A'}</p>
                                    <p><strong>Teléfono:</strong> ${orden.telefono_cliente || 'No especificado'}</p>
                                    <p><strong>Dirección:</strong> ${orden.direccion_entrega || 'No especificada'}</p>
                                </div>
                                <div class="col-md-6">
                                    <h6>🚚 Despacho</h6>
                                    <p><strong>Repartidor:</strong> ${repartidorNombre || 'Por asignar'}</p>
                                    <p><strong>Código:</strong> ${repartidor ? repartidor.codigo : 'N/A'}</p>
                                    <p><strong>Estado:</strong> <span class="badge ${this.getEstadoBadgeClass(orden.estado)}">${this.getEstadoTexto(orden.estado)}</span></p>
                                    <p><strong>Salida estimada:</strong> ${orden.fecha_salida ? new Date(orden.fecha_salida).toLocaleString('es-CL') : 'Por definir'}</p>
                                    <p><strong>Repartidor ID:</strong> <code>${orden.repartidor_id || 'No especificado'}</code></p>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <h6>🛒 Productos</h6>
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <thead>
                                        <tr>
                                            <th>Producto</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Subtotal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${orden.items ? orden.items.map(item => {
                                            const precio = item.precio_unitario || item.precio || 0;
                                            const cantidad = item.cantidad || 0;
                                            return `
                                            <tr>
                                                <td>${item.nombre_producto || item.nombre || 'Producto'}</td>
                                                <td>${cantidad}</td>
                                                <td>$${precio.toLocaleString()}</td>
                                                <td>$${(cantidad * precio).toLocaleString()}</td>
                                            </tr>`;
                                        }).join('') : '<tr><td colspan="4">No hay productos</td></tr>'}
                                    </tbody>
                                </table>
                            </div>
                            
                            <div class="text-end">
                                <h5>Total: $${orden.total ? orden.total.toLocaleString() : '0'}</h5>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                            ${orden.estado !== 'entregado' ? `
                            <button type="button" class="btn btn-warning" onclick="asignaciones.marcarComoEntregado('${orden._id}')">
                                ✅ Marcar como Entregado
                            </button>
                            ` : ''}
                            <button type="button" class="btn btn-primary" onclick="asignaciones.imprimirOrden('${orden._id}')">
                                🖨️ Imprimir Orden
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remover modal anterior si existe
        const modalAnterior = document.getElementById('modalDetallesOrden');
        if (modalAnterior) modalAnterior.remove();
        
        // Agregar nuevo modal
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Mostrar modal
        const modal = new bootstrap.Modal(document.getElementById('modalDetallesOrden'));
        modal.show();
    },
    
    // Configurar eventos
    configurarEventos() {
        // Botón actualizar
        const btnActualizar = document.getElementById('btnActualizarOrdenes');
        if (btnActualizar) {
            btnActualizar.addEventListener('click', () => this.actualizarPanel());
        }
        
        // Auto-actualizar cada 30 segundos
        setInterval(() => {
            if (!document.getElementById('asignaciones').classList.contains('hidden')) {
                console.log('🔄 Auto-actualizando órdenes de despacho...');
                this.cargarOrdenesDespacho();
            }
        }, 30000);
    },
    
    // Actualizar panel
    async actualizarPanel() {
        await this.cargarOrdenesDespacho();
        this.mostrarMensaje('✅ Lista de órdenes actualizada', 'success');
    },
    
    // Mostrar mensajes
    mostrarMensaje(mensaje, tipo = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${tipo} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.getElementById('asignacionesContainer');
        if (container) {
            // Insertar al inicio (después de estadísticas)
            const estadisticas = document.getElementById('estadisticasOrdenes');
            if (estadisticas) {
                container.insertBefore(alertDiv, estadisticas.nextSibling);
            } else {
                container.insertBefore(alertDiv, container.firstChild);
            }
            
            // Auto-remover después de 5 segundos
            setTimeout(() => {
                if (alertDiv.parentNode) alertDiv.remove();
            }, 5000);
        }
    },
    
    mostrarError(mensaje) {
        this.mostrarMensaje(`❌ ${mensaje}`, 'danger');
    },
    
    // Debug
    debugEstructuraOrdenes() {
        console.log('🔍 Debug: Estructura de órdenes disponibles');
        if (!this.todasOrdenes || this.todasOrdenes.length === 0) {
            console.log('❌ No hay órdenes cargadas');
            return;
        }
        
        console.log(`📊 Total órdenes: ${this.todasOrdenes.length}`);
        
        // Mostrar estructura de la primera orden
        const primeraOrden = this.todasOrdenes[0];
        console.log('📋 Estructura de la primera orden:');
        console.log('- _id:', primeraOrden._id);
        console.log('- repartidor_id:', primeraOrden.repartidor_id);
        console.log('- repartidor_nombre:', primeraOrden.repartidor_nombre);
        console.log('- estado:', primeraOrden.estado);
        
        // Calcular estadísticas
        const total = this.todasOrdenes.length;
        const asignadas = this.todasOrdenes.filter(o => o.estado === 'asignado').length;
        const enCamino = this.todasOrdenes.filter(o => o.estado === 'en_camino').length;
        const entregadas = this.todasOrdenes.filter(o => o.estado === 'entregado').length;
        
        console.log('📈 Estadísticas:');
        console.log(`- Total: ${total}`);
        console.log(`- Asignadas: ${asignadas}`);
        console.log(`- En camino: ${enCamino}`);
        console.log(`- Entregadas: ${entregadas}`);
    },
    
    // Función de test
    testAsignacion() {
        console.log('🧪 Test sistema de órdenes de despacho');
        this.debugEstructuraOrdenes();
        this.mostrarMensaje('✅ Sistema de órdenes funcionando correctamente', 'success');
    }
};

// ========== INICIALIZACIÓN ==========

// Función para inicializar asignaciones
window.inicializarAsignaciones = function() {
    console.log('🚀 Inicializando asignaciones...');
    if (typeof asignaciones !== 'undefined') {
        asignaciones.initialize();
    } else {
        console.error('❌ Objeto asignaciones no definido');
    }
};

// Auto-inicialización cuando se carga el DOM
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚚 asignaciones.js cargado correctamente');
    
    // Inicializar directamente (sin esperar)
    if (typeof asignaciones !== 'undefined') {
        console.log('🎯 Inicializando sistema de asignaciones...');
        
        // Pequeño delay para asegurar que el DOM esté listo
        setTimeout(() => {
            asignaciones.initialize();
        }, 500);
    } else {
        console.error('❌ Objeto asignaciones no definido');
    }
});



// Exportar para uso global
window.asignaciones = asignaciones;

// Debug global
console.log('✅ asignaciones.js completamente cargado');
console.log('💡 Usa asignaciones.mostrarEstadisticas() para ver estadísticas');
console.log('💡 Usa asignaciones.debugEstructuraOrdenes() para diagnóstico');