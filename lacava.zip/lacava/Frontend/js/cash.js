// Gestión de caja virtual
const cash = {
  async registerSale(orderId) {
    if (!orderId) {
      this.showMessage('Ingresa el ID del pedido', 'warning');
      return;
    }

    try {
      const result = await api.registerSale(orderId);
      this.showMessage(`
        ${result.mensaje}<br>
        Monto: $${result.monto_agregado.toLocaleString()}<br>
        Nuevo saldo: $${result.nuevo_saldo.toLocaleString()}
      `, 'success');
      
      return result;
    } catch (error) {
      this.showMessage('Error: ' + error.message, 'error');
      return null;
    }
  },

  async checkBalance() {
    try {
      const result = await api.getCashBalance();
      this.showMessage(`
        Saldo actual: $${result.saldo_actual.toLocaleString()}<br>
        Última actualización: ${new Date(result.ultima_actualizacion).toLocaleString()}
      `, 'info');
      
      return result;
    } catch (error) {
      this.showMessage('Error: ' + error.message, 'error');
      return null;
    }
  },

  showMessage(message, type = 'info') {
    const msgElement = $('msgCaja');
    if (msgElement) {
      msgElement.innerHTML = `<div class="alert-${type}">${message}</div>`;
    } else {
      alert(message.replace(/<br>/g, '\n'));
    }
  }
};

// Exportar para uso global
window.cash = cash;