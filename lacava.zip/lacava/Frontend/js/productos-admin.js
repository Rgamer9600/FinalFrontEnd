// productos-admin.js - Gestión completa de productos para administrador (CORREGIDO)
const productosAdmin = {
    // Estado
    currentProduct: null,
    modoEdicion: false,
    
    // Inicialización
    async initialize() {
        console.log('🛍️ [productos-admin.js] Inicializando gestión de productos...');
        
        // Cargar productos inicialmente
        await this.cargarProductos();
        
        // Configurar eventos
        this.configurarEventos();
        
        console.log('✅ [productos-admin.js] Módulo inicializado');
    },
    
    // Configurar eventos
    configurarEventos() {
        // Botón Agregar Producto
        const btnAgregar = document.getElementById('btnAgregarProducto');
        if (btnAgregar) {
            btnAgregar.addEventListener('click', () => this.mostrarModalProducto());
        }
        
        // Botón Guardar en modal
        const btnGuardar = document.getElementById('btnGuardarProducto');
        if (btnGuardar) {
            btnGuardar.addEventListener('click', () => this.guardarProducto());
        }
        
        // Buscador
        const buscador = document.getElementById('buscadorProductos');
        if (buscador) {
            buscador.addEventListener('input', (e) => this.buscarProductos(e.target.value));
        }
        
        // Filtro por categoría
        const filtroCategoria = document.getElementById('filtroCategoria');
        if (filtroCategoria) {
            filtroCategoria.addEventListener('change', (e) => this.filtrarPorCategoria(e.target.value));
        }
        
        console.log('✅ [productos-admin.js] Eventos configurados');
    },
    
    // Cargar productos desde API
    async cargarProductos() {
        try {
            console.log('📥 [productos-admin.js] Cargando productos...');
            
            const productos = await api.getProducts();
            console.log(`✅ [productos-admin.js] ${productos.length} productos cargados:`, productos);
            
            this.renderizarProductos(productos);
            this.actualizarContadores(productos);
            this.actualizarSelectCategorias(productos);
            
            return productos;
        } catch (error) {
            console.error('❌ [productos-admin.js] Error cargando productos:', error);
            this.mostrarError(`Error al cargar los productos: ${error.message}`);
            return [];
        }
    },
    
    // Renderizar tabla de productos
    renderizarProductos(productos) {
        const tbody = document.getElementById('tablaProductosBody');
        if (!tbody) {
            console.error('❌ [productos-admin.js] No se encontró tablaProductosBody');
            return;
        }
        
        // Ordenar por nombre
        const productosOrdenados = productos.sort((a, b) => 
            a.nombre.localeCompare(b.nombre)
        );
        
        tbody.innerHTML = '';
        
        if (productosOrdenados.length === 0) {
            tbody.innerHTML = `
                <tr>
                    <td colspan="8" class="text-center text-muted py-4">
                        <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                        No hay productos registrados<br>
                        <small class="text-danger">Base de datos vacía o error de conexión</small>
                    </td>
                </tr>
            `;
            return;
        }
        
        productosOrdenados.forEach(producto => {
            const row = this.crearFilaProducto(producto);
            tbody.appendChild(row);
        });
        
        console.log(`🎨 [productos-admin.js] ${productosOrdenados.length} productos renderizados`);
    },
    
    // Crear fila de producto para la tabla
    crearFilaProducto(producto) {
        const tr = document.createElement('tr');
        tr.id = `producto-${producto._id || producto.id}`;
        
        // Determinar estado visual
        const disponible = producto.disponible !== false && (producto.stock > 0);
        const badgeDisponible = disponible ? 
            '<span class="badge bg-success">Disponible</span>' : 
            '<span class="badge bg-danger">Agotado</span>';
        
        const badgeStock = producto.stock < 10 && producto.stock > 0 ? 
            `<span class="badge bg-warning">Bajo stock</span>` : '';
        
        tr.innerHTML = `
            <td>
                <strong>${producto.nombre}</strong><br>
                <small class="text-muted">${producto.descripcion || 'Sin descripción'}</small>
            </td>
            <td>${producto.categoria || 'Sin categoría'}</td>
            <td class="text-end">$${producto.precio?.toLocaleString() || 0}</td>
            <td class="text-center">${producto.stock || 0}</td>
            <td class="text-center">
                ${badgeDisponible}
                ${badgeStock}
            </td>
            <td>
                ${producto.created_at ? new Date(producto.created_at).toLocaleDateString() : 'N/A'}
            </td>
            <td class="text-center">
                <div class="btn-group btn-group-sm">
                    <button class="btn btn-outline-primary" 
                            onclick="productosAdmin.editarProducto('${producto._id || producto.id}')"
                            title="Editar">
                        <i class="bi bi-pencil"></i>
                    </button>
                    <button class="btn btn-outline-danger" 
                            onclick="productosAdmin.eliminarProducto('${producto._id || producto.id}', '${producto.nombre}')"
                            title="Eliminar">
                        <i class="bi bi-trash"></i>
                    </button>
                    <button class="btn btn-outline-info" 
                            onclick="productosAdmin.verDetalles('${producto._id || producto.id}')"
                            title="Ver detalles">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </td>
        `;
        
        return tr;
    },
    
    // Actualizar contadores
    actualizarContadores(productos) {
        const total = productos.length;
        const disponibles = productos.filter(p => p.disponible !== false && p.stock > 0).length;
        const agotados = productos.filter(p => p.disponible === false || p.stock <= 0).length;
        const bajoStock = productos.filter(p => p.stock < 10 && p.stock > 0).length;
        
        // Actualizar elementos si existen
        const actualizar = (id, valor) => {
            const elem = document.getElementById(id);
            if (elem) elem.textContent = valor;
        };
        
        actualizar('contadorTotal', total);
        actualizar('contadorDisponibles', disponibles);
        actualizar('contadorAgotados', agotados);
        actualizar('contadorBajoStock', bajoStock);
    },
    
    // Actualizar select de categorías
    actualizarSelectCategorias(productos) {
        const select = document.getElementById('filtroCategoria');
        const selectCategoriaModal = document.getElementById('productoCategoria');
        
        if (!select && !selectCategoriaModal) return;
        
        // Extraer categorías únicas
        const categorias = [...new Set(productos.map(p => p.categoria).filter(Boolean))];
        categorias.sort();
        
        // Opción "Todas"
        const opcionTodas = '<option value="">Todas las categorías</option>';
        
        // Opciones de categorías
        const opcionesCategorias = categorias.map(cat => 
            `<option value="${cat}">${cat}</option>`
        ).join('');
        
        // Actualizar selects
        if (select) {
            select.innerHTML = opcionTodas + opcionesCategorias;
        }
        
        if (selectCategoriaModal) {
            // Para el modal, agregar opción "Nueva categoría"
            selectCategoriaModal.innerHTML = 
                '<option value="">-- Seleccionar categoría --</option>' +
                opcionesCategorias +
                '<option value="_nueva">➕ Nueva categoría</option>';
            
            // Manejar selección de nueva categoría
            selectCategoriaModal.addEventListener('change', function() {
                const inputNuevaCategoria = document.getElementById('nuevaCategoriaContainer');
                if (inputNuevaCategoria) {
                    inputNuevaCategoria.style.display = 
                        this.value === '_nueva' ? 'block' : 'none';
                }
            });
        }
    },
    
    // Buscar productos
    buscarProductos(termino) {
        const tbody = document.getElementById('tablaProductosBody');
        if (!tbody) return;
        
        const filas = tbody.getElementsByTagName('tr');
        const terminoLower = termino.toLowerCase();
        
        Array.from(filas).forEach(fila => {
            if (fila.cells.length < 2) return; // Saltar fila vacía
            
            const nombre = fila.cells[0].textContent.toLowerCase();
            const descripcion = fila.cells[0].querySelector('small')?.textContent.toLowerCase() || '';
            const categoria = fila.cells[1].textContent.toLowerCase();
            
            const coincide = nombre.includes(terminoLower) || 
                            descripcion.includes(terminoLower) || 
                            categoria.includes(terminoLower);
            
            fila.style.display = coincide ? '' : 'none';
        });
    },
    
    // Filtrar por categoría
    filtrarPorCategoria(categoria) {
        const tbody = document.getElementById('tablaProductosBody');
        if (!tbody || !categoria) return;
        
        const filas = tbody.getElementsByTagName('tr');
        
        Array.from(filas).forEach(fila => {
            if (fila.cells.length < 2) return; // Saltar fila vacía
            
            const categoriaFila = fila.cells[1].textContent;
            const mostrar = !categoria || categoria === '' || categoriaFila === categoria;
            
            fila.style.display = mostrar ? '' : 'none';
        });
    },
    
    // Mostrar modal para agregar/editar producto
    mostrarModalProducto(producto = null) {
        this.currentProduct = producto;
        this.modoEdicion = !!producto;
        
        // Limpiar formulario
        this.limpiarFormulario();
        
        // Configurar modal según modo
        const modalTitle = document.getElementById('modalProductoLabel');
        const btnGuardar = document.getElementById('btnGuardarProducto');
        
        if (modalTitle) {
            modalTitle.textContent = this.modoEdicion ? 
                '✏️ Editar Producto' : '➕ Agregar Nuevo Producto';
        }
        
        if (btnGuardar) {
            btnGuardar.textContent = this.modoEdicion ? 'Actualizar Producto' : 'Guardar Producto';
            btnGuardar.className = this.modoEdicion ? 
                'btn btn-warning' : 'btn btn-primary';
        }
        
        // Si es edición, llenar formulario
        if (producto) {
            this.llenarFormulario(producto);
        }
        
        // Mostrar modal
        const modal = new bootstrap.Modal(document.getElementById('modalProducto'));
        modal.show();
    },
    
    // Llenar formulario con datos del producto
    llenarFormulario(producto) {
        const setValue = (id, value) => {
            const elem = document.getElementById(id);
            if (elem) elem.value = value || '';
        };
        
        setValue('productoNombre', producto.nombre);
        setValue('productoDescripcion', producto.descripcion);
        setValue('productoPrecio', producto.precio);
        setValue('productoStock', producto.stock);
        
        // Categoría
        const selectCategoria = document.getElementById('productoCategoria');
        if (selectCategoria) {
            if (producto.categoria) {
                // Verificar si la categoría existe en las opciones
                const opcionExistente = Array.from(selectCategoria.options)
                    .find(opt => opt.value === producto.categoria);
                
                if (opcionExistente) {
                    selectCategoria.value = producto.categoria;
                } else {
                    // Si no existe, mostrar campo para nueva categoría
                    selectCategoria.value = '_nueva';
                    const inputNuevaCategoria = document.getElementById('nuevaCategoriaContainer');
                    const inputNuevaCategoriaField = document.getElementById('nuevaCategoria');
                    if (inputNuevaCategoria && inputNuevaCategoriaField) {
                        inputNuevaCategoria.style.display = 'block';
                        inputNuevaCategoriaField.value = producto.categoria;
                    }
                }
            }
        }
        
        // Disponible
        const checkDisponible = document.getElementById('productoDisponible');
        if (checkDisponible) {
            checkDisponible.checked = producto.disponible !== false;
        }
    },
    
    // Limpiar formulario
    limpiarFormulario() {
        const ids = [
            'productoNombre', 'productoDescripcion', 'productoPrecio',
            'productoStock', 'productoCategoria', 'nuevaCategoria'
        ];
        
        ids.forEach(id => {
            const elem = document.getElementById(id);
            if (elem) elem.value = '';
        });
        
        const checkDisponible = document.getElementById('productoDisponible');
        if (checkDisponible) checkDisponible.checked = true;
        
        const nuevaCategoriaContainer = document.getElementById('nuevaCategoriaContainer');
        if (nuevaCategoriaContainer) nuevaCategoriaContainer.style.display = 'none';
        
        // Resetear select de categoría
        const selectCategoria = document.getElementById('productoCategoria');
        if (selectCategoria) selectCategoria.value = '';
    },
    
    // Guardar producto (crear o actualizar)
    async guardarProducto() {
        try {
            // Validar formulario
            if (!this.validarFormulario()) {
                return;
            }
            
            // Obtener datos del formulario
            const productoData = this.obtenerDatosFormulario();
            
            console.log(`💾 [productos-admin.js] ${this.modoEdicion ? 'Actualizando' : 'Creando'} producto:`, productoData);
            
            let resultado;
            if (this.modoEdicion && this.currentProduct) {
                // Actualizar producto existente
                const id = this.currentProduct._id || this.currentProduct.id;
                resultado = await this.actualizarProductoAPI(id, productoData);
            } else {
                // Crear nuevo producto
                resultado = await this.crearProductoAPI(productoData);
            }
            
            if (resultado) {
                // Cerrar modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalProducto'));
                if (modal) modal.hide();
                
                // Recargar productos
                await this.cargarProductos();
                
                // Mostrar mensaje de éxito
                this.mostrarMensaje(
                    this.modoEdicion ? '✅ Producto actualizado correctamente' : '✅ Producto creado correctamente',
                    'success'
                );
            }
            
        } catch (error) {
            console.error('❌ [productos-admin.js] Error guardando producto:', error);
            this.mostrarMensaje(`❌ Error: ${error.message}`, 'error');
        }
    },
    
    // Validar formulario
    validarFormulario() {
        const getValue = (id) => {
            const elem = document.getElementById(id);
            return elem ? elem.value.trim() : '';
        };
        
        const nombre = getValue('productoNombre');
        const precio = getValue('productoPrecio');
        const stock = getValue('productoStock');
        
        // Validaciones
        if (!nombre) {
            this.mostrarMensaje('El nombre del producto es obligatorio', 'error');
            return false;
        }
        
        if (!precio || isNaN(precio) || parseFloat(precio) <= 0) {
            this.mostrarMensaje('El precio debe ser un número mayor a 0', 'error');
            return false;
        }
        
        if (!stock || isNaN(stock) || parseInt(stock) < 0) {
            this.mostrarMensaje('El stock debe ser un número válido (0 o mayor)', 'error');
            return false;
        }
        
        return true;
    },
    
    // Obtener datos del formulario
    obtenerDatosFormulario() {
        const getValue = (id) => {
            const elem = document.getElementById(id);
            return elem ? elem.value.trim() : '';
        };
        
        const getChecked = (id) => {
            const elem = document.getElementById(id);
            return elem ? elem.checked : true;
        };
        
        // Determinar categoría
        let categoria = getValue('productoCategoria');
        if (categoria === '_nueva') {
            categoria = getValue('nuevaCategoria');
        }
        
        return {
            nombre: getValue('productoNombre'),
            descripcion: getValue('productoDescripcion'),
            precio: parseFloat(getValue('productoPrecio')),
            stock: parseInt(getValue('productoStock')),
            categoria: categoria || null,
            disponible: getChecked('productoDisponible')
        };
    },
    
    // API: Crear producto (USA api.js CORREGIDO)
    async crearProductoAPI(productoData) {
        try {
            return await api.createProduct(productoData);
        } catch (error) {
            console.error('❌ [productos-admin.js] Error en crearProductoAPI:', error);
            throw error;
        }
    },
    
    // API: Actualizar producto (USA api.js CORREGIDO)
    async actualizarProductoAPI(productoId, productoData) {
        try {
            return await api.updateProduct(productoId, productoData);
        } catch (error) {
            console.error('❌ [productos-admin.js] Error en actualizarProductoAPI:', error);
            throw error;
        }
    },
    
    // API: Eliminar producto (USA api.js CORREGIDO)
    async eliminarProductoAPI(productoId) {
        try {
            return await api.deleteProduct(productoId);
        } catch (error) {
            console.error('❌ [productos-admin.js] Error en eliminarProductoAPI:', error);
            throw error;
        }
    },
    
    // Editar producto
    async editarProducto(productoId) {
        try {
            console.log(`✏️ [productos-admin.js] Editando producto: ${productoId}`);
            
            // Buscar producto en la tabla
            const productos = await api.getProducts();
            const producto = productos.find(p => 
                (p._id === productoId) || (p.id === productoId)
            );
            
            if (producto) {
                this.mostrarModalProducto(producto);
            } else {
                throw new Error('Producto no encontrado');
            }
        } catch (error) {
            console.error('❌ [productos-admin.js] Error editando producto:', error);
            this.mostrarMensaje(`❌ Error: ${error.message}`, 'error');
        }
    },
    
    // Eliminar producto (con confirmación)
    async eliminarProducto(productoId, productoNombre) {
        if (!confirm(`¿Estás seguro de eliminar el producto "${productoNombre}"?\nEsta acción no se puede deshacer.`)) {
            return;
        }
        
        try {
            console.log(`🗑️ [productos-admin.js] Eliminando producto: ${productoId}`);
            
            const resultado = await this.eliminarProductoAPI(productoId);
            
            if (resultado) {
                // Eliminar fila de la tabla
                const fila = document.getElementById(`producto-${productoId}`);
                if (fila) fila.remove();
                
                // Recargar contadores
                await this.cargarProductos();
                
                // Mostrar mensaje
                this.mostrarMensaje('✅ Producto eliminado correctamente', 'success');
            }
        } catch (error) {
            console.error('❌ [productos-admin.js] Error eliminando producto:', error);
            this.mostrarMensaje(`❌ Error: ${error.message}`, 'error');
        }
    },
    
    // Ver detalles del producto
    verDetalles(productoId) {
        console.log(`👁️ [productos-admin.js] Viendo detalles de producto: ${productoId}`);
        this.mostrarModalDetalles(productoId);
    },
    
    // Mostrar modal de detalles
    async mostrarModalDetalles(productoId) {
        try {
            const productos = await api.getProducts();
            const producto = productos.find(p => 
                (p._id === productoId) || (p.id === productoId)
            );
            
            if (!producto) {
                throw new Error('Producto no encontrado');
            }
            
            const modalHTML = `
                <div class="modal fade" id="modalDetallesProducto" tabindex="-1">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">📋 Detalles del Producto</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                            </div>
                            <div class="modal-body">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">${producto.nombre}</h5>
                                        <h6 class="card-subtitle mb-2 text-muted">${producto.categoria || 'Sin categoría'}</h6>
                                        
                                        <p class="card-text">${producto.descripcion || 'Sin descripción'}</p>
                                        
                                        <div class="row mt-3">
                                            <div class="col-6">
                                                <strong>Precio:</strong><br>
                                                <span class="h4 text-success">$${producto.precio?.toLocaleString() || 0}</span>
                                            </div>
                                            <div class="col-6">
                                                <strong>Stock:</strong><br>
                                                <span class="h4 ${producto.stock < 10 ? 'text-warning' : 'text-primary'}">
                                                    ${producto.stock || 0} unidades
                                                </span>
                                            </div>
                                        </div>
                                        
                                        <div class="row mt-3">
                                            <div class="col-6">
                                                <strong>Estado:</strong><br>
                                                ${producto.disponible !== false ? 
                                                    '<span class="badge bg-success">Disponible</span>' : 
                                                    '<span class="badge bg-danger">Agotado</span>'}
                                            </div>
                                            <div class="col-6">
                                                <strong>Creado:</strong><br>
                                                <small>${producto.created_at ? new Date(producto.created_at).toLocaleDateString() : 'N/A'}</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                                <button type="button" class="btn btn-primary" 
                                        onclick="productosAdmin.editarProducto('${producto._id || producto.id}')">
                                    <i class="bi bi-pencil"></i> Editar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            // Remover modal anterior si existe
            const modalAnterior = document.getElementById('modalDetallesProducto');
            if (modalAnterior) modalAnterior.remove();
            
            // Agregar nuevo modal
            document.body.insertAdjacentHTML('beforeend', modalHTML);
            
            // Mostrar modal
            const modal = new bootstrap.Modal(document.getElementById('modalDetallesProducto'));
            modal.show();
            
        } catch (error) {
            console.error('❌ [productos-admin.js] Error mostrando detalles:', error);
            this.mostrarMensaje(`❌ Error: ${error.message}`, 'error');
        }
    },
    
    // Mostrar mensaje
    mostrarMensaje(mensaje, tipo = 'info') {
        // Crear elemento de notificación
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${tipo === 'error' ? 'danger' : tipo} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${mensaje}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        // Agregar al contenedor de mensajes
        const mensajesContainer = document.getElementById('mensajesProductos');
        if (mensajesContainer) {
            mensajesContainer.innerHTML = '';
            mensajesContainer.appendChild(alertDiv);
        } else {
            // Si no existe contenedor, crear uno temporal
            alertDiv.style.position = 'fixed';
            alertDiv.style.top = '20px';
            alertDiv.style.right = '20px';
            alertDiv.style.zIndex = '9999';
            document.body.appendChild(alertDiv);
            
            // Auto-remover después de 5 segundos
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }
    },
    
    // Mostrar error
    mostrarError(mensaje) {
        this.mostrarMensaje(`❌ ${mensaje}`, 'error');
    },
    
    // Refrescar productos
    async refrescar() {
        await this.cargarProductos();
        this.mostrarMensaje('🔄 Productos actualizados', 'info');
    }
};

// Auto-inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
    console.log('🛍️ [productos-admin.js] Script cargado');
    
    // Esperar a que api.js esté disponible
    const initInterval = setInterval(() => {
        if (window.api && window.api.getProducts) {
            clearInterval(initInterval);
            productosAdmin.initialize();
        }
    }, 500);
});

// Hacer disponible globalmente
window.productosAdmin = productosAdmin;