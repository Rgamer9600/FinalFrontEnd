// orders.js - Gestión completa de pedidos - VERSIÓN CORREGIDA
const orders = {
  // Bandera para controlar si ya se inicializó
  initialized: false,

  // Función de inicialización del módulo
  async initialize() {
    if (this.initialized) {
      console.log('✅ [orders.js] Módulo ya inicializado');
      return;
    }

    console.log('🚀 [orders.js] Inicializando módulo de pedidos...');
    
    try {
      // Verificar que auth esté disponible
      if (!window.auth) {
        console.warn('⚠️ auth.js no disponible, reintentando en 500ms...');
        setTimeout(() => this.initialize(), 500);
        return;
      }

      // Verificar que api esté disponible
      if (!window.api) {
        console.warn('⚠️ api.js no disponible, reintentando en 500ms...');
        setTimeout(() => this.initialize(), 500);
        return;
      }

      // Marcar como inicializado
      this.initialized = true;
      
      console.log('✅ [orders.js] Módulo inicializado correctamente');

      // Si ya hay usuario logueado, precargar pedidos
      const user = this.getCurrentUser();
      if (user && this.esAdmin()) {
        console.log('👨‍💼 [orders.js] Usuario admin detectado, precargando pedidos...');
        setTimeout(() => {
          this.renderAllOrders();
        }, 1500);
      }

    } catch (error) {
      console.error('❌ [orders.js] Error en initialize:', error);
      this.initialized = false;
    }
  },

  // Helper para obtener usuario actual
  getCurrentUser() {
    return window.auth ? window.auth.getCurrentUser() : null;
  },

  // Helper para verificar si es admin
  esAdmin() {
    const user = this.getCurrentUser();
    return user && (user.rol === 'Administrador' || user.rol === 'Admin' || user.rol === 'Dueño');
  },

  // ========== FUNCIONES PRINCIPALES ==========

  async loadUserOrders() {
    const currentUser = this.getCurrentUser();
    if (!currentUser) {
      console.log('⚠️ [orders.js] No hay usuario para cargar pedidos');
      return [];
    }

    try {
      console.log('📥 [orders.js] Cargando pedidos del usuario:', currentUser.correo);
      const allOrders = await api.getOrders();
      const userOrders = allOrders.filter(order => order.cliente_correo === currentUser.correo);
      console.log(`✅ [orders.js] ${userOrders.length} pedidos cargados para usuario`);
      return userOrders;
    } catch (error) {
      console.error('❌ [orders.js] Error loading orders:', error);
      return [];
    }
  },

  async loadAllOrders() {
    try {
      console.log('📥 [orders.js] Cargando TODOS los pedidos...');
      const orders = await api.getOrders();
      console.log(`✅ [orders.js] ${orders.length} pedidos cargados en total`);
      
      // Asegurar que todos los pedidos tengan un ID accesible
      return orders.map(order => ({
        ...order,
        id: order._id || order.id // Usar _id de MongoDB como id principal
      }));
    } catch (error) {
      console.error('❌ [orders.js] Error loading all orders:', error);
      return [];
    }
  },

  async renderUserOrders() {
    console.log('🔄 [orders.js] Renderizando pedidos del usuario...');
    
    const orders = await this.loadUserOrders();
    console.log(`📦 [orders.js] ${orders.length} pedidos cargados del usuario`);
    
    // USAR document.getElementById DIRECTAMENTE en lugar de $()
    let ul = document.getElementById('misPedidosList');
    
    // Debug: verificar qué está devolviendo $() vs document.getElementById
    console.log('🔍 Comparando selectores:');
    console.log('  - document.getElementById:', !!ul);
    console.log('  - $() función:', typeof $, $ ? $('#misPedidosList') : '$ no definido');
    
    if (!ul) {
        console.error('❌ [orders.js] #misPedidosList no encontrado con document.getElementById');
        console.log('Buscando alternativas...');
        
        // Intentar selector de jQuery si existe
        if (typeof jQuery !== 'undefined') {
            ul = jQuery('#misPedidosList')[0];
            console.log('  - jQuery selector:', !!ul);
        }
        
        // Buscar por selector CSS
        if (!ul) {
            ul = document.querySelector('#misPedidosList');
            console.log('  - querySelector:', !!ul);
        }
        
        // Último recurso: buscar cualquier ul en #misPedidos
        if (!ul) {
            const seccion = document.getElementById('misPedidos');
            if (seccion) {
                ul = seccion.querySelector('ul');
                console.log('  - ul en sección:', !!ul);
            }
        }
    }
    
    if (!ul) {
        console.error('❌ [orders.js] No se pudo encontrar el contenedor de ninguna manera');
        
        // Mostrar todos los elementos UL en la página para debug
        console.log('📋 Todos los ULs en el documento:');
        document.querySelectorAll('ul').forEach((ulElem, i) => {
            console.log(`  UL ${i+1}: id="${ulElem.id}", clases="${ulElem.className}", padre="${ulElem.parentElement?.id}"`);
        });
        
        return;
    }
    
    console.log('✅ [orders.js] Contenedor encontrado:', ul);
    
    // Limpiar lista
    ul.innerHTML = '';
    
    if (orders.length === 0) {
        ul.innerHTML = `
            <li class="list-group-item text-center text-muted py-3">
                <i class="bi bi-inbox fs-1 d-block mb-2"></i>
                No tienes pedidos realizados
            </li>
        `;
        console.log('ℹ️ [orders.js] Usuario no tiene pedidos');
        return;
    }
    
    console.log(`🎨 [orders.js] Renderizando ${orders.length} pedidos de usuario`);
    
    // Ordenar por fecha más reciente primero
    const ordenados = orders.sort((a, b) => {
        const fechaA = new Date(a.fecha || a.created_at || 0);
        const fechaB = new Date(b.fecha || b.created_at || 0);
        return fechaB - fechaA;
    });
    
    // Renderizar cada pedido
    ordenados.forEach(order => {
        this.crearItemPedidoUsuario(order, ul);
    });
    
    console.log('✅ [orders.js] Pedidos de usuario renderizados correctamente');
},

async renderAllOrders() {
    console.log('🔄 [orders.js] renderAllOrders() llamado');
    
    try {
        const orders = await this.loadAllOrders();
        console.log(`📊 [orders.js] ${orders.length} pedidos para renderizar`);
        
        // BUSCAR EL ELEMENTO DE DIFERENTES MANERAS
        let ul = document.getElementById('colaPedidos');
        
        if (!ul) {
            console.warn('⚠️ [orders.js] #colaPedidos no encontrado, buscando alternativas...');
            
            // 1. Buscar dentro de la sección listaPedidos
            const seccion = document.getElementById('listaPedidos');
            if (seccion) {
                console.log('✅ Sección listaPedidos encontrada');
                ul = seccion.querySelector('#colaPedidos');
                
                if (!ul) {
                    // 2. Buscar cualquier UL dentro de la sección
                    ul = seccion.querySelector('ul');
                    console.log('UL en sección:', ul);
                    
                    if (!ul) {
                        // 3. Crear una UL si no existe
                        console.log('⚠️ No hay UL, creando una...');
                        ul = document.createElement('ul');
                        ul.id = 'colaPedidos';
                        ul.className = 'list-group mb-2';
                        seccion.appendChild(ul);
                        console.log('✅ UL creada:', ul);
                    } else {
                        // 4. Si encontramos una UL pero no tiene el ID correcto
                        ul.id = 'colaPedidos';
                        console.log('✅ Asignado ID a UL existente');
                    }
                }
            } else {
                console.error('❌ [orders.js] Sección #listaPedidos tampoco encontrada');
                
                // Buscar en todo el documento
                const uls = document.querySelectorAll('ul');
                console.log(`${uls.length} ULs en el documento:`);
                uls.forEach((u, i) => {
                    console.log(`  UL ${i}: id="${u.id}", padre="${u.parentElement?.id}", clases="${u.className}"`);
                });
                
                return;
            }
        }
        
        console.log('✅ [orders.js] Contenedor encontrado:', ul);
        this.renderPedidosEnLista(orders, ul);
        
    } catch (error) {
        console.error('❌ [orders.js] Error en renderAllOrders:', error);
        this.mostrarErrorEnLista(error);
    }
},

  renderPedidosEnLista: function(orders, ul) {
    console.log(`🎨 [orders.js] Renderizando ${orders.length} pedidos en`, ul);
    
    // Limpiar lista
    ul.innerHTML = '';

    if (orders.length === 0) {
      ul.innerHTML = `
        <li class="list-group-item text-center text-muted">
          <div class="py-3">
            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
            No hay pedidos en el sistema
          </div>
        </li>
      `;
      return;
    }

    // Crear encabezado informativo
    const headerLi = document.createElement('li');
    headerLi.className = 'list-group-item bg-light text-center';
    headerLi.innerHTML = `<small class="text-muted">Mostrando ${orders.length} pedidos - Actualizado: ${new Date().toLocaleTimeString()}</small>`;
    ul.appendChild(headerLi);

    // Ordenar por fecha más reciente primero
    const ordenados = orders.sort((a, b) => {
      const fechaA = new Date(a.fecha || a.created_at || 0);
      const fechaB = new Date(b.fecha || b.created_at || 0);
      return fechaB - fechaA;
    });

    // Renderizar cada pedido
    ordenados.forEach((order, index) => {
      this.crearItemPedidoAdmin(order, ul, index + 1);
    });

    console.log('✅ [orders.js] Lista de pedidos renderizada correctamente');
  },

  crearItemPedidoUsuario: function(order, contenedor) {
    const li = document.createElement('li');
    li.className = `list-group-item order-card ${order.estado}`;
    
    // Determinar color según estado
    let estadoColor = 'secondary';
    if (order.estado === 'pagado') estadoColor = 'success';
    if (order.estado === 'pendiente') estadoColor = 'warning';
    if (order.estado === 'anulado') estadoColor = 'danger';
    if (order.estado === 'asignado') estadoColor = 'info';
    if (order.estado === 'entregado') estadoColor = 'dark';
    
    const idCorto = (order._id || order.id || 'N/A').substring(0, 8);
    const fecha = order.fecha || order.created_at;
    const fechaFormateada = fecha ? new Date(fecha).toLocaleDateString() : 'Fecha no disponible';
    
    li.innerHTML = `
      <div>
        <strong>Pedido: ${idCorto}...</strong>
        <span class="badge bg-${estadoColor} ms-2">${order.estado}</span>
      </div>
      <div class="tiny">Total: $${order.total?.toLocaleString() || 0}</div>
      <div class="tiny">Entrega: ${order.tipo_entrega || 'No especificado'} 
        ${order.direccion_entrega ? ` - ${order.direccion_entrega}` : ''}
      </div>
      <div class="tiny">Fecha: ${fechaFormateada}</div>
      
      <div class="mt-2">
        ${order.estado === 'pendiente' ? `
          <button class="btn btn-sm btn-outline-danger" onclick="orders.solicitarAnulacion('${order._id || order.id}')">
            ❌ Solicitar anulación
          </button>
        ` : ''}
        <button class="btn btn-sm btn-outline-info ms-1" onclick="orders.mostrarDetallesPedido(${JSON.stringify(order).replace(/"/g, '&quot;')})">
          📋 Detalles
        </button>
      </div>
    `;
    
    contenedor.appendChild(li);
  },

  crearItemPedidoAdmin: function(order, contenedor, numero) {
    const li = document.createElement('li');
    li.className = `list-group-item order-card ${order.estado}`;
    li.id = `pedido-${order._id || order.id}`;
    
    // Determinar color según estado
    let estadoColor = 'secondary';
    if (order.estado === 'pagado') estadoColor = 'success';
    if (order.estado === 'pendiente') estadoColor = 'warning';
    if (order.estado === 'anulado') estadoColor = 'danger';
    if (order.estado === 'asignado') estadoColor = 'info';
    if (order.estado === 'entregado') estadoColor = 'dark';
    
    // Formatear fecha
    const fecha = order.fecha || order.created_at || new Date().toISOString();
    const fechaFormateada = new Date(fecha).toLocaleDateString('es-CL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Extraer ID corto
    const idCorto = (order._id || order.id || '').substring(0, 8);
    
    li.innerHTML = `
      <div class="d-flex justify-content-between align-items-start">
        <div class="flex-grow-1">
          <div class="d-flex align-items-center mb-1">
            <span class="badge bg-secondary me-2">#${numero}</span>
            <h6 class="mb-0">Pedido: ${idCorto}...</h6>
          </div>
          
          <div class="mb-1">
            <span class="badge bg-${estadoColor}">${order.estado || 'sin estado'}</span>
            ${order.metodo_pago ? `<span class="badge bg-primary ms-1">${order.metodo_pago}</span>` : ''}
            ${order.tipo_entrega === 'delivery' ? '<span class="badge bg-info ms-1">🚚 Delivery</span>' : ''}
            ${order.tipo_entrega === 'retiro' ? '<span class="badge bg-warning ms-1">🏪 Retiro</span>' : ''}
          </div>
          
          <div class="small">
            <div><strong>👤 Cliente:</strong> ${order.cliente_correo || order.cliente_nombre || 'N/A'}</div>
            <div><strong>📅 Fecha:</strong> ${fechaFormateada}</div>
            <div><strong>💰 Total:</strong> $${(order.total || 0).toLocaleString()}</div>
            ${order.direccion_entrega ? `<div><strong>📍 Dirección:</strong> ${order.direccion_entrega}</div>` : ''}
            ${order.repartidor_id ? `<div><strong>🚚 Repartidor:</strong> ${order.repartidor_nombre || order.repartidor_id}</div>` : ''}
          </div>
        </div>
        
        <div class="btn-group-vertical ms-3">
          <button class="btn btn-sm btn-outline-info" onclick="orders.mostrarDetallesPedido(${JSON.stringify(order).replace(/"/g, '&quot;')})">
            📋 Detalles
          </button>
          
          ${this.esAdmin() && order.estado === 'pagado' && order.tipo_entrega === 'delivery' ? `
            ${order.repartidor_id ? `
              <button class="btn btn-sm btn-info mt-1" onclick="orders.verAsignacionRepartidor(${JSON.stringify(order).replace(/"/g, '&quot;')})">
                👁️ Ver Asignación
              </button>
            ` : `
              <button class="btn btn-sm btn-primary mt-1" onclick="orders.mostrarModalAsignacion(${JSON.stringify(order).replace(/"/g, '&quot;')})">
                🚚 Asignar
              </button>
            `}
          ` : ''}
          
          ${this.esAdmin() && order.estado === 'asignado' ? `
            <button class="btn btn-sm btn-success mt-1" onclick="orders.marcarComoEntregado(${JSON.stringify(order).replace(/"/g, '&quot;')})">
              ✅ Entregado
            </button>
          ` : ''}
          
          ${this.esAdmin() && order.estado === 'pendiente' ? `
            <button class="btn btn-sm btn-outline-danger mt-1" onclick="orders.mostrarModalAnulacion(${JSON.stringify(order).replace(/"/g, '&quot;')})">
              ❌ Anular
            </button>
          ` : ''}
        </div>
      </div>
    `;
    
    contenedor.appendChild(li);
  },

  // ========== FUNCIONES AUXILIARES ==========

  async populateAnulacionSelect() {
    console.log('🔄 [orders.js] Populando selector de anulación...');
    
    const userOrders = await this.loadUserOrders();
    
    // USAR document.getElementById DIRECTAMENTE
    const sel = document.getElementById('anulaPedidoSel');
    
    if (!sel) {
        console.error('❌ [orders.js] #anulaPedidoSel no encontrado con document.getElementById');
        
        // Debug: mostrar todos los selects
        console.log('📋 Todos los selects en la página:');
        document.querySelectorAll('select').forEach((select, i) => {
            console.log(`  Select ${i+1}: id="${select.id}"`);
        });
        
        return;
    }
    
    sel.innerHTML = '<option value="">-- seleccionar --</option>';
    
    const pedidosPendientes = userOrders.filter(order => order.estado === 'pendiente');
    console.log(`📝 [orders.js] ${pedidosPendientes.length} pedidos pendientes para anulación`);
    
    pedidosPendientes.forEach(order => {
        const opt = document.createElement('option');
        opt.value = order._id || order.id;
        opt.textContent = `${(order._id || order.id).substring(0, 8)} — $${(order.total || 0).toLocaleString()} - ${order.tipo_entrega || 'sin tipo'}`;
        sel.appendChild(opt);
    });
},

  async cancelOrder(orderId, motivo) {
    console.log(`🗑️ [orders.js] Anulando pedido ${orderId}: ${motivo}`);
    
    try {
      const result = await api.cancelOrder(orderId, motivo);
      console.log('✅ [orders.js] Pedido anulado:', result);
      return result;
    } catch (error) {
      console.error('❌ [orders.js] Error anulando pedido:', error);
      throw error;
    }
  },

  solicitarAnulacion: function(orderId) {
    console.log(`❌ [orders.js] Solicitando anulación para pedido ${orderId}`);
    
    // Rellenar el selector en la sección de anulación
    if ($('anulaPedidoSel')) {
      $('anulaPedidoSel').value = orderId;
    }
    
    // Mostrar la sección de anulación
    if (typeof showSection === 'function') {
      showSection('anulacion');
    }
    
    // Mostrar alerta
    if (confirm('Se ha seleccionado este pedido para anulación. ¿Deseas proceder con la anulación?')) {
      // Enfocar el selector de motivo
      if ($('anulaMotivoSel')) {
        $('anulaMotivoSel').focus();
      }
    }
  },

  mostrarErrorEnLista: function(error) {
    console.error('❌ [orders.js] Mostrando error en lista:', error);
    
    const ul = $('#colaPedidos');
    if (!ul) return;
    
    ul.innerHTML = `
      <li class="list-group-item text-danger">
        <div class="alert alert-danger">
          <h5>❌ Error cargando pedidos</h5>
          <p><strong>Mensaje:</strong> ${error.message}</p>
          <p><strong>Acciones:</strong></p>
          <div class="d-flex gap-2 mt-2">
            <button class="btn btn-sm btn-outline-danger" onclick="orders.renderAllOrders()">
              🔄 Reintentar
            </button>
            <button class="btn btn-sm btn-outline-secondary" onclick="debug.testOrdersAPI()">
              🌐 Test API
            </button>
            <button class="btn btn-sm btn-outline-info" onclick="console.log('Usuario:', auth.getCurrentUser())">
              👤 Ver Usuario
            </button>
          </div>
        </div>
      </li>
    `;
  },

  // ========== FUNCIONES PARA ASIGNACIÓN ==========

  async cargarRepartidoresDisponibles() {
    try {
      console.log('🚚 [orders.js] Cargando repartidores disponibles...');
      const response = await fetch(`${API_BASE}/asignaciones/repartidores/?estado=disponible`);
      if (!response.ok) throw new Error('Error cargando repartidores');
      const data = await response.json();
      console.log(`✅ [orders.js] ${data.length} repartidores disponibles`);
      return data;
    } catch (error) {
      console.error('❌ [orders.js] Error cargando repartidores:', error);
      return [];
    }
  },

  async mostrarModalAsignacion(pedido) {
    console.log('🚚 [orders.js] Mostrando modal de asignación para:', pedido._id);
    
    // Cargar repartidores disponibles
    let repartidores = [];
    try {
      repartidores = await this.cargarRepartidoresDisponibles();
    } catch (error) {
      console.error('❌ [orders.js] Error cargando repartidores:', error);
      repartidores = [];
    }
    
    // Crear modal dinámico
    const modalHTML = `
      <div class="modal fade" id="modalAsignacion" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">🚚 Asignar Repartidor</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <div class="card-skel mb-3">
                <h6>📦 Información del Pedido</h6>
                <p class="mb-1"><strong>ID:</strong> ${pedido._id?.substring(0, 8) || pedido.id?.substring(0, 8)}</p>
                <p class="mb-1"><strong>Cliente:</strong> ${pedido.cliente_correo}</p>
                <p class="mb-1"><strong>Total:</strong> $${(pedido.total || 0).toLocaleString()}</p>
                <p class="mb-1"><strong>Dirección:</strong> ${pedido.direccion_entrega || 'No especificada'}</p>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Seleccionar Repartidor:</label>
                ${repartidores.length > 0 ? `
                  <select id="selectRepartidor" class="form-select">
                    <option value="">-- Seleccione un repartidor --</option>
                    ${repartidores.map(rep => `
                      <option value="${rep.id}">
                        ${rep.nombre} (${rep.codigo}) - Zona: ${rep.zona} - Capacidad: ${rep.pedidos_asignados?.length || 0}/${rep.capacidad_maxima || 5}
                      </option>
                    `).join('')}
                  </select>
                ` : `
                  <div class="alert alert-warning">
                    No hay repartidores disponibles en este momento.
                    <button class="btn btn-sm btn-outline-primary mt-2" onclick="orders.recargarRepartidores()">
                      🔄 Recargar
                    </button>
                  </div>
                `}
              </div>
              
              <div id="msgAsignacion" class="mt-3"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
              ${repartidores.length > 0 ? `
                <button type="button" class="btn btn-primary" onclick="orders.asignarRepartidorPedido('${pedido._id || pedido.id}')">
                  Asignar Repartidor
                </button>
              ` : ''}
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Remover modal anterior si existe
    const modalAnterior = document.getElementById('modalAsignacion');
    if (modalAnterior) modalAnterior.remove();
    
    // Agregar nuevo modal
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Mostrar modal
    const modal = new bootstrap.Modal(document.getElementById('modalAsignacion'));
    modal.show();
  },

  async recargarRepartidores() {
    const select = document.getElementById('selectRepartidor');
    if (select) {
      select.innerHTML = '<option value="">Cargando repartidores...</option>';
    }
    
    const repartidores = await this.cargarRepartidoresDisponibles();
    
    if (select && repartidores.length > 0) {
      select.innerHTML = '<option value="">-- Seleccione un repartidor --</option>' +
        repartidores.map(rep => `
          <option value="${rep.id}">
            ${rep.nombre} (${rep.codigo}) - Zona: ${rep.zona} - Capacidad: ${rep.pedidos_asignados?.length || 0}/${rep.capacidad_maxima || 5}
          </option>
        `).join('');
    }
  },

  async asignarRepartidorPedido(pedidoId) {
    console.log(`🚚 [orders.js] Asignando repartidor a pedido ${pedidoId}`);
    
    const select = document.getElementById('selectRepartidor');
    const repartidorId = select?.value;
    const msgDiv = document.getElementById('msgAsignacion');
    
    if (!repartidorId) {
      if (msgDiv) {
        msgDiv.innerHTML = '<div class="alert alert-warning">Selecciona un repartidor</div>';
      }
      return;
    }
    
    try {
      const response = await fetch(`${API_BASE}/asignaciones/asignar/`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          pedido_id: pedidoId,
          repartidor_id: repartidorId
        })
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Error al asignar');
      }
      
      const result = await response.json();
      
      if (msgDiv) {
        msgDiv.innerHTML = `
          <div class="alert alert-success">
            ✅ ${result.mensaje}<br>
            <small>Repartidor: ${result.repartidor} (${result.codigo_repartidor})</small>
          </div>
        `;
      }
      
      // Cerrar modal después de 2 segundos
      setTimeout(() => {
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalAsignacion'));
        if (modal) modal.hide();
        
        // Recargar la lista de pedidos
        setTimeout(() => {
          this.renderAllOrders();
        }, 500);
      }, 2000);
      
    } catch (error) {
      console.error('❌ [orders.js] Error asignando repartidor:', error);
      if (msgDiv) {
        msgDiv.innerHTML = `<div class="alert alert-danger">❌ Error: ${error.message}</div>`;
      }
    }
  },

  async verAsignacionRepartidor(pedido) {
    try {
      console.log(`👁️ [orders.js] Viendo asignación de pedido ${pedido._id}`);
      
      // Obtener información del repartidor
      const response = await fetch(`${API_BASE}/asignaciones/repartidores/`);
      if (!response.ok) throw new Error('Error cargando repartidores');
      
      const repartidores = await response.json();
      const repartidor = repartidores.find(r => r.id === pedido.repartidor_id);
      
      const modalHTML = `
        <div class="modal fade" id="modalVerAsignacion" tabindex="-1">
          <div class="modal-dialog">
            <div class="modal-content">
              <div class="modal-header">
                <h5 class="modal-title">👁️ Asignación Actual</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
              </div>
              <div class="modal-body">
                <div class="card-skel mb-3">
                  <h6>📦 Pedido</h6>
                  <p class="mb-1"><strong>ID:</strong> ${pedido._id?.substring(0, 8) || pedido.id?.substring(0, 8)}</p>
                  <p class="mb-1"><strong>Cliente:</strong> ${pedido.cliente_correo}</p>
                  <p class="mb-1"><strong>Dirección:</strong> ${pedido.direccion_entrega || 'No especificada'}</p>
                </div>
                
                ${repartidor ? `
                  <div class="card-skel">
                    <h6>🚚 Repartidor Asignado</h6>
                    <p class="mb-1"><strong>Nombre:</strong> ${repartidor.nombre}</p>
                    <p class="mb-1"><strong>Código:</strong> ${repartidor.codigo}</p>
                    <p class="mb-1"><strong>Zona:</strong> ${repartidor.zona}</p>
                    <p class="mb-1"><strong>Estado:</strong> ${repartidor.estado}</p>
                    <p class="mb-1"><strong>Pedidos asignados:</strong> ${repartidor.pedidos_asignados?.length || 0}</p>
                  </div>
                ` : `
                  <div class="alert alert-warning">
                    No se pudo obtener información del repartidor asignado.
                  </div>
                `}
              </div>
              <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
              </div>
            </div>
          </div>
        </div>
      `;
      
      // Remover modal anterior si existe
      const modalAnterior = document.getElementById('modalVerAsignacion');
      if (modalAnterior) modalAnterior.remove();
      
      // Agregar nuevo modal
      document.body.insertAdjacentHTML('beforeend', modalHTML);
      
      // Mostrar modal
      const modal = new bootstrap.Modal(document.getElementById('modalVerAsignacion'));
      modal.show();
      
    } catch (error) {
      console.error('❌ [orders.js] Error viendo asignación:', error);
      alert('Error al obtener información de la asignación');
    }
  },

  async marcarComoEntregado(pedido) {
    console.log(`✅ [orders.js] Marcando como entregado: ${pedido._id}`);
    
    if (!confirm(`¿Confirmar que el pedido ${pedido._id?.substring(0, 8) || pedido.id?.substring(0, 8)} ha sido entregado?`)) {
      return;
    }
    
    try {
      const response = await fetch(`${API_BASE}/asignaciones/entregar/${pedido._id || pedido.id}`, {
        method: 'PUT'
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || 'Error al marcar como entregado');
      }
      
      const result = await response.json();
      alert(`✅ ${result.mensaje}`);
      
      // Recargar la lista de pedidos
      setTimeout(() => {
        this.renderAllOrders();
      }, 500);
      
    } catch (error) {
      console.error('❌ [orders.js] Error marcando como entregado:', error);
      alert(`❌ Error: ${error.message}`);
    }
  },

  mostrarDetallesPedido(pedido) {
    console.log(`📋 [orders.js] Mostrando detalles de pedido ${pedido._id}`);
    
    const detallesHTML = `
      <div class="card-skel">
        <h5>📋 Detalles Completos del Pedido</h5>
        
        <div class="row">
          <div class="col-md-6">
            <h6>📦 Información General</h6>
            <p><strong>ID:</strong> ${pedido._id || pedido.id}</p>
            <p><strong>Cliente:</strong> ${pedido.cliente_correo}</p>
            <p><strong>Estado:</strong> ${pedido.estado}</p>
            <p><strong>Total:</strong> $${(pedido.total || 0).toLocaleString()}</p>
            <p><strong>Fecha creación:</strong> ${new Date(pedido.created_at).toLocaleString()}</p>
          </div>
          
          <div class="col-md-6">
            <h6>🚚 Información de Entrega</h6>
            <p><strong>Tipo entrega:</strong> ${pedido.tipo_entrega || 'No especificado'}</p>
            <p><strong>Dirección:</strong> ${pedido.direccion_entrega || 'No especificada'}</p>
            ${pedido.metodo_pago ? `<p><strong>Método pago:</strong> ${pedido.metodo_pago}</p>` : ''}
            ${pedido.repartidor_id ? `<p><strong>Repartidor ID:</strong> ${pedido.repartidor_id}</p>` : ''}
          </div>
        </div>
        
        <h6 class="mt-3">🛒 Items del Pedido</h6>
        <div class="table-responsive">
          <table class="table table-sm">
            <thead>
              <tr>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio Unitario</th>
                <th>Subtotal</th>
              </tr>
            </thead>
            <tbody>
              ${(pedido.items || []).map(item => `
                <tr>
                  <td>${item.nombre || 'Producto'}</td>
                  <td>${item.cantidad || 1}</td>
                  <td>$${(item.precio || 0).toLocaleString()}</td>
                  <td>$${((item.precio || 0) * (item.cantidad || 1)).toLocaleString()}</td>
                </tr>
              `).join('')}
              <tr class="table-success">
                <td colspan="3" class="text-end"><strong>TOTAL:</strong></td>
                <td><strong>$${(pedido.total || 0).toLocaleString()}</strong></td>
              </tr>
            </tbody>
          </table>
        </div>
        
        ${pedido.motivo_anulacion ? `
          <div class="alert alert-danger mt-3">
            <h6>❌ Motivo de Anulación</h6>
            <p>${pedido.motivo_anulacion}</p>
          </div>
        ` : ''}
      </div>
    `;
    
    // Crear modal de detalles
    const modalHTML = `
      <div class="modal fade" id="modalDetalles" tabindex="-1">
        <div class="modal-dialog modal-lg">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Detalles del Pedido</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              ${detallesHTML}
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Remover modal anterior si existe
    const modalAnterior = document.getElementById('modalDetalles');
    if (modalAnterior) modalAnterior.remove();
    
    // Agregar nuevo modal
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Mostrar modal
    const modal = new bootstrap.Modal(document.getElementById('modalDetalles'));
    modal.show();
  },

  mostrarModalAnulacion(pedido) {
    console.log(`❌ [orders.js] Mostrando modal de anulación para pedido ${pedido._id}`);
    
    const modalHTML = `
      <div class="modal fade" id="modalAnulacionAdmin" tabindex="-1">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">❌ Anular Pedido</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
              <p>¿Estás seguro de anular este pedido?</p>
              <div class="card-skel mb-3">
                <p><strong>ID:</strong> ${pedido._id?.substring(0, 8) || pedido.id?.substring(0, 8)}</p>
                <p><strong>Cliente:</strong> ${pedido.cliente_correo}</p>
                <p><strong>Total:</strong> $${(pedido.total || 0).toLocaleString()}</p>
              </div>
              
              <div class="mb-3">
                <label class="form-label">Motivo de anulación:</label>
                <select id="motivoAnulacionAdmin" class="form-select">
                  <option value="">-- Seleccionar motivo --</option>
                  <option value="Cliente solicitó cancelación">Cliente solicitó cancelación</option>
                  <option value="Stock insuficiente">Stock insuficiente</option>
                  <option value="Error en el sistema">Error en el sistema</option>
                  <option value="Otro motivo">Otro motivo</option>
                </select>
                <textarea id="motivoPersonalizado" class="form-control mt-2" placeholder="Especificar motivo (si seleccionó 'Otro motivo')" style="display: none;"></textarea>
              </div>
              
              <div id="msgAnulacionAdmin" class="mt-3"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
              <button type="button" class="btn btn-danger" onclick="orders.ejecutarAnulacionAdmin('${pedido._id || pedido.id}')">
                Confirmar Anulación
              </button>
            </div>
          </div>
        </div>
      </div>
    `;
    
    // Remover modal anterior si existe
    const modalAnterior = document.getElementById('modalAnulacionAdmin');
    if (modalAnterior) modalAnterior.remove();
    
    // Agregar nuevo modal
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    
    // Mostrar modal
    const modal = new bootstrap.Modal(document.getElementById('modalAnulacionAdmin'));
    modal.show();
    
    // Mostrar/ocultar textarea para motivo personalizado
    document.getElementById('motivoAnulacionAdmin').addEventListener('change', function() {
      const textarea = document.getElementById('motivoPersonalizado');
      textarea.style.display = this.value === 'Otro motivo' ? 'block' : 'none';
    });
  },

  async ejecutarAnulacionAdmin(pedidoId) {
    console.log(`🗑️ [orders.js] Ejecutando anulación admin para pedido ${pedidoId}`);
    
    const select = document.getElementById('motivoAnulacionAdmin');
    const motivoBase = select?.value;
    const motivoPersonalizado = document.getElementById('motivoPersonalizado')?.value;
    const msgDiv = document.getElementById('msgAnulacionAdmin');
    
    if (!motivoBase) {
      if (msgDiv) {
        msgDiv.innerHTML = '<div class="alert alert-warning">Selecciona un motivo</div>';
      }
      return;
    }
    
    const motivoFinal = motivoBase === 'Otro motivo' && motivoPersonalizado 
      ? motivoPersonalizado 
      : motivoBase;
    
    try {
      const result = await this.cancelOrder(pedidoId, motivoFinal);
      
      if (msgDiv) {
        msgDiv.innerHTML = `<div class="alert alert-success">✅ ${result.mensaje}</div>`;
      }
      
      // Cerrar modal después de 2 segundos
      setTimeout(() => {
        const modal = bootstrap.Modal.getInstance(document.getElementById('modalAnulacionAdmin'));
        if (modal) modal.hide();
        
        // Recargar la lista de pedidos
        setTimeout(() => {
          this.renderAllOrders();
          if (typeof populateAllViews === 'function') {
            populateAllViews();
          }
        }, 500);
      }, 2000);
      
    } catch (error) {
      console.error('❌ [orders.js] Error anulando pedido:', error);
      if (msgDiv) {
        msgDiv.innerHTML = `<div class="alert alert-danger">❌ Error: ${error.message}</div>`;
      }
    }
  },

  // ========== FUNCIONES DE DIAGNÓSTICO ==========

  testModule: async function() {
    console.log('🧪 [orders.js] Testeando módulo orders...');
    
    try {
      // 1. Verificar que las funciones principales existen
      const funcionesEsenciales = [
        'initialize',
        'loadAllOrders',
        'renderAllOrders',
        'loadUserOrders',
        'renderUserOrders'
      ];
      
      console.log('🔍 Funciones disponibles:');
      funcionesEsenciales.forEach(func => {
        console.log(`  - ${func}:`, typeof this[func] === 'function' ? '✅' : '❌');
      });
      
      // 2. Testear API
      console.log('🌐 Testeando conexión API...');
      const pedidos = await this.loadAllOrders();
      console.log(`📦 Pedidos obtenidos en test: ${pedidos.length}`);
      
      // 3. Verificar usuario
      const user = this.getCurrentUser();
      console.log(`👤 Usuario actual:`, user ? `${user.correo} (${user.rol})` : 'No logueado');
      
      // 4. Verificar elementos DOM
      console.log('🏗️ Verificando elementos DOM:');
      console.log(`  - #colaPedidos:`, $('#colaPedidos') ? '✅' : '❌');
      console.log(`  - #misPedidosList:`, $('#misPedidosList') ? '✅' : '❌');
      
      return {
        funcionesOk: funcionesEsenciales.every(func => typeof this[func] === 'function'),
        pedidosCount: pedidos.length,
        usuario: user,
        domOk: $('#colaPedidos') && $('#misPedidosList')
      };
      
    } catch (error) {
      console.error('❌ [orders.js] Error en testModule:', error);
      return { error: error.message };
    }
  },

  forceRender: function() {
    console.log('⚡ [orders.js] Forzando renderizado de pedidos...');
    
    if (this.esAdmin()) {
      console.log('👨‍💼 Forzando renderAllOrders()...');
      this.renderAllOrders();
    } else {
      console.log('👤 Forzando renderUserOrders()...');
      this.renderUserOrders();
    }
  }
};

// Auto-inicialización cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', function() {
  console.log('📜 [orders.js] Script cargado, iniciando auto-inicialización...');
  
  // Esperar un momento para que otros módulos se carguen
  setTimeout(() => {
    if (window.orders && window.orders.initialize) {
      window.orders.initialize();
    } else {
      console.error('❌ [orders.js] No se pudo auto-inicializar: objeto orders no encontrado');
    }
  }, 1000);
});

// Hacer disponible globalmente
window.orders = orders;

// Exportar para tests
if (typeof module !== 'undefined' && module.exports) {
  module.exports = orders;
}