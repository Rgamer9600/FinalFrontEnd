// Gestión de pagos
const payments = {
async processPayment(metodo) {
  const currentOrderId = cart.getCurrentOrderId();
  if (!currentOrderId) {
    this.showMessage('No hay un pedido para pagar', 'error');
    return;
  }

  try {
    const allOrders = await orders.loadAllOrders();
    const currentOrder = allOrders.find(order => 
      order._id === currentOrderId || 
      order.id === currentOrderId
    );
    
    if (!currentOrder) {
      throw new Error('Pedido no encontrado');
    }

    // VERIFICAR TIPOS DE DATOS
    const paymentData = {
      pedido_id: String(currentOrder._id || currentOrder.id), // Asegurar string
      metodo: String(metodo), // Asegurar string
      monto: Number(currentOrder.total) // Asegurar número
    };

    console.log('🔍 Datos de pago que se enviarán:');
    console.log('pedido_id:', paymentData.pedido_id, 'tipo:', typeof paymentData.pedido_id);
    console.log('metodo:', paymentData.metodo, 'tipo:', typeof paymentData.metodo);
    console.log('monto:', paymentData.monto, 'tipo:', typeof paymentData.monto);

    const result = await api.processPayment(paymentData);
    this.showPaymentResult(result);
    
    return result;
  } catch (error) {
    console.error('❌ Error completo:', error);
    this.showMessage('Error al procesar pago: ' + error.message, 'error');
    return null;
  }
},

  showPaymentResult(result) {
    const mensaje = $('mensajePago');
    if (!mensaje) return;

    if (result.estado === 'exitoso') {
      mensaje.style.color = "green";
      mensaje.textContent = `Pago exitoso! ID: ${result.pago_id}`;
      
      // Ocultar sección de pago después de éxito
      setTimeout(() => {
        $('seccionPago').classList.add('hidden');
        populateAllViews();
      }, 3000);
    } else {
      mensaje.style.color = "red";
      mensaje.textContent = `Pago rechazado: ${result.mensaje}`;
    }
  },

  showPaymentSection(orderResult) {
    $('seccionPago').classList.remove('hidden');
    $('totalPago').textContent = `$${orderResult.total.toLocaleString("es-CL")}`;
    $('pedidoIdPago').textContent = orderResult.pedido_id;
  },

  showMessage(message, type = 'info') {
    alert(message); // Simple alert por ahora
  }
};

// Exportar para uso global
window.payments = payments;